---
name: "etsy-planner-builder"
description: "Build a new digital planner product for the user's Etsy shop as a single-file HTML app in their established mobile-first design system, plus its Etsy title, tags, description, finished listing photos, Pinterest pins and a zipped buyer download with a \"Start Here\" PDF guide, then uploads it all as a draft listing via their Etsy connector, and on request TikTok/Instagram videos: organic screen-recorded clips with captions, a 3D phone showcase, or a cinematic promo. First checks the niche for a go/no-go. Use whenever the user wants a new planner, tracker or organizer to sell, whether they paste a competitor's module list, name a niche (\"ADHD meal planner\", \"wedding planner\", \"budget planner\"), or give any idea for one. Also use when adding modules to, fixing, or checking the mobile layout of one of their existing planners, or when writing an Etsy listing, publishing a listing, making listing photos/mockups, or making TikTok/Instagram videos (clips, 3D phone showcase, promo, hook) for one."
---

# Etsy planner builder

The user sells digital planners on Etsy: single-file HTML apps that
buyers download and open in a browser, mostly on their phones. Existing
products: Homeschool Planner, ADHD Life Planner (Sunny, mango; 14
modules in Plan / Life hubs with star rewards), ADHD Study Planner, Side Hustle Income Tracker, GLP-1
Tracker, Student Nurse Planner (blue palette), Job Search Tracker (slate
palette), Coin Collection Tracker, 3D Print Pricing
Calculator (Bold, petrol teal), Soap Business Planner (Playful,
lavender), Christmas Gift Tracker (Playful, Christmas red), ADHD Budget
Planner (Dreamy, ocean blue), ADHD Paycheck Budget Planner (Bold, forest
and emerald), Pantry & Food Inventory Tracker (Playful, carrot orange),
Workout Tracker (Focused, graphite and lime), College Application Tracker (Focused, navy and gold), Cross Stitch Thread Tracker (Focused, plum; DMC color chart), Diamond Painting Tracker (Bold, violet and orange; DMC drills), Nail Polish Collection Tracker (Playful, rose). Every new planner should look and behave
like a sibling of these, and must be flawless on a phone, because that's
where buyers judge it in the first ten seconds.

## Files in this skill

- `assets/starter-template.html`: the shell to start every planner from.
  Full design system CSS, navigation generated from a `NAV` list, state
  with `normalize()`, toasts with Undo, confirm modal, confetti, export /
  import / clear / sample data, embedded offline icons, screenshot hook.
- `references/personalities.md` + `assets/personalities/` (bold, calm,
  playful, sunny, dreamy .html): the shared base, the menu of hero / color /
  progress / input / tab bar / celebration options, and six personalities
  (Bold, Calm, Playful, Focused, Sunny, Dreamy). Read before planning; lift
  components from the example files.
- `references/design-system.md`: what each color, size and component is
  for, and the behaviors every planner keeps. Read before designing views.
- `references/mobile-rules.md`: the mobile requirements and layout
  patterns, including how to handle 15–25 modules. Read before building.
- `references/example-study-planner.html`: a complete finished planner
  (ADHD Study Planner). Look here for worked examples of richer
  components: assignment cards with subtasks, focus timer, donut and bar
  charts, class color picker, bulk add, streaks, wins log.
- `references/etsy-listing.md`: title, tag and description rules.
- `assets/start-here-template.html` + `scripts/make_buyer_package.py`:
  the buyer's "Start Here" PDF guide, zipped with the planner HTML Its background is the listing
  photos' blurred glows + dot patch (set `--glow1..4` per planner).
- `scripts/embed_icons.py`: copies the drawings of every Material
  Symbols icon the planner uses into the file (from
  `assets/material-symbols-outlined.json.gz`, all ~4,150 icons, Apache
  2.0 licensed, fine for products you sell).
- `scripts/check_mobile.py`: headless phone test of every view at 320,
  375 and 430px. Saves screenshots and reports problems.
- `scripts/make_palette.py`: five shades from one color the seller
  names, with contrast checks and ready CSS tokens.
- `scripts/make_pins.py` + `references/pinterest.md`: Pinterest pins
  (2:3) with titles, descriptions, alt text and board suggestions.
- `scripts/make_listing_photos.py` + `references/listing-photos.md`:
  finished Etsy listing images (3D phones and laptop, headlines, brand
  colors) planned for this planner's buyer. `references/example-photos.json`
  is a worked example of the spec format.
- `scripts/make_3d_video.py` + `references/3d-video.md`: 3D showcase
  videos for TikTok/Instagram (the real app on the 3D phone, whip-pan
  transitions, pop-out cards, end card), in two styles. 
  `references/example-3d-video.json` is a worked spec.
- `assets/device3d/`: the 3D devices the photo, pin and video scripts render with:
  `devices.html` (a jet black phone and laptop modeled in three.js) and
  the bundled three.js files (r165, MIT), so nothing is downloaded.

## Workflow

### 1. Check the niche first (go / no-go)

Before planning anything, check that buyers are really paying for this
kind of planner, so the seller doesn't spend a build on a dead niche.

**Use the Etsy connector when it's there.** The seller has his own Etsy
connector (a custom MCP; its tools are named like `*__search_etsy`,
`*__get_shop`, `*__get_listing`,
`*__get_reviews`; load them with ToolSearch "search_etsy" if deferred).
Don't fetch or analyze competitor photos (skip `get_listing_photos` on
other shops' listings); the seller doesn't want that step.
It returns real numbers from Etsy's API, so prefer it over web scraping:

1. Start from the listing the seller gave you: `get_listing` (title,
   description, price, tags, views, favorites) and `get_reviews` with its
   `shop_id` (ratings, dates, what reviewers praise or complain about).
2. Run `search_etsy` for the niche phrase plus 2–3 wording variants a
   buyer might type (limit 50 each). For the top ~10 distinct shops, call
   `get_shop` (total sales, review count, shop age). Views and favorites
   per listing are the demand signal; shop sales and reviews show who
   actually sells. The `created` field resets when a listing auto-renews,
   so don't read it as listing age. If the connector isn't available or a
   call fails, fall back to WebSearch (`site:etsy.com/listing "<niche>"
   digital`) and WebFetch individual listing pages.
   Never guess numbers you couldn't read; say "couldn't read".
3. Report a short table: listing (shop + link), price, views, favorites,
   shop sales, reviews, format (app / PDF / GoodNotes / spreadsheet).
   Then 3–5 lines:
   - **Demand:** total search results, views and favorites on the top
     listings, how many shops have sales/reviews, and how recent reviews
     are (last ~3 months count most; only a small share of buyers leave
     reviews, so a few still mean real sales).
   - **Crowding:** a few strong sellers with hundreds of reviews each =
     hard; demand spread across small or dated listings = opportunity.
   - **Gaps:** the repeated complaints in low reviews (these become the
     planner's selling points) and features nobody offers.
   - **Price range** and where this planner should sit.
   - **Risks:** brand or trademark names the niche depends on (drug,
     app or brand names that can't go in the listing).
4. Give a clear verdict: **Go**, **Go with a twist** (what to do
   differently), or **Skip** (and why). Only one listing with reviews,
   or reviews all older than a year, is a weak signal: say so.

Keep it to one message. If the seller already said "just build it",
still run the check, report it alongside the plan, and continue unless
the verdict is Skip.

### 2. Plan the modules

**Ask about the look first** (unless the seller already said): the
seller won't remember the personality names, so offer them. Use
AskUserQuestion with two questions:
- *"Which personality should this planner have?"*: the best fit for
  the niche first, labeled "(Recommended)", then the next three fits.
  Each option's description is one short line of feel plus what's in
  it, e.g. Calm: "Quiet and reassuring: soft ring, muted colors, no
  emoji". The others are reachable by typing a name (Other); for kid,
  family or reward niches consider Sunny, for wellness, sleep, mood or
  habit niches consider Dreamy.
- *"What should the main color be?"*: "Shop palette (sage and
  terracotta)", "One color, I'll name it", "I'll send a palette", and
  "You pick for the niche".

Ask both together, alongside the niche report when there is one. If no
one answers (unattended), take the recommended options and say so.

Input is usually a competitor listing's module list, sometimes just an
idea. Turn it into a plan the user can check before you write code:

- The planner's name, audience, and a planner-specific `STORAGE_KEY`
  (e.g. `adhdMealPlannerData_v1`) and backup prefix.
- Each module: what the buyer does in it, the data it stores, and the
  one thing it shows first.
- Navigation: 5 bottom-nav items max. With more than ~6 modules, group
  them into sections with module-card hubs (see mobile-rules.md).
- The **personality** (read references/personalities.md): the one that
  fits this niche, plus 1–2 swapped slots so it isn't a clone of another
  planner in the shop, e.g. "Personality: Calm, with the day row instead
  of bars".
- A Home/Today view that pulls the most important item from across the
  modules into a "right now" card. Settings always included.
- Use competitor modules as inspiration for *what* to include; design
  and word everything fresh. Merge near-duplicates, cut filler pages
  that add nothing in an app (cover pages, blank notes pages become one
  Notes module), and add what an interactive app does better than a PDF
  (auto totals, streaks, progress bars, reminders of what's due).
- The full price, from the price ladder in step 5.

Share the plan in a short list and ask for a yes or changes. If the user
has said to just go ahead, state the plan and continue.

### 3. Build from the template

Copy `assets/starter-template.html` to `<planner-slug>.html`, replace
`__PLANNER_NAME__`, `__STORAGE_KEY__` and `__BACKUP_PREFIX__`, then:

- Fill `NAV`, add one `<section class="view" id="view-<name>">` and one
  render function per view, and register each in `RENDER`. The
  `?view=<name>` hook and the checker find views by that id.
- Extend `defaultState()` and `normalize()` for every new field, and the
  import check for the main collections. normalize must give a safe
  default for anything missing, so old backups still load.
- Tabs inside a view use `data-action="<something>-tab"` so the mobile
  checker visits each tab.
- Reuse existing components and tokens before writing new CSS (see
  `.filter-stack`, `.summary-stats`, `.donut` in design-system.md). When a
  module needs something new (a calendar, a meal grid), build it from
  the same tokens: 8-point spacing, the four type sizes, radius 10/14/20,
  sage for done, terracotta for urgent.
- Apply the chosen personality to every view, not only Home: its hero
  style for each screen's lead number (one big number, supporting stats
  in a strip or chips), its color logic, progress style, inputs, tab
  bar, celebration and motion feel. Lift components from
  `assets/personalities/*.html` into the template's structure. Write the
  personality in a comment at the top of `<style>`.
- Use the template's base motion everywhere: `.rise` with a `--i`
  stagger on each view's sections, `data-count` on headline numbers with
  `countUp(viewEl)` at the end of the render, press feedback, and
  check-off pops. Keep the reduced-motion block.
- Keep the template's **motion kit** (the seller's premium-feel upgrade):
  every tappable thing springs when pressed, bottom sheets spring up and
  drag down to close, the bottom-nav pill glides between tabs, toasts pop
  in on a spring, and ticking any `.check-hit` checkbox fires a ripple,
  sparks and a tiny vibration (Android) automatically. The default feel
  sits between Calm and Bold (the seller's choice); a personality can set
  `<body data-motion="playful">` (bouncier: Playful, Sunny) or
  `data-motion="bold"` (snappier: Bold), and `calm` for Calm and Dreamy.
  Leave Focused on the default. Use `motionBurst(el)` for
  other satisfying taps (a stage button, "mark paid"), `buzz()` for a
  haptic tick, and `rollNumber(el, value, '$')` for a hero number that
  changes in place (odometer roll). Give new tappable custom components
  the class `tap` so they press too. Performance: animate only transform
  and opacity; never `filter: blur` in entrances and never animate
  `backdrop-filter` (it stutters on phones; the seller tested it).
  After a tap that re-renders the view, don't replay `.rise` entrances:
  add a `settled` class to the view ~1s after it opens and turn `.rise`
  off under it (`.view.settled .rise{ animation:none }`).
- **Dark mode, always.** Keep the template's head theme script and the
  Settings > Appearance control (Light / Dark / Auto, Auto by default, so
  buyers with a dark phone get it automatically; the choice is stored
  under `STORAGE_KEY + ':theme'`, outside the data). Every planner ships
  a dark palette: under `:root[data-theme="dark"]` re-define each color
  token the planner sets (its `--c-*` shades, `--bg`, `--surface`,
  `--field`, `--ink*`, `--border*`, accents, `--nav-active`, `--on-nav`,
  `--action`/`--on-action`) following personalities.md > Dark mode, and
  lift the matching block from the personality's example file
  (`<style id="dark-mode">`). In new CSS never hardcode `#fff` surfaces
  or `var(--ink)` button fills: use `var(--surface)`, `var(--field)`,
  `var(--action)`. The checker runs a dark pass at 375px (phone set to
  dark) and flags a planner that stays light, white surfaces left behind
  and low-contrast text; also look at the `-dark` screenshots yourself.
- Navigation on phones floats: the template's labeled floating tab bar
  (inset, soft blur, active tab a solid pill) unless the personality
  uses the dark icon pill or the raised-center-button bar. With a custom
  palette, set `--nav-active` to the palette's darkest action color
  (e.g. slate #11212D). Active icons swap to the filled shape only when
  one exists (`svg:has(.f)`), or icons like `insights` vanish.
- Rows with a checkbox or button beside text: the text column gets
  `flex:1; min-width:0`, and each line is `display:block` with ellipsis,
  so long subtitles never run under the control. Tap targets 44px.
- No app-name header bar and no planner name in the top-left corner (or
  atop the desktop sidebar): buyers know which app they opened, and a
  pinned name is template filler. Each view opens with its own title.
  Anything that must stay visible everywhere, like a running timer,
  floats as a small `.float-pill` top-right.
- Keep the shared behaviors: Undo toasts on delete, celebrate on
  completion, gentle empty states, local-only privacy line.
- Write `applySampleData()` with realistic, specific content for every
  module, dated relative to today. It's what the listing photos show, so
  make it look like a real person's week.
- Icons: write them exactly as before, `<span class="icon">settings</span>`
  in markup or `icon('settings', 18)` in JS, using any Material Symbols
  name (fonts.google.com/icons). Then run
  `python3 <skill-dir>/scripts/embed_icons.py <planner>.html`, and run it
  again whenever icons change. It embeds the drawings so icons work
  offline, on school/work wifi that blocks Google, and on a first open.
  It exits with an error on a misspelled name. Never add the Material
  Symbols font link back. Inside HTML that JS builds at runtime, always
  use `icon('name')`: a raw `<span class="icon">name</span>` written by
  a render function won't get its drawing.
- Any timer (focus timer, countdown, stopwatch) counts from the clock,
  never by ticks, so it keeps exact time in a background tab, on a
  locked phone, after a reload and even after the page was closed (a
  competitor got a 2-star review for a timer that stopped on tab switch):
  - Start: `t.endAt = Date.now() + durationMs; t.status = 'running'; save();`
    Pause: `t.remainingMs = t.endAt - Date.now(); t.endAt = null;`
    Resume: `t.endAt = Date.now() + t.remainingMs;`
  - Remaining is always computed: `Math.max(0, t.endAt - Date.now())`
    (a stopwatch computes `Date.now() - t.startedAt`). Never
    `remaining -= 1`, `seconds--` or `elapsed++` in a tick; the checker
    flags these.
  - `setInterval(tick, 500)` only redraws; `tick()` finishes the session
    when `Date.now() >= t.endAt`. Also call `tick()` on
    `visibilitychange` (when `!document.hidden`), `focus` and `pageshow`.
  - The timer lives in saved state, so on startup a session whose
    `endAt` already passed is completed and logged with a "finished
    while you were away" toast.
  - Show the running time in `document.title` and a header pill.
  Details in design-system.md > Timers.
- Icons beside text (pills, chips, status tags, buttons, card labels)
  line up with the capital letters, not the line box: give any new
  icon + text component the class `ic-text` (the template already
  covers .tag, .pill, .btn, .link-btn, .back-btn, .rightnow-label and
  .nav-btn), and give icon-above-label buttons the class `stacked`.
  Details in design-system.md > Icons beside text; the checker flags
  misses.
- Buttons are centered by what you see, not by their boxes. Material
  icons carry uneven empty space (the + icon is 20% blank on each side)
  and a line box sits capitals about 1px low, so box-centered buttons look
  lopsided. Keep the template's `opticalCenter()` block (ICONS section):
  after every render it nudges each `.btn`, `.pill`, `.tag`, `.icon-btn`
  and `.fab` so the visible icon and capital letters sit dead center, and
  centers a column button's icon over its label. Give icon-above-label
  buttons `.stacked` anyway (quick-add tiles, card action rows); without
  it the capital-letter rule pins their icons to the left. In a row of
  stacked buttons the labels stay level whatever each icon's shape. The
  checker flags anything visibly off center (`content-not-optically-centered`).
- Every new button style is centered both ways, including text-only
  buttons. A new class like `.mini-btn` or `.chip-btn` with
  `display:inline-flex` and a `min-height` but no `align-items:center`
  leaves its label stuck to the top of the button (this shipped once on
  the ADHD Budget Planner's "Skip it / Buy it" buttons). Give every new
  button class `align-items:center; justify-content:center`, or add
  `ic-text` when it has an icon beside the text. Never set
  `align-items:center` on a class that is also used with `ic-text`
  (write `.x:not(.ic-text){ align-items:center; }`): your CSS loads
  after the template's and would undo the capital-letter alignment. The
  checker flags any button whose label sits more than 2px off its
  vertical center (`button-text-not-centered`), whatever its class.
- Every button's label is measured, not just the template's classes. The
  template's `opticalCenter()` now runs on every `button` and
  `[role=button]` and centers labels vertically whenever the content is
  centered top to bottom, even with `padding: 0 20px` and a min-height
  (the Workout Tracker's lime "Start workout" and "New plan" buttons
  shipped 1.3px low because it used to skip `display:flex` buttons with no
  `justify-content` and buttons with no vertical padding). The checker's
  `button-text-not-centered` now measures every button with a visible box
  and flags anything more than 1px off. Never ship with it reporting.
- Emoji and icons inside shapes (hexagon icons, icon tiles, rings,
  avatar circles) sit dead center: give the shape `display:grid;
  place-items:center`, and scope descendant rules so they can't reach
  it. A card rule like `.mcard span{display:block}` meant for a subtitle
  also matched the card's hexagon `<span>` and pinned every emoji to its
  top-left corner (it shipped once on the ADHD Life Planner's Plan and
  Life hubs). Target the text you mean (`.mcard div > span`, or a class
  like `.mc-sub`), never a bare tag inside a component. The checker flags
  any emoji or icon more than ~2px off center in a small shaped box
  (`content-not-centered-in-shape`).
- Timelines (activity feeds, history lists, step trackers): center every
  dot on the line mathematically, never with separate hand-tuned
  offsets, so they can't drift apart on high-resolution phones. Put
  the line and the dots in the same coordinate system: each row gets
  `position:relative; padding-left:24px`, the line is a `::before` at
  `left:7px; width:2px`, and the dot is an `::after` at `left:8px`
  with `transform:translate(-50%, -50%)` and `top` set to the middle of
  the first text line (e.g. `top:0.75em`). Zoom into a 375px
  screenshot of every timeline to check the dots sit dead center.
  Details in design-system.md > Timelines.
- Colors: keep the shop palette unless the seller asks for a change; to
  change it, redefine the accent tokens as described in
  design-system.md > Color roles, keeping the light background. If the
  seller gives just one color, run
  `python3 <skill-dir>/scripts/make_palette.py "<hex>"` for the five
  uneven shades (near-black tint, deep, the color, soft, faint tint) and
  paste its CSS; see personalities.md > One color from the seller.
- Plain JavaScript in one file, no frameworks, no libraries, no CDN
  scripts. The only external file is the Inter font link, and the app
  falls back to the phone's own font without it.

For a big planner, build in passes: the shell and nav first, then one
section at a time, checking each pass.

### 4. Check on mobile

```bash
python3 <skill-dir>/scripts/embed_icons.py <planner>.html
python3 <skill-dir>/scripts/check_mobile.py <planner>.html --out mobile-check --block-fonts
```

Fix everything it reports, then look at the 375px screenshots yourself
(Read the PNGs, including the per-tab ones) for what a script can't
judge. Go through this list on every screen, because these are the
things a seller notices first:
- Left edges line up with the cards; no loose text rows between cards
  (totals belong in a `.summary-stats` strip).
- Even spacing above and below every field, strip and card; fields are
  48px with text centered.
- Text sits fully inside its card, tile, pill or ring, never under a
  checkbox or button, and numbers inside rings stay small relative to
  the ring (~17px in a 96px ring).
- Tap every tab: each active icon still shows.
- The personality reads the same on every screen (hero, colors, inputs,
  celebration), and the motion plays smoothly when you open each view.
- Icons and text look centered inside every button, and stacked icons
  sit right over their labels. Zoom into a 375px screenshot of the
  quick-add tiles and the first primary button on each screen.
- Dots, markers and icons sit centered on the lines and tracks they
  belong to (timelines, progress steps), and icons sit level with the
  capital letters of the text beside them. Zoom into the listing
  photos too, since buyers view them enlarged.
- Numbers in the same group share one format (all whole or all cents).
- Every entry's full text is readable without opening an edit form
  (expandable cards show all fields, `white-space:pre-wrap`, nothing
  clipped to one line). A competitor's review complained that entries
  were "condensed and only fully visible in edit mode".
- Awkward wrapping, cramped or unbalanced cards, or a view whose first
  screen doesn't show its most important thing.

Re-run until it reports 0 problems. Also test the real flows once at
375px: add an item in each module, complete one, delete and undo,
export, reload and confirm the data is still there. If the planner has
a timer, also test it with the clock moved forward while the page is
hidden (Playwright `page.clock`) and across a reload.

### 5. Write the Etsy listing

Follow `references/etsy-listing.md`: 2–3 title options with character
counts, 13 tags each ≤20 characters with counts, and the full
description, all from what the planner actually contains.

Choose the words from evidence, not instinct:
- From the step 1 listings, collect their titles and their real tags
  (`search_etsy` and `get_listing` return all 13 tags; pull 30–50 top
  listings for the main phrase), and count which phrases repeat across
  shops, weighting listings with more views and favorites. Phrases used by several reviewed
  listings are what buyers search; build the title's lead phrase and
  most tags from those. Phrases nobody uses are long-tail extras, at
  most 2–3 tags.
- Cover different searches across the 13 tags (product phrase,
  synonyms, audience, format, key modules, gift angle) instead of
  repeating one phrase.
- Never copy a competitor's title wording, and never use brand or
  trademarked names.
- If the seller pastes keyword data from a tool like eRank or EverBee,
  that wins: lead with the highest-volume relevant phrases.
- At the end of the listing file, add a short "Why these words" note:
  the phrases that repeated across competitors and how many listings
  used each.

**Price (the seller's full prices).** Every listing has a full "real"
price, and the seller runs Etsy sales on top of it (a 25% launch sale
through Nov 18, 2026, then holiday sales), so buyers see the full price
crossed out. Put the FULL price at the top of the listing file as
`PRICE: $X.XX full (sale price at 25% off: $Y.YY)`, never the sale price,
and never mention a discount inside the description itself (Etsy shows
it). Current full prices:

| Listing | Full price |
|---|---|
| ADHD Life Planner (14 modules) | $14.99 |
| Soap Business Planner | $13.99 |
| ADHD Budget Planner | $13.99 |
| ADHD Paycheck Budget Planner | $13.99 |
| Homeschool Planner | $12.99 |
| 3D Print Pricing Calculator | $12.99 |
| ADHD Study Planner | $11.99 |
| Student Nurse Planner | $11.99 |
| Christmas Gift Tracker | $11.99 |
| Coin Collection Tracker | $11.99 |
| Workout Tracker | $11.99 |
| Side Hustle Income Tracker | $9.99 |
| Job Search Tracker | $9.99 |
| GLP-1 Tracker | $9.99 |
| Pantry & Food Inventory Tracker | $9.99 |
| College Application Tracker | $9.99 |
| Cross Stitch Thread Tracker | $11.99 |
| Diamond Painting Tracker | $11.99 |
| Nail Polish Collection Tracker | $9.99 |

For a new planner, place it on this ladder by how much it does: $9.99
for a simple single-purpose tracker, $11.99 for a full planner with
several modules, $12.99–13.99 for a business app with real calculators
(pricing engine, lye or cost math, file imports), $14.99 for a very
large all-in-one (15+ modules). Keep it above the $3–6 spreadsheet and
PDF listings from the niche check; the sale is what makes it
competitive. Bundles of 3–4 related apps go at $19.99–24.99 full. Add
each new planner to this table in the next skill update.

Save everything as `<planner-slug>-etsy-listing.txt`, ending with a
"Design" line naming the personality and swaps, so later fixes and new
planners can keep the shop varied.

### 6. Make the listing photos

Read `references/listing-photos.md`. Plan a shot list for this
planner's own buyer and strongest features (don't reuse another
planner's), write `photos.json`, render with
`scripts/make_listing_photos.py`, fix any WARNING it prints (devices
off-canvas or overlapping text), then look at every image and fix
anything weak before sending. Headlines and bullets must match the
listing description and only claim what the planner does.

**Photo 2 is always a comparison photo (the seller's rule).** Every
listing gets a `"type": "comparison"` slide as the SECOND slide (rank 2,
right after the hero): "More than a <alternative>" with the alternative
highlighted, the sub "It does the work a <alternative> can't.", and a
table of 6 rows comparing the alternative's column (grey tick or grey x)
with a THIS APP column (ticks in the planner's main color), next to one
tilted phone. Pick the alternative the buyer would really use instead
(printable chart for marker/color trackers, spreadsheet for money,
business and job trackers, paper planner or notebook for planners and
logs, notes app for collection lists). Row 1 is something both can do
(grey tick); rows 2–6 are features only the app has, taken from the
listing description. See `references/listing-photos.md` > Comparison
slide.

**The look (the seller's chosen default for every listing).** Real 3D
devices rendered with three.js on a soft blurred-gradient background:
- A jet black phone with Pro Max proportions, smooth continuous
  corners, a flat side band with one crisp machined chamfer, raised pill
  side buttons with the same cut, and thin antenna lines. It sits tilted
  in perspective with a soft shadow; each layout sets its own angles.
- On the `desktop` slide, a matching jet black 3D laptop (keyboard,
  trackpad, notch) with the 3D phone standing in front of it.
- The background is four large blurred glows in the planner's colors
  (main color bottom left, paler tint middle, warm peach right, faint
  tint top right) with a faint dot texture behind the devices; no flat
  shapes.
- Spec options: `"finish"` (`jet` default; `graphite`, `titanium`,
  `silver`, `black`) and `"glow"` (four colors, to hand-pick the
  background, e.g. pinks and peach for a Christmas planner). The defaults
  come from the palette; check the background reads as the planner's
  color, not muddy, and hand-pick `glow` if it doesn't.
- Rendering uses software WebGL: about 20–40 s per slide, so a full
  set takes several minutes. Run it in the background for a full set.
- `--flat` gives the old flat CSS frames only if the 3D page can't load.
- The phone's shape was tuned with the seller against a real product
  photo (corner radius 22% of the width, superellipse n = 3.5, cut
  edges). Don't round, square or soften it; if a change is ever asked
  for, render a side-by-side zoom against the reference first.

**Headline highlight = the planner's main color (the seller's rule).** The
emphasized words on every listing photo AND every pin use the planner's
main theme color, so photos and pins match each other and the app. Give
`photos.json` and `pins.json` the same `"palette"` (with the planner's
`main` color) and the scripts use `main` for the highlight automatically.
Don't set `"accent": "terracotta"` or `"sage"` on a planner with its own
palette (that once gave a rose planner orange headlines). Only if `main`
is too pale to read, set `"highlight_color"` to the palette's deep shade.
Check one photo and one pin side by side before sending.

**+50 saturation (the seller's rule).** Every listing photo and pin is
saved with a color boost of 1.5 (+50 saturation) so it pops in Etsy
search thumbnails. Both scripts do it by default; `"saturation": 1.2` in
the spec (or `--saturation 1`) changes or turns it off for one planner,
and `make_listing_photos.py --keep-original` also saves the un-boosted
images in `<out>/original/` for a before/after.

Two things the script gets wrong by default (both also apply to pins):
- **A round add button docked beside the nav** (Bold's dark pill with
  the orange + beside it) is part of the navigation, and the photo
  looks broken without it. The script hides every `.fab` unless the
  slide sets `"hide"`, so put `"hide": []` on every slide and pin (and
  on view objects in `hero` / `two-phones`) whenever the planner's add
  button sits next to the nav. Keep the default only for a button that
  floats over the content.
- **Scrolled screens need room at the top.** `scroll_to` lands the
  bare element 72px down, which leaves a sliver of the card above
  peeking under the status bar and can cut the target card's own
  title. Instead, scroll the whole card to 16px below the top (the
  gap between cards, so nothing of the card above shows) with `js`
  (and no `scroll_to`):
  `"js": "var b=document.querySelector('#break-seg').closest('.panel'); window.scrollTo(0, b.getBoundingClientRect().top + scrollY - 16)"`.
  Every phone screen in the set should open with a clean gap above
  its first card; look for this on every `two-phones` slide.

### 7. Make the Pinterest pins

Read `references/pinterest.md`. Plan 5 pins, each aimed at a different
Pinterest search (the product, its main pain, a tips list, a second
feature, a niche moment), write `pins.json`, and render:

```bash
python3 <skill-dir>/scripts/make_pins.py <planner>.html pins.json --out pinterest
```

Pins use the same 3D devices, `"finish"`, `"glow"` and `--flat` as the
listing photos. It makes 1000x1500 (2:3) pins at 2x plus `pinterest-pins.txt` with each
pin's title (max 100), description (max 500), alt text and board. Fix
every WARNING (text crowding the phones, over-length text), then look at
each pin as a small thumbnail and at full size. Use the same `"hide": []`
and card-scroll `js` as the listing photos (step 6).

The `list` (tips) pin's defaults put the peeking phone right against the
last tip card. Give it breathing room: set `"list_top": 360` and
`"peek_bottom": -500` for 5 tips (a 4-tip list can use `-460`), then
check the gap between the last card and the top of the phone is at
least 48px at full size.

### 8. Make the buyer download (always)

Every planner ships to buyers as a zip of the HTML plus a 2-page
"Start Here" PDF, so nobody is left wondering what to do with the file.

1. Copy `assets/start-here-template.html` and fill it for this planner:
   the `__FILE_NAME__` / `__TITLE_HTML__` / `__PLANNER_NAME__`
   placeholders, the quick tour (one line per real tab, in nav order) and
   at most one extra planner-specific FAQ. Keep the backup warning and the
   "move to another device" steps: those prevent most support messages.
2. Opening steps: if the seller has told you how their buyers open the
   file on phones, use exactly that. Otherwise keep the template's general
   phone steps and tell the seller to try it on their own phone before
   uploading. Never invent app names or steps you haven't verified.
3. Run
   `python3 <skill-dir>/scripts/make_buyer_package.py <planner>.html start-here.html --name "<Planner Name>"`.
   It renders the PDF, refuses if a page overflows or a placeholder is
   left, and zips `<Planner Name>.html` + `Start Here - <Planner Name>.pdf`.
   Look at both PDF pages (render them to PNG and Read them) before sending.
4. **Background = the listing photos' look (the seller's default).** The
   guide uses the same soft blurred glows and faint dot patch as the
   listing photos, so the download matches the listing. Set the four
   `--glow1..4` colors at the top of the template's `<style>` to the
   planner's glows: the spec's `"glow"` if you hand-picked one, otherwise
   `python3 -c "import sys; sys.path.insert(0,'<skill-dir>/scripts'); from make_listing_photos import default_glow; print(default_glow({'main':'<main hex>'}))"`.
   Also switch the template's sage/terracotta accents (eyebrow, step
   numbers, `h1 em`, tips) to the planner's palette. The glows are CSS
   gradients, so the PDF stays sharp and small; check them on the PNG
   render (soft color at the bottom corners and top right, never muddy).

Listing photos and the listing text never go in the buyer zip; send
photos as their own zip.

### 9. Publish to Etsy (connector) and deliver

If the Etsy connector is connected (tools named like
`*__create_draft_listing`, `*__upload_listing_photo`,
`*__upload_download_file`, `*__update_listing`, `*__find_category`;
ToolSearch "create_draft_listing" if deferred), put the listing on the
shop instead of only handing over files. Its write tools refuse to run
without `confirm: true`, which may only be sent after the seller's OK.

1. **Ask once for the whole draft.** In one message show: the chosen
   title, the 13 tags, the FULL price, the category path, the photo
   order (thumbnails already sent), and the buyer zip name. One "yes"
   covers creating the draft and all uploads. If he gave a title choice
   or edits, use those.
2. **Create the draft:** `find_category` (e.g. "planner" or
   "calendars") to pick the taxonomy_id, then `create_draft_listing`
   with title, the full description, tags, the FULL price (never the
   sale price), quantity 999, who_made "i_did", and confirm true. If Etsy
   rejects a field (e.g. `when_made`), read its error, fix the value and
   retry once.
3. **Upload the photos** in shot-list order with `upload_listing_photo`
   (`image_base64` from the +50 saturation files, rank 1 = hero, up to
   10, alt_text = a short plain description). Re-check the saturation
   rule before uploading.
4. **Attach the buyer zip** with `upload_download_file` (`file_base64`
   of the step 8 zip, `name` = `<Planner Name>.zip`).
5. **Check it:** `get_listing` on the draft and confirm the title, tags,
   price, photo count and order match. Then give him the draft's link to
   look over on Etsy.
6. **Go live only on a second OK:** when he says publish, call
   `update_listing` with `state: "active"` and confirm true. Never
   publish in the same step as creating the draft.

If an upload fails because the file is too big or the connector is down,
say so in one line and fall back to delivering that file.

Then deliver as before: the buyer zip, the listing text file, the photos
(a zip is enough when they're already on Etsy; otherwise individually in
upload order plus a zip), and the pins with `pinterest-pins.txt`. In the
reply, say in a line or two what's in the planner, which personality it
uses, its full price, that it passed the phone check, and whether the
draft is on Etsy waiting for review, and offer TikTok videos: organic
clips (step 11, the default), a 3D showcase video (step 12), or the
cinematic promo video (step 10).

### 10. Make the promo video (hook + walkthrough)

The bigger, ad-style option: build it when the seller asks for a
cinematic or hook video, for a new planner or an existing one. For
everyday posting the seller prefers organic clips (step 11). Make two clips:
a 5–8s animated **hook** that shows the buyer's problem and a 15–25s
**walkthrough** of the real app in use. Both are 1080x1920, 60fps,
H.264, rendered frame by frame so motion is perfectly smooth. The seller
stitches them in CapCut, adds their own music and sound effects, and
ends with the shop's existing "Search LucianVoxDesigns on Etsy" end card,
which they reuse on every video. Don't make a new end card unless they
ask for one.

#### 10a. Ask about the vision first (always, in rounds)

The seller has a picture in their head; get it out before building,
because a render takes 10–20 minutes. Use AskUserQuestion, up to 4
questions per call, in as many rounds as needed (usually 2). Put the
best fit first with "(Recommended)", give each option a one-line
description, and use `preview` to show draft hook lines or a storyboard
in words. Build follow-up questions from the answers: a short answer
means "you pick", a typed answer is the vision, so ask about the
details it opens up. If no one answers, take the recommended options and
say so. Cover:

- **Round 1: the hook.**
  - The pain the hook shows, drafted from the niche report's complaints
    (e.g. a messy spreadsheet, sticky notes everywhere, a pile of
    receipts, a forgotten deadline). Offer 3 concrete scenes.
  - The hook text: 2–3 drafted versions of a question line plus 2–3
    pain lines plus a turn line ("There's a better way."). The seller
    may read it as a voiceover, so it must sound spoken.
  - The style: **Flat motion** (2D type and shapes, fastest, ~2 min
    render), **3D hero object** (one three.js object for the niche: a
    coin, a notebook, a pill bottle, a calendar; ~10 min), or
    **Cinematic 3D** (adds bloom, depth of field, film grain, physics;
    ~20 min).
  - The hand-off from the hook into the app (the hero object shrinks
    into its tab, a page-turn, a hard cut on a beat).
- **Round 2: the walkthrough.**
  - Which features to show (multiSelect), in story order: the one big
    number first, then add an item, then the satisfying moment
    (completion, celebration, streak), then the "does the math for you"
    feature, then back home with the number changed. Show features, not
    a tour of tabs.
  - Length (aim for 25–30s for hook plus walkthrough, so the 4s end
    card lands it near 30–35s) and pace (calm vs snappy holds).
  - The sample data shown: realistic and specific to the buyer.
  - Audio is the seller's: they add music and sound effects. If they ask
    for a voiceover script, write natural sentences describing the
    product, not ad fragments or "I built this".

Then send a 4–8 still storyboard (Read your preview PNGs, send a contact
sheet) before the full render, and render only after a yes.

Never draw or place Etsy's (or any brand's) logo or a lookalike in a
video, even from a file the seller supplies.

#### 10b. Environment facts

- npm and most websites are blocked; GitHub works. Get libraries with a
  sparse clone, never a CDN:
  `git clone --depth 1 --filter=blob:none --sparse -b r165 https://github.com/mrdoob/three.js`
  then `git sparse-checkout set build examples/jsm/postprocessing examples/jsm/shaders examples/jsm/environments`
  (three.js MIT); GSAP 3 + SplitText from `github.com/greensock/GSAP`
  (`dist/gsap.min.js`, `dist/SplitText.min.js`, free); cannon-es from
  `github.com/pmndrs/cannon-es` (`dist/cannon-es.js`, MIT). Remotion
  isn't needed (and can't install): the same idea is done by hand below.
- ES modules need http: run `python3 -m http.server 8765 --bind 127.0.0.1`
  in the video folder with `run_in_background` (background processes stop
  after 2 hours; restart before a new render).
- WebGL in headless Chromium: launch with
  `args=['--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader']`.
- Fonts: copy the planner's embedded `@font-face` block into `fonts.css`
  so the video uses the app's type.
- Work in a `video/` folder next to the planner.

#### 10c. Hook: a page that is a pure function of time

Write `hook.html` at a 390x693 stage. Everything on screen is set by
`window.renderAt(t)` from `t` alone (no timers, no CSS transitions, no
`Math.random` at render time; use a seeded generator), with a global
`DURATION`. Capture every frame at 3x and encode:

```python
from playwright.sync_api import sync_playwright
with sync_playwright() as p:
    b = p.chromium.launch(args=[...WebGL flags...])
    pg = b.new_page(viewport={'width':390,'height':693}, device_scale_factor=3)
    pg.goto('http://127.0.0.1:8765/hook.html'); pg.wait_for_function('window.ready===true')
    for i in range(start, end):
        pg.evaluate(f'renderAt({i/60})')
        pg.evaluate("() => new Promise(r => requestAnimationFrame(() => requestAnimationFrame(r)))")
        pg.screenshot(path=f'frames/{i:05d}.jpg', type='jpeg', quality=94)
```
`ffmpeg -framerate 60 -i frames/%05d.jpg -vf "scale=1080:1920:flags=lanczos,format=yuv420p" -c:v libx264 -crf 16 -preset slow -movflags +faststart hook.mp4`

Split long 3D renders across 2 processes by frame range and merge the
frame folders. Render 6–8 preview stills first (`renderAt` at chosen
times, PNG) and Read them; fix framing and timing before the full run.

**No one-frame flickers.** A word that vanishes for a single frame is
a capture glitch, not the animation: with GPU layers (3D transforms)
under heavy load, a screenshot can grab a layer before it has been
painted (the 3D print calculator hook's "did you" vanished at frame 68 and came
back on 69; re-rendering that frame alone was perfect). Three rules:
- Build GSAP timelines with `defaults: { force3D: false }` so text and
  DOM elements animate with 2D transforms in the main layer instead of
  each getting its own GPU layer. Don't add `will-change` or
  `translate3d` to text either.
- After every `renderAt(t)`, wait two animation frames before the
  screenshot, so every layer is painted:
  `pg.evaluate("() => new Promise(r => requestAnimationFrame(() => requestAnimationFrame(r)))")`.
  (This is for the hook, which has no fake clock. In the 10d recorder
  the clock is paused, so rAF never fires there: use a real 20ms wait.)
- After rendering, scan the frames for one-frame glitches: a frame
  whose biggest local change (8x8 blocks of a 130x231 grayscale
  thumbnail) against BOTH neighbours is more than 1.8x the neighbours'
  change against each other, plus 8. Re-render any flagged frame on its
  own, rescan, and only encode when the scan reports none. Run the same
  scan on the walkthrough frames.

```python
img = lambda f: np.asarray(Image.open(f).convert('L').resize((130, 231)), dtype=float)
blk = lambda x, y: np.abs(x - y)[:224, :128].reshape(28, 8, 16, 8).mean(axis=(1, 3)).max()
for i in range(1, len(fs) - 1):
    p, c, n = img(fs[i - 1]), img(fs[i]), img(fs[i + 1])
    if min(blk(c, p), blk(n, c)) > 1.8 * blk(n, p) + 8: bad.append(i)
```

**Revisions: re-render only the frames that changed (frame cache).**
A full cinematic render takes ~20 minutes; a change to one line of text
shouldn't. Set the hook up for caching from the start:
- In `hook.js`, wrap the whole three.js section in `// ==== 3D:START`
  and `// ==== 3D:END` comments, skip the GPU render when
  `window.DRY` is set (`if(!window.DRY) composer.render();`), and
  expose `window.state3d()`: `'off'` while the 3D canvas is hidden,
  otherwise a JSON of what the 3D layer shows (canvas opacity, object
  visibility, position, rotation, scale, particle opacity, time).
- Render through a `render_cached.py` that keeps a `manifest.json`
  (frame number to fingerprint) next to the frames:
  1. Fingerprint pass in one page, no screenshots (~25s for 430
     frames): `window.DRY = true`, then for each frame `renderAt(i/60)`
     and collect (a) the *visible* DOM of `#stage`, walked recursively,
     skipping any element whose computed `display` is none,
     `visibility` hidden or `opacity` 0, keeping tag, id, class, inline
     style and text; (b) `state3d()`; (c) the handoff layer's opacity.
     Fingerprint = sha1 of (a) + (b) + the 3D code hash (only when (b)
     isn't `'off'`) + a hash of the page's `<style>` blocks and
     `fonts.css` (styles only, never the page text, or every frame
     changes) + the `handoff.jpg` hash (only while the handoff is
     visible).
  2. Render only frames whose fingerprint differs from the manifest or
     whose JPG is missing, split across 2 workers (the frame-list mode
     of the renderer, with the paint wait).
  3. Run the one-frame glitch scan on the whole folder, re-render any
     flagged frame, rescan, then write the new manifest.
- For the first render, run it normally (everything renders). If
  frames were rendered before the cache existed, a `--seed` run writes
  the manifest from the current code without rendering.
- Measured on the 3D print calculator hook: changing "real price" to
  "true price" re-rendered 92 of 432 frames (the ones showing that
  line) in 8 minutes instead of 20; a change to early 2D text is
  faster still, since 2D frames render quickly and the 3D frames are
  reused. A change inside the 3D section re-renders every frame where
  the 3D layer shows.
- Walkthrough recordings aren't cached: they take only a few minutes,
  so re-record the whole walkthrough after an app change.

Craft that made the coin tracker's hook work:
- **Scene 1, the pain:** the problem drawn in HTML/CSS (e.g. a cramped
  spreadsheet with red error cells) under the question line, set in the
  app's display font with a SplitText character cascade and one word in
  the accent color with an underline sweep. A GSAP timeline built paused
  (with `force3D: false`) and scrubbed with `tl.seek(t, false)` inside
  `renderAt`.
- **Pain lines** rise in word by word (masked lines), then a **building
  camera rumble then a jolt** on the stage: a shake whose amplitude
  eases in for ~0.8s (sums of sines at 41–89 Hz, a few px and a fraction
  of a degree), then one big hit that decays with `exp(-9k)`.
- **Scene 2, the chaos:** cannon-es physics simulated once at load
  (fixed 1/240 step, positions recorded every 1/60) and replayed by
  frame, so it's deterministic. Niche objects pour in (coins with "?" on
  one face and a value on the other). Put any symbols on the objects
  themselves, never as floating badges (they flicker).
- **Scene 3, the turn:** "There's a better way." blurs in while the hero
  object rises in three.js. Materials: `MeshPhysicalMaterial` with
  canvas-drawn bump and roughness maps (raised design frosted, field
  mirror), a custom PMREM studio environment (dark warm room plus
  softbox planes, since a bright room washes metal to white), a point
  light that sweeps for a glint, additive-blended dust particles.
  Cinematic: `EffectComposer` with `UnrealBloomPass` (threshold ~0.9,
  strength 0.3–0.5), `BokehPass` focused on the object, and a lens
  `ShaderPass` (slight chromatic fringe, vignette, film grain).
- **The hand-off:** the spin decelerates naturally to rest,
  `(1-(1-p)^2.4)*turns`, never snapping to face the camera, then the
  object shrinks and drops into its spot in the app on a damped spring
  from rest, `1 - e^(-zwt)(cos(wd t) + (zw/wd) sin(wd t))` with w≈8.5,
  z≈0.62, while the first walkthrough frame (the app's home screen, saved
  as `handoff.jpg`) fades in under it. Overshoot spring for pop-ins:
  `1 - e^(-6p)cos(9.5p)`.
- Keep text and key action in the upper two thirds (TikTok's UI covers
  the bottom and right).

#### 10d. Walkthrough: frame-exact capture of the real app

Record the planner itself (`?sample=1` sample data) at 390x693, dpr 3,
`is_mobile=True`. Let the JS run on Playwright's fake clock and slow CSS
animations with CDP, so every frame lands at an exact moment no matter
how long a screenshot takes:

```python
FPS=60; FMS=1000/FPS; RATE=0.08; REAL=FMS/RATE/1000
ctx.add_init_script(TAP)   # pointerdown -> a 46px soft circle that scales up and fades (tap indicator)
pg = ctx.new_page()
t0 = datetime.datetime.now().replace(microsecond=0)
pg.clock.install(time=t0); pg.clock.pause_at(t0 + datetime.timedelta(seconds=1))   # PAUSED: time moves only with run_for
cdp = ctx.new_cdp_session(pg); cdp.send('Animation.enable')
cdp.send('Animation.setPlaybackRate', {'playbackRate': RATE}); pg.goto(URL)
acc = 0.0; nxt = time.perf_counter()
def frame(cb=None):
    global acc, nxt, n
    if cb: cb()
    acc += FMS; step = int(acc); acc -= step; pg.clock.run_for(step)   # run_for needs integer ms
    now = time.perf_counter()
    if now < nxt: time.sleep(nxt - now)                                  # let slowed CSS advance one frame
    nxt = max(nxt + REAL, time.perf_counter())
    pg.wait_for_timeout(20)                                              # real ms for the compositor, not a rAF wait
    pg.screenshot(path=f'frames/{n:05d}.jpg', type='jpeg', quality=92); n += 1
```
**Pause the fake clock.** `pg.clock.install()` on its own keeps the page's
clock running in real time *on top of* `run_for`, and real time races
ahead while screenshots are taken (about 3s of page time per 0.25s of
video). Every `setTimeout` then fires far too early: the app's toasts
("Cut! Curing until Nov 13") flash for a few frames and vanish, delayed
re-renders land early, timers jump. Always install with a start time and
`pause_at` it, so page time advances only through `run_for`, exactly one
frame per frame. With a paused clock, `requestAnimationFrame` is faked
too and only fires inside `run_for`, so never `await` a rAF promise
before a screenshot (it hangs forever): wait a real `pg.wait_for_timeout(20)`
instead. Check once per new recorder: after a tap that shows a toast,
log `Date.now()` and the toast's presence every 0.25s of video; time
should step by 250ms and the toast should stay for its full ~3s.
Build the script from small helpers on top of `frame()`: `hold(sec)`;
`scroll_to(y, sec)` stepping `window.scrollTo` (or a sheet's `scrollTop`)
along easeInOutCubic so scrolls glide in and out; `tap(sel)` that first
eases the target into the middle of the screen if it's near an edge,
holds 0.12s, then `pg.mouse.click` at its center; `type_into(sel, text)`
one key per ~0.07s. Use `pg.select_option` for selects (a native picker
popup blocks screenshots). Script the story from 10a with holds long
enough to read each moment (~1–1.5s on payoffs, 2.5s on the opening
number). Encode with the same ffmpeg line. Save frame 0 as `handoff.jpg`
for the hook. Watch for the app's own toasts or modals covering the
action, and use `?view=` only when the cut is intended.

#### 10e. Deliver

Send `<slug>-hook.mp4` and `<slug>-walkthrough.mp4` with one line on
how they stitch (hook, walkthrough, then their usual end card; the
hook's last frame matches the walkthrough's first). Offer a caption (one
line that answers the hook's question, plus "Search LucianVoxDesigns on
Etsy") and 5–6 niche hashtags (the hobby's own tags plus one shopper tag
like #etsyfinds; skip #fyp). Remind them to pin a comment with the shop
name.

### 11. Make organic TikTok clips (the default video)

The seller found the cinematic video too "salesy" for a new account and
prefers short, organic clips he can post 3–5 times a week: one simple
moment in the app plus a relatable caption he adds as text in CapCut.
You become the buyer: the clip should look like a fellow hobbyist
screen-recorded their own phone, not like an ad. No hook, no end card,
no "search my shop" in the video.

**Plan the batch.** Default: 3 clips, 8–9s each, screen recordings
with soft tap circles, captions in the voice of a fellow buyer (e.g. a
3D-print seller: "me finding out what my $12 dragons were actually
making me"). Ask with AskUserQuestion only if the seller hasn't said:
which product, how many, footage style (plain screen recording, with
tap circles, or he films his own phone and you only write captions and
a shot list) and caption voice (fellow buyer, POV scenario, or a mix
with quick tips). Pick angles from the niche report's pains: each clip
is ONE action whose result makes the point, with real numbers from the
app's sample data. The 3D print calculator batch:
- "The $12 dragon": type $12 into "What if I list it at…", see
  "You keep $2.73".
- "The quick favor": import a 9h 41m helmet G-code, the real price
  appears.
- "The fees": switch In person to Etsy, the price jumps to cover fees.
The soap business planner batch: "$5 bars" (cost per bar $3.29, type
$5, Etsy profit drops to $0.79, wholesale goes red), "the cure" (tap
Cut into bars, "Curing until Nov 13", 26 days left), "market day" (five
taps on Market day tiles, the total climbs to $42).

**Record** with the 10d frame-exact recorder (paused fake clock, slowed
CSS, 2D only), with these changes so it feels like a real thumb, not a bot:
- Set up off camera, then start saving frames: load `?sample=1`, do any
  setup clicks (reset, pick a channel, scroll to the start card), and
  hold 2.5s before the first saved frame so every entrance animation
  (`.rise`) has finished. Otherwise buttons are still fading in.
- Unhurried pacing: open on the screen for ~1.8s, scrolls ~1.3s with
  easeInOutCubic, a 0.4–0.5s pause before a tap, typing ~0.24s per
  key, and ~3s holding on the result.
- Soft taps, not instant pops: inject a touch indicator (init script)
  with `show(x,y)` (a 48px circle fades in from scale 1.25 to 1 over
  ~0.25s), `press()` (scales to 0.82 and darkens over 0.14s) and
  `release()` (scales to 1.5 and fades out over ~0.65s). Per tap: show,
  hold 0.32s, press, hold 0.14s, click, release. For a file picker, do
  the click inside `expect_file_chooser()` between press and release.
- Pause the fake clock and wait a real 20ms before each screenshot (see
  10d). Without the pause, toasts and anything on a `setTimeout` vanish
  almost instantly on camera.
- Look for jumps in the app itself, not just the recording. A tap that
  re-renders the whole view replays every `.rise` entrance, so the screen
  "pops in" again; repeated taps (a counter, a stage button) must update
  only what changed in place (the tapped card, the total). Fix that in
  the planner, since buyers see it too, then rebuild the buyer zip.
  Also don't start a clip scrolled to the very bottom if the action makes
  the page shorter (a button disappears): the browser clamps the scroll
  and the whole list jumps. Start ~90px above the bottom.
- Make a contact sheet (one frame every ~0.75s) of each clip and look at
  it before encoding: toasts visible for their full time, no jumps, the
  payoff number on screen for the last ~3s.
- Run the one-frame glitch scan (10c) on each clip, and encode with the
  same ffmpeg line.

**Deliver** the clips plus `captions.txt`. For each clip, give 3
on-screen text options (lowercase, conversational, one line each, true
to what the clip shows), one post caption in the same voice, and 5
niche hashtags. Add these notes: put the text in the top third (TikTok's
buttons cover the bottom and right), use a trending sound quietly, and
when someone asks "what app is this?", reply that it's a calculator or
planner in the Etsy shop (LucianVoxDesigns), since the comment reply is
where the shop gets mentioned.

**Posting plan to share when asked:** 2–3 clips per new listing,
then move on unless one clip clearly beats the others; if it does, make
3–5 more variations of that winning angle. Keep older listings in
rotation (each week, 2–3 clips for the newest product plus 1–2
following up on the best performer). Judge clips after about 3 days,
compare angles rather than raw views, and reply to every comment.

### 12. Make a 3D showcase video

When the seller asks for a 3D video, a showcase, or "the 3D phone video",
read `references/3d-video.md` and follow it: ask the one round of
questions there (which video, style, length, features, end card), write
the spec, run `make_3d_video.py --stills` and show the storyboard, then
render in the background and deliver the MP4 with its contact sheet
checked. These are for TikTok and Instagram, so always vertical. The
organic clips (step 11) stay the everyday default; the 3D video is the
polished one for a launch, an ad or a pinned post. Offer the same three
caption extras as step 11 (on-screen text options, a post caption,
5 hashtags) when he asks for them.

## Working on an existing planner

When the user asks to add a module to, fix, or polish one of their
existing planners, edit their file in place in its own structure rather
than rebuilding it from the template, keep its personality (see the
"Design" line in its listing file or the comment atop its `<style>`;
older planners predate personalities, so keep their look unless the
seller asks to restyle), then run the mobile checker on it.
If the file still loads icons from the Material Symbols font, switch it
to embedded icons, because the font fails for first-time offline buyers
and on networks that block Google, and the icons then show as words like
"settings" across the bottom nav: replace its `.icon` CSS (and any
`icons-ready` / `.icon-fallback` rules) with the template's icon CSS,
replace its `icon()` helper and any `document.fonts` icon check with
the template's ICONS block (`svgIcon`, `icon`, `hydrateIcons`), call
`hydrateIcons()` at startup, then run `embed_icons.py` (it also removes
the font link).