# Mobile rules

Most buyers open these planners on a phone, and a planner that looks
broken in the first 10 seconds becomes a refund or a bad review. These
rules combine general mobile UI principles (thumb zone, tap targets,
8-point spacing, hierarchy, celebrating the peak moment) with the
specific ways single-file planners break on real phones.

## Hard requirements (the checker enforces these)

1. **No sideways scrolling, ever.** Design at 375px, verify at 320px
   (small Androids, iPhone SE zoomed) and 430px.
   - Every flex/grid child that holds text gets `min-width:0`.
   - Grids use `repeat(n, minmax(0,1fr))`, never bare `1fr` (bare 1fr
     lets a long number push the grid wider than the screen).
   - Long user text gets `overflow-wrap:anywhere`; one-line labels get
     `overflow:hidden; text-overflow:ellipsis; white-space:nowrap`.
   - Wide things (tables, calendars, pill filters) go inside a
     deliberate `overflow-x:auto` scroller, not the page.
   - Never set fixed pixel widths wider than ~280px on phone layouts.
2. **Tap targets ≥44×44px.** Small visuals are fine inside a bigger
   hit area (the template's `.check-hit` wraps a 30px checkbox in a
   44px button). Leave ≥8px between adjacent targets.
3. **Inputs, selects and textareas at 16px on phones.** iOS Safari
   zooms the whole page when you focus a field smaller than 16px, and
   the page stays zoomed and lopsided afterward. Drop to 15px only
   inside the desktop media query.
4. **Nothing hidden behind the fixed bottom nav.** `.main` keeps
   `padding-bottom: calc(120px + env(safe-area-inset-bottom))`; toasts
   and the FAB sit above the nav.
5. **Icons never show as words.** Icons are embedded SVG (run
   `scripts/embed_icons.py`), never the Material Symbols web font, which
   fails offline and on networks that block Google.
6. **No text cut off inside fields.** Inputs are 16px, so long
   placeholders and dropdown choices clip on phones. Keep placeholders
   to a few words ("Instructor", not "Instructor (optional)") and
   dropdown choices short ("Medium", not "Medium priority"). When a
   short choice needs context, put a visible label above the field with
   `<label class="field-col"><span>Priority</span><select>…</label>`.
   Paired fields in `.form-row-2` stack automatically below 360px.
7. **Form fields are 48px tall with centered text.** The template sets
   a fixed `height:48px` with zero vertical padding and `appearance:none`
   (one consistent chevron on dropdowns), because native padding and
   dropdown styling render differently on Android and iOS and leave text
   sitting low in the box. Never override field height or padding per
   screen. Paired fields stack below 360px (`.form-row-2`), and stacked
   children must not flex-shrink (the template handles this).
8. **Text stays inside its shape.** Nothing may spill out of a card,
   tile, pill or ring. A progress ring's center holds one short value
   ("74%") and a one-word label; longer detail ("$20,476 of $20,000")
   goes in `.donut-detail` below the ring.
9. **Safe areas.** `viewport-fit=cover` in the meta tag, and
   `env(safe-area-inset-*)` padding on the header, bottom nav and sheets
   so nothing sits under the iPhone notch or home bar.

## Polish rules (what makes it look professional)

- **No loose text rows between cards.** Totals or counts above a list go
  in a `.summary-stats` strip (aligned label/value cells, 2 columns on
  phones, 4 with `.cols-4` when the screen is wide), not a line of
  inline text, which wraps unevenly and doesn't line up with the cards.
- **Even rhythm around controls.** Stacked filters/controls above a list
  sit in `.filter-stack` (12px gaps), then the summary strip, then the
  list card, each 16px apart. Never a field pressed against the next.
- **One number format per group.** Within one strip, card or row group,
  use the same decimals: all whole amounts ("$3,405 · $0 · $120") or all
  with cents, never a mix like "$3,405 · $0.00 · $120.00".
- **Left edges line up.** Everything in a view starts on the same 16px
  gutter as the cards; nothing floats at its own indent.
- **Every view uses the same vertical rhythm**: title, then 16px, then
  the first card. Check the top and bottom spacing of each screen in the
  screenshots, not just the middle.

## Modern responsive techniques (built into the template)

- **Dynamic viewport units.** Full-height things use `100dvh` with a
  `100vh` fallback, so sheets and the sidebar aren't hidden behind mobile
  browser bars. Never use bare `100vh` for something that must fit.
- **Container queries.** Every `.view` is a size container
  (`container-name: view`). Make component layouts respond to the space
  they get with `@container view (min-width: …)` instead of viewport
  media queries, e.g. stat tiles 2 → 4 columns, badges 3 → 2 columns on
  very narrow screens. Keep a sensible phone layout as the default so
  older browsers still look right.
- **Fluid type.** `--text-lg` and `--text-xl` use `clamp()` so headings
  scale smoothly between phone and desktop while staying within the four
  type sizes.
- **Content-based breakpoints.** Phone base styles, a 600px tablet step
  (wider gutters, centered 760px column, inline button rows) and the
  900px desktop sidebar. Add a breakpoint only where content breaks.
- **User preferences.** `prefers-reduced-motion` (no animations) and
  `prefers-contrast: more` (darker text and borders) are both honored.
- **Wide content scrolls inside its own box** (`overflow-x:auto` wrapper)
  and long tables become row lists on phones.

## Layout patterns

- **Bottom nav: 5 items max.** Six cramped labels at 320px is the
  limit of legibility. With more sections than that, group them (see
  "Many modules" below) or move Settings behind a header gear button.
  Labels short: one word ("Tasks", not "Assignments").
- **Thumb zone.** Primary actions in the lower part of the screen or
  full-width in the content flow. Bottom sheets (`.sheet`) instead of
  centered modals on phones; the template's `.overlay` already does this.
- **Stack, don't squeeze.** Button groups stack full-width on phones
  (`.btn-row`, `.modal-actions`), side by side on desktop. Two-column
  form rows only for short paired fields (date + time, amount + category).
- **One thing first.** Each view opens with its most important element
  (the "right now" card, today's total, the next due item). Forms that
  are used occasionally go in a `.disclosure`.
- **Lists over tables.** On phones, render records as `.row-list` rows
  or cards; a real table only if it lives in a horizontal scroller.
- **Calendars/week grids**: 7 columns inside the normal 16px gutters
  are only ~38px each at 320px, under the 44px minimum. Below 360px let
  the row run edge to edge (negative side margins, gap 0, borderless
  cells) so each day gets ~45px. Show dots for "has entries" and a list
  of the selected day below, rather than text inside cells.

## Many modules (15–25 modules from a competitor list)

Don't make 20 nav items. Group modules into 4–5 sections (the ADHD Life
Planner used Home / Finance / Organize / Wellness). Bottom nav = Today
plus the sections, or the sections plus Settings. Each section view is
a `.module-grid` of `.module-card`s (icon, name, one live stat like "3
due"). Tapping opens the module view with a `.back-btn` to its section.
Today/Home pulls the most urgent items from all modules into one place.

## Polish

- Hierarchy through size, weight and opacity, max 4 sizes / 2 weights.
- Values bigger than labels.
- Empty states always say what to do next.
- Peak-end moments: confetti on completion, a streak or "wins" log, a
  kind line when everything is done.
- Respect `prefers-reduced-motion`.

## Verify, don't assume

Run `python3 scripts/check_mobile.py planner.html --block-fonts` and look
at the screenshots it saves. It visits every view and every in-view tab
(buttons whose `data-action` ends in `-tab`, e.g. `data-action="ins-tab"`),
so always use that naming for tabs inside a view, or the checker can't
reach them. The script catches measurable problems;
the screenshots catch the rest (awkward wrapping, cramped cards,
unbalanced spacing). Fix and re-run until it reports 0 problems.
