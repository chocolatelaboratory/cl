# Pinterest pins

Pinterest is a search engine people browse months ahead of a need, so a
pin made today keeps sending traffic to the Etsy listing for a long time.
Every planner gets 5 pins, each aimed at a DIFFERENT search a buyer makes,
not five versions of the same ad.

## Format
- 1000x1500 (2:3), Pinterest's recommended ratio. Taller pins get cut off
  in the feed. `scripts/make_pins.py` renders at 2x (2000x3000).
- Big headline at the top (readable as a small feed thumbnail), phones in
  the middle, 2 short badges + "Instant download on Etsy" + the shop
  wordmark at the bottom. Unlike Etsy listing photos, pins carry the shop
  name: a pin gets saved and shared far from the shop, and the wordmark is
  how people find their way back.
- Layouts: `hero` (3 phones), `phone`, `two-phones`, `list` (a tips
  checklist with a phone peeking up from the bottom). All use the same
  3D jet black phones and blurred-gradient background as the listing
  photos (`"finish"` and `"glow"` work the same way).

## Plan the 5 pins around search intent
Think of what the buyer types into Pinterest, which is usually a problem
or a how-to, not the product name:
1. The product itself ("job application tracker", "nursing student planner").
2. The biggest pain the planner solves ("when to follow up on a job application").
3. A tips/how-to pin using the `list` layout ("4 habits of an organized job
   search"). Tips pins get saved the most. Every tip must be true advice
   AND something the planner does.
4. A second feature angle ("interview prep checklist", "STAR method").
5. A niche moment ("how to compare two job offers").

- Headline highlight: the planner's main theme color, the same as the
  listing photos (see listing-photos.md). Use the same `"palette"` in
  pins.json as in photos.json.

## Writing
- Title: max 100 characters. Lead with the search phrase, written like a
  helpful headline, not a keyword pile.
- Description: max 500 characters; the first ~55 show in the feed, so open
  with the hook. Use 2-3 search phrases naturally, describe what the pin
  shows, end with what the app does. No hashtags, no brand names you don't
  own, no claims the planner can't back up.
- Alt text: describe the image plainly (it also helps Pinterest search).
- Board: suggest a topic board per pin (e.g. "Job Search Tips", "Interview
  Tips"). Topic boards rank better than a board named after the shop.

## Posting advice to pass on
- Link every pin to the Etsy listing.
- Post one new pin every few days rather than all at once; Pinterest favors
  steady fresh pins.
- Results build over 2-6 months; that's normal.
