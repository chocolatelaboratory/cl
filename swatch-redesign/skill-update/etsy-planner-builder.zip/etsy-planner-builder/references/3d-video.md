# 3D showcase videos (TikTok / Instagram)

`scripts/make_3d_video.py` puts the real planner on the same jet black 3D
phone as the listing photos and cuts it into a short vertical promo:
1080x1920, 30fps, H.264, no audio (the seller adds a trending sound in
TikTok/Instagram). The seller posts these to TikTok and Instagram, not to
Etsy, so always make them vertical.

The look was built from the seller's own reference videos (the "equ",
"Moolah" and "Black Hole" app promos) and he loved the result. What makes it
work, so keep it when you change things:

- **The phone barely spins.** It stays front-facing with a slight 3D angle
  (about 12°, alternating sides per section) and a gentle idle float.
  Steady 360° spins on one axis read as robotic; an early draft was
  rejected for exactly that.
- **Whip-pans between features.** The phone accelerates off frame
  (ease-in) with real motion blur, and the next screen flies in from the
  opposite side and settles fast with a ~3% overshoot: a fast start and a
  long settle. Symmetric ease-in-out moves look cheap.
- **One feature per section, 3–4 seconds each,** with a big two-line
  headline (line 2 in a highlight color). Show features, not a tour of tabs.
- **A pop-out card per feature:** the key card (the big number, the saved
  total, the date) lifts off the screen toward the camera with a soft shadow.
- **Every pop-out must be a whole, clean card.** The pop-out is a crop of
  the screen, so pick an element that is one complete card with its own
  rounded corners, and that nothing else overlaps. If tiles or chips sit
  across its edge (like the Honolulu marker app's stat tiles overlapping the
  bottom of the hero), pop them together as one card with a list:
  `["pop", [".hero-wrap", ".minis"]]`. The script takes the corner radius from
  the first rounded box and prints `WARNING pop ... cuts through ...` when
  something overlaps the crop; fix every warning before rendering, then zoom
  into the storyboard to check the corners are rounded and nothing is sliced.
  (The seller rejected a render whose hero pop-out had square corners and
  stat tiles cut in half.)
- **Pop-out corners are truly transparent.** The card is a flat plane
  whose shape comes from an alpha mask in `devices.html` (`updateCard`):
  a canvas `roundRect` with real CSS arcs, inset ~1 CSS px so the card's
  own anti-aliased edge (page color) is cut away too. Never go back to a
  `ShapeGeometry(roundedRect(...))` card: its quadratic corners bulge past
  the CSS radius and carried a white sliver of the page into every corner
  (the seller spotted it on dark hero cards). Zoom into a popped corner
  on the storyboard: only the card and the phone/background behind it.
- **The intro:** the phone drops in large and tilted with a dark screen,
  then the app wakes up as it settles.
- **An end card:** emoji buddy, the planner name and a CTA pill.
- The phone stays whole at about 60% of the frame width, with a slow push
  in. No tight close-ups.

## Styles

| style | look | fits |
|---|---|---|
| `bold` | each section on its own saturated color, wiping in the direction the phone travels (left, up, right, down) | Bold, Playful, Sunny, most planners; the most eye-catching |
| `studio` | one soft backdrop (the listing-photo glows) the whole way through, headlines slide with the phone, lighter shadow, smaller tilts | Calm, Dreamy; premium and quiet |

## Ask first (AskUserQuestion, one round)

1. **Which video?** Organic screen-recorded clips (step 11, the everyday
   posting default) or a 3D showcase (this). If 3D:
2. **Style:** Bold sections or Clean studio, with the planner's
   personality deciding which one is "(Recommended)". Use `preview` with a
   one-line description of each. After the answer, render `--stills`
   (about a minute once the app is recorded) and show the storyboard sheet
   before the full render.
3. **Length:** about 12s (3 features), about 17s (4 features,
   recommended) or about 20s (5 features).
4. **Features** (multiSelect): propose the planner's strongest moments,
   each as one action plus one pop-out (the big number first, then the
   satisfying action, then the "does the math for you" result). Draft each
   headline in the option's description.
5. **End card:** the planner's own (emoji + name + "Instant download on
   Etsy") or none, if the seller will add his shop end card in CapCut.

If no one answers, take the recommended options and say so.

## Spec (JSON)

`references/example-3d-video.json` is the ADHD Budget Planner's spec.

```json
{
 "name": "ADHD Budget Planner",
 "style": "bold",
 "palette": {"main": "#2A8FB0", "strong": "#155E7A", "accent": "#FFB547", "sage": "#1FAE8E",
             "ink": "#0F2733", "bg": "#F3F9FB", "glow": ["#9ED7E8", "#BFE6F0", "#FFD9A0", "#CDEBF3"]},
 "sections": [
  {"query": "view=today", "headline": ["Know what's", "safe to spend."],
   "steps": [["hold", 1.5], ["pop", "#safe-card"], ["hold", 2.7]]},
  {"query": "view=spend&tab=wait", "headline": ["Wait before", "you buy."],
   "setup": [["scroll", ".saved-strip", 64]],
   "steps": [["hold", 0.6], ["tap", "#wait-card [data-action=wait-skip]", 0.1], ["hold", 0.5],
             ["pop", ".saved-strip"], ["hold", 2.0]]}
 ],
 "end": {"title": ["ADHD Budget", "Planner"], "emoji": "🦦", "cta": "Instant download on Etsy"}
}
```

- `palette`: the planner's colors. `bold` cycles section backgrounds
  through `section_colors` if given, else main, accent, sage, strong. Text
  is white on dark backgrounds and `ink` on light ones; set a section's
  `bg`, `c1` (line 1) or `c2` (line 2) to override. Check every headline
  reads clearly on its color in the storyboard. `studio` uses `bg` plus the
  four `glow` colors (the same ones as the listing photos).
- `query`: what's added to `?sample=1` to open the right screen (the
  template's `?view=` hook, plus any tab param the planner reads). Every
  section starts from fresh sample data.
- `setup`: steps done off camera (scroll the payoff into view). `steps`:
  what the camera sees. Steps: `["hold", sec]`, `["tap", selector, pause]`
  (soft tap circle, the camera nudges in), `["pop", selector]` or `["pop", [sel1, sel2]]` to pop several boxes as one card (that
  element pops out from this moment on; one per section), `["scroll",
  selector, px from top]`, `["type", selector, text]`, `["js", code]`.
  End each section with about 2s of hold after the pop so it reads.
- The first section shows the app waking up (`"wake": false` to skip).
- Keep each section at about 3–4.5s (≈ 90–135 frames). Fewer than 3
  sections feels thin; more than 5 runs past 20s.
- `font`: the headline font family (e.g. `"Fredoka"` for Sunny). By default the
  planner's heaviest embedded face is used.
- `end`: `null` to finish on the last section instead (the seller adds
  his own end card).

## Run

```bash
python3 <skill-dir>/scripts/make_3d_video.py planner.html spec.json --out video/ --stills   # storyboard first
python3 <skill-dir>/scripts/make_3d_video.py planner.html spec.json --out video/            # full render
```

- Recording the app takes about 4 minutes (CSS animations are slowed and
  frames captured one by one so taps and toasts look natural). It's cached
  in `video/sections/` and reused until a section's `query`, `setup` or
  `steps` change, so restyling or rewording headlines doesn't re-record;
  pass `--rerecord` to force it.
- The full render is about 1.2s per frame (≈ 10 minutes for 17s). Run it
  with `run_in_background` and tell the seller roughly when it's due.
- Output: `<name>-3d-<style>.mp4` plus a contact sheet (a frame every
  0.75s). Read the contact sheet before sending: the headline readable on
  every color, the pop-out lands on the right card, no section opens on a
  half-loaded screen, the end card complete.

## How it renders fast (keep these)

The workspace has no GPU, so three.js runs on SwiftShader (software) and
pays for every shaded pixel, hidden or not. With `window.FAST_FRONT` the
phone's front face (always under the glass and screen) gets a flat
material and the glass becomes a thin ring around the screen, which is
pixel-identical and about 3x faster on close frames. `window.TEX_W = 960`
keeps the screen texture at a size the video never exceeds. Frames are
composited on a 2D canvas and read with `toDataURL`, never page
screenshots. Motion blur averages 2–18 sub-frames only on fast frames.
Running two renders in parallel doesn't help: one already uses both cores.
