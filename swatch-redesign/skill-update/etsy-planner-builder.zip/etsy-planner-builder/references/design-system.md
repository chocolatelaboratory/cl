# The shop's planner design system

Every planner in the shop shares this look so the products read as one
brand. The tokens and components are already implemented in
`assets/starter-template.html`; this file explains what they're for, so
new modules use them the same way the existing planners do.
`references/example-study-planner.html` is a complete finished planner
(ADHD Study Planner) to copy patterns from.

## Feel

Calm, warm, uncluttered. Built for people who get overwhelmed easily:
one obvious next thing per screen, gentle encouraging copy, no guilt, no
walls of options. "Progress, not perfection."

## Color roles (don't add new colors casually)

| Token | Use for |
|---|---|
| `--bg` #FAFAFA | page background |
| `--surface` #FFF | cards, panels, nav bars |
| `--ink` #171717 | headings, primary buttons, active pills |
| `--ink-body` / `--ink-secondary` | body text (82%) / labels, meta, helper text (62%) |
| `--border`, `--border-strong` | card borders / hover and empty-state icons |
| `--sage` family | progress, completion, "done", active nav, focus rings, charts |
| `--terracotta` family | urgency (due today, overdue, high priority) and celebration accents |
| `#B3402C` danger | destructive confirm buttons only |

Category colors (classes, subjects, kids, budget categories): use the
muted set `['#7B9075','#CC8B79','#7E8FA6','#C2A25E','#9A7E97','#6E9A96','#B58B6B','#8C8C8C']`.
They're shown as small dots, swatches, or stripes, never as big fills.

Rough balance: ~60% off-white/white, ~30% ink, ~10% sage/terracotta.

**Per-planner accent palette.** When the seller asks for different colors
on one planner, keep `--bg`, `--surface` and the ink tokens, and redefine
the accent tokens in a block at the end of the CSS: point `--sage`,
`--sage-strong`, `--sage-soft` at the new main color (mid shade for
progress/charts, a dark shade with 4.5:1 contrast on white for buttons
and text, the lightest shade for soft fills) and keep one warm color in
the `--terracotta` slots for urgency. Every shared component then follows
automatically. Also recolor `celebrate()` confetti and the category color
list. Example: the Student Nurse Planner (blue 600 `#0085ca` progress,
blue 700 `#006aa1` buttons/active, blue 50–200 fills, coral urgency).

## Type

Inter, weights 400 and 700 only. Four sizes: `--text-xs` 12.5px (labels,
meta, tags), `--text-sm` 15px (body), `--text-lg` 20px (view titles on
phone, card headlines, stat numbers), `--text-xl` 28px (desktop titles,
big numbers). Numbers use `font-variant-numeric: tabular-nums` (`.num`).
Make values bigger than their labels ("12" big, "Done" small).
Form inputs are 16px on phones (see mobile rules).

## Spacing, radius, shadow

8-point scale: `--sp-1` 4 · `--sp-2` 8 · `--sp-3` 12 · `--sp-4` 16 ·
`--sp-6` 24 · `--sp-8` 32 · `--sp-12` 48. Never invent in-between values.
Radius: 10 (small controls), 14 (buttons, inputs, inner cards), 20
(panels, sheets). Soft shadows only: `--shadow-card`, `--shadow-btn`.

## Icons

Google Material Symbols Outlined, embedded in the file as SVG drawings
by `scripts/embed_icons.py` (no icon font, so they always appear). Size
with `font-size` and color with `color`, same as text. Active nav items
switch to the filled version automatically. Icon-only buttons need an
`aria-label`. Never put essential meaning in an icon alone; pair it with
a label.

## Components (class names in the template)

- `.panel` card with `.panel-title` / `.panel-head` + `.link-btn` ("See all")
- `.rightnow` card: the single most important thing right now
  (terracotta border = needs attention, `.calm` sage = all clear)
- `.stat-row.cols-2/.cols-4` + `.stat-box` / `.stat-num` / `.stat-label`
- `.row-list` rows with `.check-hit` + `.checkbox` (CSS-drawn check),
  `.row-body`, `.row-title`, `.row-meta`, `.row-end`, and a `closeBtn()`
- `.tag` (`.urgent`, `.sage`, `.soft`), `.dot`
- `.btn` + `.btn-primary` (ink), `.btn-secondary`, `.btn-sage`,
  `.btn-ghost-danger`, `.btn-danger-solid`, `.btn-sm`, `.btn-block`,
  `.btn-row` (stacked on phone, row on desktop)
- `.pill-row` / `.pill` filters (swipe sideways on phones)
- `.form-stack`, `.form-row-2`, `.inline-form`, `.field-label`
- `.disclosure` + `.disclosure-body` to fold rarely used forms away
- `.module-grid` / `.module-card` hub for planners with many modules
- Charts without libraries: `.bar-chart` (week view, today bar in
  terracotta), `.hbar-row` (by category), `.progress-bar`, SVG donut
  (see example planner), `.insight-callout`
- `.filter-stack` for stacked filters/controls above a list (12px rhythm)
- `.summary-stats` (+ `.cols-4`) strip of aligned label/value cells for
  totals above a list; `.k` label, `.v` value (add `.money-in` / `.neg`)
- `.donut-wrap` / `.donut` / `.donut-center` (`.big` short value +
  `.small` one-word label) and `.donut-detail` below the ring for the
  full numbers
- `.empty-state` with icon + one encouraging sentence + what to do next
- `.settings-row`, `.switch`
- `toast()` with optional Undo, `openModal()` with optional typed
  confirmation, `celebrate()` confetti, bottom `.sheet`, `.fab`

## Behaviors every planner keeps

1. **Local-only storage** in `localStorage` under a planner-specific
   `STORAGE_KEY` (e.g. `adhdMealPlannerData_v1`), with `normalize()` so
   old or broken data can never crash the app. Footer line: "Everything
   you enter stays private in this browser on this device."
2. **Settings view** with Load sample data, Export backup (JSON
   download), Import backup, Clear all data (type DELETE to confirm).
3. **Undo instead of "are you sure?"** for everyday deletes; confirm
   modals only for big destructive actions.
4. **Celebrate completions** (confetti on check-off, wins log, streaks).
   Respect `prefers-reduced-motion`.
5. **Gentle copy**: greeting by time of day, a rotating encouraging line,
   empty states that invite rather than scold, no red "OVERDUE!!" shouting.
6. **Sample data** that looks like a real person's week (specific names,
   realistic amounts and dates relative to today). It's what the listing
   screenshots show.
7. **Screenshot hook**: `?view=<name>&sample=1` opens any view
   pre-filled with sample data (only if the planner is empty). Used for
   listing photos and by `scripts/check_mobile.py`.
8. **Desktop**: at ≥900px the bottom nav becomes a 240px sidebar,
   content gets more padding, stats go 4-across, controls get slightly
   smaller. Phones are the primary target; desktop is the bonus.

## Timers (focus timers, countdowns, stopwatches)

Buyers switch tabs, lock their phones and close the page mid-session.
Browsers slow `setInterval` to once a minute or pause it entirely in
those cases, so a timer that subtracts one second per tick falls behind
or stops. A competitor's 2-star review said exactly this ("the study
timer stops when I switch tabs"), so every timer works from the clock:

- On start, store an absolute end time in state and save it:
  `t.endAt = Date.now() + durationMs; t.status = 'running'; save();`
- On pause, store what's left: `t.remainingMs = t.endAt - Date.now(); t.endAt = null;`
  On resume: `t.endAt = Date.now() + t.remainingMs;`
- Remaining time is always computed, never counted:
  `remaining = Math.max(0, t.endAt - Date.now())`. A stopwatch stores
  `startedAt` and computes `Date.now() - startedAt` the same way.
- `setInterval(tick, 500)` only redraws; `tick()` checks
  `Date.now() >= t.endAt` to finish the session.
- Also call `tick()` on `visibilitychange` (when `!document.hidden`),
  `focus` and `pageshow`, so the display is right the instant the buyer
  comes back.
- Because the timer lives in saved state, a reload resumes it, and on
  startup a session whose `endAt` already passed is completed and logged
  with a toast like "Your focus session finished while you were away.
  It's been logged."
- Show the running time in `document.title` and as a small pill in the
  header so it's visible from any view.
- Never write `remaining -= 1`, `seconds--` or `elapsed++` in a tick.
  `scripts/check_mobile.py` flags those patterns.

Worked examples: the focus timer in `references/example-study-planner.html`
(search "TIMER") and in the Student Nurse Planner.

## Timelines

Dots must sit exactly centered on the line. Draw the line and the dot
from the same anchor point instead of tuning two separate offsets:

```css
.timeline li{ position:relative; padding-left:24px; }
.timeline li::before{ content:''; position:absolute; left:7px; top:0; bottom:0; width:2px; background: var(--border); }      /* the line */
.timeline li:first-child::before{ top:0.75em; }
.timeline li:last-child::before{ bottom:auto; height:0.75em; }
.timeline li::after{ content:''; position:absolute; left:8px; top:0.75em; width:10px; height:10px; border-radius:50%;
  transform: translate(-50%, -50%); background:#fff; border:2px solid var(--border-strong); box-sizing:border-box; }      /* the dot */
```

The line's center is at `left: 7px + 1px = 8px`, and the dot is centered
on `8px` with `translate(-50%, -50%)`, so they line up at any screen
density or font size. A shop reviewer spotted dots sitting off the line
on a phone when they were placed with separate offsets.

## Icons beside text

An icon next to words (pills, chips, status tags, buttons, card labels,
nav items) must line up with the CAPITAL letters. Plain
`align-items:center` centers the icon on the line box instead, and each
font, plus each phone's rounding at small text sizes, puts the letters
1-2px higher or lower inside that box. It looks fine at a glance and
off when a listing photo is zoomed in (a seller spotted a bell icon
sitting low beside "Follow up today").

The template handles it for `.tag`, `.pill`, `.btn`, `.link-btn`,
`.back-btn`, `.rightnow-label` and `.nav-btn`:

```css
@property --pcap{ syntax:'<length>'; inherits:true; initial-value:0px; }
@supports (height: 1cap){
  .ic-text{ align-items: baseline; flex-wrap: wrap; align-content: center; --pcap: 1cap; }
  .ic-text > .icon{ translate: 0 calc(50% - var(--pcap) / 2); }
}
```

The icon's bottom sits on the text baseline, then moves down half its
own height and up half the cap height, so its center lands exactly on
the middle of the capital letters in any font. `flex-wrap` +
`align-content:center` keeps the whole group centered in tall pills and
buttons. Rules:
- Any NEW component with an icon beside text gets class `ic-text`.
- A button whose icon sits ABOVE its label (column layout, like quick
  action tiles) gets class `stacked` to opt out.
- `scripts/check_mobile.py` flags icon + text rows that aren't
  cap-aligned (`icon-not-cap-aligned`).

## Bottom navigation

Phones get a floating tab bar (template default): 12px in from the
sides and 10px above the bottom safe area, 26px radius, a hairline
border, a soft shadow and a light blur behind it. The active tab is a
solid pill (`--nav-active`, default `--sage-strong`) with a white icon and
label. Page content keeps 132px of bottom padding and toasts sit above
the bar, so nothing hides behind it. Desktop still uses the sidebar.

## No app-name header

Planners have no top bar with the app name, on phones or atop the desktop
sidebar. The buyer knows which app they opened; a name pinned top-left is
template filler. Each view starts with its own title (greeting on Home,
the view name elsewhere), with safe-area padding above it. Status that
must stay visible across views (a running timer) floats as `.float-pill`
in the top-right corner.


## Personalities and base motion

The structure of each screen (hero style, color logic, progress, inputs,
tab bar style, celebration) comes from the planner's personality: see
references/personalities.md. The base motion is in the template:
`.rise` + `--i` for staggered section entrances, `data-count` +
`countUp(root)` for numbers that count up, a 0.96 press on buttons, and
the reduced-motion block that turns all of it off. Any active-state icon
swap must use `svg:has(.f) .o` (or `.icon.has-fill`) so icons without a
filled version never disappear.

## Optical centering (buttons, pills, tags, icon buttons)

Center by the ink, not the box. Material Symbols icons sit inside a box
with uneven empty space (the `add` icon is about 20% blank on each side,
`library_add` is not), and a text line box puts the capital letters about
1px below center. A button centered by its boxes therefore looks heavier
on the icon side and slightly low, which buyers notice on primary buttons.

The template's `opticalCenter()` (in the ICONS section of the script)
fixes this automatically after every render, resize and font load:
1. each icon's visible shape is moved onto the middle of the capitals
   (icon beside text), over the middle of the label (icon above text), or
   onto the middle of its own box (icon-only buttons);
2. the visible icon + capitals group is centered in the button by
   trading padding left/right and top/bottom (width and height never
   change). Column buttons skip the vertical step so a row of tiles keeps
   its labels on one line.
It measures icon shapes with `getBBox()` and capitals with canvas text
metrics, so it works in any font and at any size. Never remove it; when
building a new centered component with an icon, use one of the classes it
covers (`.btn`, `.pill`, `.tag`, `.icon-btn`, `.fab`, `.toggle`, `.ic-text`)
and give icon-above-label buttons `.stacked`. `check_mobile.py` reports
`content-not-optically-centered` for anything more than ~1px off.

Text-only buttons need centering too. `opticalCenter()` only touches the
classes above, so any other button relies on its own CSS. A flex button
with a `min-height` taller than its text and no `align-items:center`
stretches its text to the top edge (the ADHD Budget Planner's "Skip it /
Buy it" shipped this way). Every new button class gets
`align-items:center; justify-content:center` (or `ic-text` when it has an
icon beside the label; don't combine `align-items:center` with `ic-text`).
`check_mobile.py` reports `button-text-not-centered` for any visible
button, of any class, whose label sits more than 2px off its vertical
center.

Shapes holding a single emoji or icon (hexagons, tiles, rings, avatars)
center it with `display:grid; place-items:center`. Keep descendant
selectors narrow (`.card div > span`, or a class on the text) so a rule
meant for a subtitle can't override the shape's display. `check_mobile.py`
reports `content-not-centered-in-shape` for any emoji or icon more than
~2px (or 7% of the shape) off center.
