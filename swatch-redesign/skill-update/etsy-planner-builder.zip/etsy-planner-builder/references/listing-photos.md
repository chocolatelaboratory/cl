# Listing photos

`scripts/make_listing_photos.py` turns a planner into finished 3000×2250
Etsy images: real 3D devices (a tilted jet black phone, plus a matching
laptop on the desktop slide) rendered with three.js, headline, short
text and checklist, on a soft blurred-gradient background in the
planner's colors. The script only takes the pictures. What to show and
what to say is decided fresh for every planner, because a homeschool
parent, a college student and someone budgeting for a wedding are
looking for completely different things. Never reuse another planner's
shot list or headlines; `references/example-photos.json` (ADHD Study
Planner) shows the format and the level of quality, not the content.

## 1. Think like the buyer first

Before writing any slide, answer these from what the planner does and
who it's for:

- **Who is scrolling past this?** (A tired parent planning a school
  year, a student who can't start assignments, an adult with ADHD
  drowning in bills.) Write every headline in their words.
- **What's their pain?** The headlines should name the relief, not the
  feature: "Always know what to do next", not "Today dashboard".
- **What makes this planner different** from the competitor listing it
  was modeled on, or from a printable PDF? Interactive things a PDF
  can't do (auto totals, timers, progress bars, streaks, a "right now"
  card) are the strongest photos.
- **Which 4–6 features would make them buy?** Those become the photo
  slides. Everything else goes on the "What's inside" slide.

## 2. Plan the set (usually 7–10 images)

1. **Cover (hero).** Name + one-line promise + 3 phones showing the most
   visually impressive, most different screens (not a settings page or an
   empty form). This is the search thumbnail, so it must read at small
   size: short name, big text.
2. **One slide per key feature**, in the order the buyer cares about them.
   Each gets: a headline of 3–7 words, one sentence of support, 2–3
   checklist bullets that are true and specific to this planner.
   Alternate `"side": "left"` / right so the set has rhythm.
2b. **Comparison (always slide 2, the seller's rule)** (`comparison`):
   see "Comparison slide" below.
3. **A pair slide** (`two-phones`) where two related screens tell one
   story better together (classes + insights, budget + bills).
4. **Phone + computer** (`desktop` with `phone_view`): reassures buyers it
   works everywhere.
5. **What's inside** (`features`): every section with its icon, plus
   footer badges for the trust points (works offline, private on your
   device, no subscription, backup & restore). Cards sit 3 per row and
   any leftover cards on the last row are centered (8 items = 3, 3, then
   2 centered). With more than 6 items the cards turn compact so the
   footer badges keep a clear gap below the grid and above the bottom
   edge (~120px at display size). Check both on the render.

Pick only screens the planner actually has, and only claims the file
actually does.

## Comparison slide (always photo 2)

Shows at a glance why the app beats the free or cheap thing the buyer
already has. Put it right after the hero, so it is rank 2 on Etsy.

```json
{"type": "comparison", "view": "today",
 "headline": "More than a printable chart", "highlight": "printable chart",
 "sub": "It does the work a chart can't.",
 "versus": "PRINTABLE",
 "rows": [["All 320 Honolulu colors", true],
          ["Old \u2194 new code converter", false],
          ["Blends from your markers", false],
          ["Duplicate check", false],
          ["Refill & wishlist tracking", false],
          ["Search by code or name", false]]}
```

- `versus`: the column header for the alternative, one short word or two
  (PRINTABLE, SPREADSHEET, PAPER, NOTEBOOK, NOTES APP). The headline is
  always "More than a <alternative>", and the script puts the
  highlighted words on their own line.
- Choose the alternative this buyer actually uses: printable chart for
  marker and color trackers, spreadsheet for budget, business, job and
  collection value trackers, paper planner or notebook for planners and
  logs, notes app or paper list for simple lists.
- 6 rows, each 2–5 words. Row 1 (`true`, grey tick) is the basic thing
  both can do. Rows 2–6 (`false`, grey x) are the app's most
  buyer-relevant features that the alternative really can't do. Only
  claim what the planner does.
- The phone shows the home or dashboard screen at its best (`side`:
  `"right"` by default, or `"left"`). The THIS APP ticks and header use
  the planner's main color, like every other highlight.

## 3. Show each feature *in action*

A screenshot of an empty or idle screen sells nothing. Use the slide
options to put the screen in its best state:

- `click`: open the thing that matters (expand a card, open a recipe,
  start a timer).
- `scroll_to`: bring the selling part into view (the steps checklist,
  a chart, a callout).
- `fast_forward_ms`: let time pass after the clicks so a timer is
  mid-session or a countdown is partway.
- `fill`: type into fields after the clicks, e.g.
  `[["#calc-weight", "25"]]` (a number picks a dropdown option by index),
  so a calculator shows a real result.
- `js`: one line of JavaScript run after the clicks, e.g. to scroll a
  sideways board to a fuller column.
- `hide`: remove floating clutter (the FAB is hidden by default).
- Per-phone settings in `hero` / `two-phones`: give a view as an object,
  `{"view": "assignments", "scroll_to": ".assign-card"}`.

The sample data is what buyers see, so it has to look like a real
person's life in this niche (real-sounding class names, kids' names,
meals, bills). If a screen looks thin, improve `applySampleData()` in
the planner rather than settling for a weak photo.

## 4. Match the product's tone

- Headline highlight color (the seller's rule): the emphasized words are
  always the planner's **main theme color**, the same on listing photos and
  pins, so the whole set looks consistent (rose planner = rose highlights,
  plum planner = plum). Set the planner's `"palette"` with its `main` color
  and the scripts use it automatically; never use the old shop
  `"accent": "terracotta"` / `"sage"` on a planner with its own palette.
  Use `"highlight_color"` only if the main color is too pale to read on the
  light background (pick the palette's deep shade, `--c-700`, then).
- Highlight 1–3 words of each headline with `"highlight"`: the relief
  word ("next", "tiny steps", "time blindness").
- Kids/family planners can be warmer and more playful in wording;
  finance planners calmer and more reassuring; student planners short
  and punchy. Keep it kind, never shaming, no medical claims.

- If the planner uses its own palette (see design-system.md > Color
  roles), set `"palette": "blue"` (built in: shop, blue, slate, gold) (or an object with `bg`, `b1`, `b2`,
  `soft`, `main`, `strong`, `accent`) so the photo background, checkmarks
  and highlights match the app.
- The background glows come from the palette's main color. For a
  seasonal or very specific mood, set them yourself with `"glow"`: four
  colors for bottom left, bottom middle, bottom right and top right, e.g.
  `["#EE9AA2", "#F6C3C6", "#F8C9A0", "#F4DCD3"]` for the Christmas
  Gift Tracker (rose, blush, peach). Keep them soft and light: the
  headline must stay crisp on top.
- Device finish: `"finish": "jet"` (default). Use `graphite`,
  `titanium` or `silver` only if the seller asks.

## Composition rules

- **No product name or shop name stamped in a corner.** The headline and
  the screens carry the image; a corner label is clutter.
- **Devices are centered in their space automatically.** Each layout puts
  its 3D phones/laptop in a stage and the script measures the rendered
  outlines and centers them. It prints a WARNING if devices run
  off the canvas or overlap the headline: fix the spec (shorter headline,
  fewer bullets) and re-render until there are no warnings.
- Keep headlines to 2 lines on photo slides and 1–2 on the desktop
  slide, so text never crowds the devices.

## 5. Render, then look at every image

```bash
python3 <skill-dir>/scripts/make_listing_photos.py <planner>.html photos.json --out listing-photos
```

Open every PNG (Read it) and check: devices visibly centered in their
half (or the whole width on the desktop slide), nothing cut off at the edges, each
phone shows the feature its headline promises, no empty forms or
placeholder text in the key area, text not crowding the phone, headline
readable when shrunk to thumbnail size. Fix the spec (or the planner's
sample data) and re-render until every image earns its place. Then send
them in upload order and say in a line or two what each one shows.


## Saturation

The seller wants every photo and pin at +50 saturation (PIL `ImageEnhance.Color` 1.5 on the finished image). It's the default in both scripts. Look at the boosted set before sending: pale pastels and skin-tone swatches can get loud, so drop `"saturation"` to 1.3 in the spec if a screen looks garish.
