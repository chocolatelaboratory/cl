# Personalities

Every planner in the shop shares one base, so buyers recognize the
family, but each planner gets its own **personality**: one choice per
slot from the menu below. Like friends: similar, never all at once.
Never stack every option into one planner.

Working examples (the same Job Search Tracker Home screen, three ways;
open them at 375px and lift components from them):
- `assets/personalities/bold.html`
- `assets/personalities/calm.html`
- `assets/personalities/playful.html`

Two more, as static two-screen mockups of real trackers (open at full
size, 1600x1200; add `#mint` / `#berry` or `#ocean` / `#sunset` to see
the same personality in other palettes):
- `assets/personalities/sunny.html`: Kids Reading Quest (home + sticker chart)
- `assets/personalities/dreamy.html`: Sleep & Mood Journal (today + insights)

They are demos: the "This demo shows Home only" toasts, the hard-coded
data and the separate sheets are not product code. Port components into
the template's structure (views, `RENDER`, state, `icon()`), not the
demo's closures.

## The base (every planner, every personality)

- Inter for body text (Inter Display for big numbers and headings), via
  `embed_fonts.py`. Sunny and Dreamy use rounded Nunito (with Fredoka headings for Sunny).
- Rounded cards on the light background; one view title per screen; no
  app-name header.
- **Motion kit** (in the template): sections enter with `.rise` and a
  `--i` stagger; numbers count up with `data-count` + `countUp(view)`;
  everything tappable springs on press; sheets spring up and drag down;
  the nav pill glides; check-offs burst (ripple, sparks, vibration);
  `rollNumber()` rolls changing numbers. Feel per personality with
  `<body data-motion>`: default (between Calm and Bold) for Focused, `playful` for Playful and Sunny, `bold` for Bold, `calm` for
  Calm and Dreamy. All of it is
  off under prefers-reduced-motion, and the photo/pin/check scripts run
  with reduced motion so screenshots show final values.
- One **hero number** per main screen: the single figure that matters
  most, large; supporting stats shrink to one strip or a chip row below
  it. Never a grid of equal stats as the first thing on Home.
- Tap targets 44px minimum (check circles included), text never runs
  under a control, the active nav icon always draws (see Lessons).

## The menu (pick one per slot)

| Slot | Options | Where to see it |
|---|---|---|
| Hero | **Dark card** (palette's darkest color, faint rings, white big number, chips/logos + light pill button, 3-up stat strip on the card) · **Light tint + ring** (tinted card, big number left, progress ring right, outlined stat chips) · **Illustrated banner** (gradient, wave bottom, floating emoji, overlapping stat cards) · **Timer hero** (Focused, below) | bold / calm / playful |
| Color | **Category colors** (one vivid color per category, used on its tile, bar segment, chip and icon tile everywhere) · **One hue + one accent** (palette shades, one muted accent for done/progress) · **Pastels** (soft tile backgrounds with strong text of the same hue) | bold / calm / playful |
| Progress | **Day row** (streak-style tiles M–S with counts, today outlined) + **milestone bar** (markers at halfway and goal) · **Bar chart** (quiet weekly bars) + **ring** · **Journey path** (stops spaced evenly along an SVG road with `getPointAtLength`, done stops checked, next stop pulsing, trophy at the end) · **Rings** only | bold / calm / playful |
| Inputs | **Ruler slider** (scroll-snap ticks, center marker, big live value, preset chips) · **Stepper** (− value + with presets) and **sliding segmented control** · **Emoji choice cards** (3-up tappable cards with an emoji and a label) · plain fields (always fine for text) | bold / calm / playful |
| Tab bar | **Labeled floating bar** (the template default) · **Dark icon pill** with a sliding white circle + a separate round add button · **Labeled bar with a raised center add button** | calm / bold / playful |
| Celebration | **Full goal screen** (sheet with medal/trophy, count-up, confetti) · **Quiet** (ring completes with a soft glow + toast) · **Party** (sparkle burst on every check-off + emoji confetti) | bold / calm / playful |
| Detail | emoji · gradients · diagonal stripes on fills · raised "ledge" shadows on buttons and cards · outlined chips · hairlines | mix 1–3 |

## The six personalities (starting points)

**Bold** (job search, side hustle, finance, fitness goals): dark hero
card, category colors, day row + milestone bar, ruler slider, dark icon
pill tab bar, full goal screen, emoji sparingly in chips. Confident and
premium.

**Calm** (nurse, health, wellness, budget, caregiving, grief, sleep):
light tint + ring hero, one hue + one accent, bar chart + ring, stepper
+ segmented control, labeled floating bar, quiet celebration, no emoji,
no gradients, slower gentler motion (fade only, ~0.9s). Reassuring.

**Playful** (ADHD, kids, homeschool, habits, chores, pets, reading
challenges): illustrated banner with a bobbing emoji, pastels, journey
path, emoji choice cards, raised center add button, party celebration,
bouncy springs, raised ledge shadows, friendly copy ("Let's do it 👉").
High energy.

**Focused** (study, exam prep, pomodoro, productivity, deep work): the
running timer or next session is the hero (big countdown on a dark card,
start/pause pill), category colors per subject, rings, stepper with
presets (25/45/60 min), dark icon pill tab bar, full goal screen for a
daily target, minimal emoji. Calm intensity.

**Sunny** (kids, chores, rewards, allowance, reading challenges, sticker
charts, homeschool for younger kids, pets): warm and game-like.
- Type: Fredoka for headings and big numbers, Nunito for everything else
  (`embed_fonts.py --display "Fredoka:600,700" --body "Nunito:600,700,800"`).
- Background: the palette's palest tint with a soft dot grid
  (`radial-gradient` dots, 26px).
- Hero: a rounded color block across the top (light-to-main gradient,
  rounded bottom corners) holding the avatar, a big emoji mascot and a
  tilted speech bubble with one encouraging line ("Just 10 more minutes
  today!"). A white **level card** overlaps its bottom edge: title, goal and
  a thick XP bar with a dark "Lv 4" chip.
- Signature detail: **chunky pressable buttons**. Every button and tile sits
  on a solid 4px ledge in a darker shade (`box-shadow: 0 4px 0 <deep>`) and
  presses down into it. Big check buttons on rows, hexagon emoji icons,
  dashed borders for empty slots.
- Progress: chunky day bars (today in the progress color), XP bars, and a
  **sticker / reward chart** grid (filled stickers slightly rotated, next
  slot dashed) with a prize shop.
- Inputs: emoji tool tiles in a colored tray, big steppers, a glowing pill
  primary button.
- Tab bar: labeled white bar with a raised, tilted center add button.
- Celebration: a full screen with a sunburst (`repeating-conic-gradient`),
  confetti, three stars, the XP bar filling, stat cards and the mascot
  cheering.
- Color logic: one main color with a deep shade for ledges, a contrasting
  **progress color** (green on yellow, orange on mint, purple on pink) and
  one accent. Big text sits on white, never on the main color.

**Dreamy** (habits, self-care, wellness, sleep, mood, journaling, hydration,
gentle fitness): soft, calm and friendly.
- Type: Nunito throughout, 900 for headings and big numbers
  (`embed_fonts.py --display "Nunito:900" --body "Nunito:600,700,800"`).
- Background: a near-white page with large blurred glows of the palette
  (deep, pale and a warm accent), a faint halftone dot patch and soft 3D
  clouds as decoration.
- Hero: a gradient header (deep color to pale, fading into the page) with
  frosted glass icon pills (`rgba(255,255,255,.22)` + 1px light border), a
  greeting, a small emoji buddy and a thought-bubble chip ("You slept
  well!"). The main card (check-in, streak, calendar) overlaps the header.
- Signature detail: soft white cards with 1px hairline borders and gentle
  shadows, rounded 24px; stat tiles in threes with an emoji on top.
- Progress: a **glowing streak track** across the week (pill background,
  checked dots, today's dot ringed and glowing), segmented progress bars,
  rings, soft bar charts and a **month of colored mood squares**.
- Inputs: emoji mood faces (5 across, the chosen one tinted and outlined),
  tag chips, round check circles.
- Tab bar: a pale floating bar with a white pill behind the active tab.
- Celebration: quiet (a soft glow on the streak dot, a kind toast); no
  confetti storms.
- Color logic: one gradient family from the palette plus one warm accent
  for highlights and tips (orange on lavender, amber on ocean blue, violet
  on coral) and a separate streak color.

Sunny and Dreamy take their palette from the seller's color answer like
every other personality: map the chosen color onto their tokens (`--main`
/ `--light` / `--deep` for Sunny, `--g1` / `--g2` / `--g3` for Dreamy) and
pick the contrasting progress or accent color to go with it. The demo
files show three palettes each as proof the look survives a color change.

## Choosing

1. If the seller named a personality (or "like the X planner"), use it.
   If not, ask before planning (see SKILL.md step 2): the best fit marked
   Recommended plus the next three fits, each with a one-line feel, and
   a second question for the main color.
2. Swap 1–2 slots so it isn't a clone of another planner in the shop
   (e.g. Calm with the journey path; Bold with pastels). Prefer a
   different personality from the shop's most recent planner unless the
   niche clearly calls for the same one.
3. State it in the module plan (step 2): "Personality: Calm, with the
   day row instead of bars". Keep it in a comment at the top of the
   planner's `<style>` and in a "Design" line at the end of the listing
   file, so later fixes keep the same personality.
4. Apply it to every view, not only Home: the same hero style for each
   module's lead number, the same color logic, input style, celebration
   and motion feel throughout.

Palettes still apply: a custom palette sets the colors, the personality
sets the structure. Bold's dark hero uses the palette's darkest color;
category colors must read on white (4.5:1 for their text uses) and stay
distinct from the palette's done/urgent colors.

## One color from the seller

When the seller names a single color ("make it purple", one hex code)
instead of a full palette, build five shades from it with
`scripts/make_palette.py "<hex>"` (for a color name, pick a pleasant hex
for it first and say which). The steps are uneven on purpose:

| Token | Lightness | Use |
|---|---|---|
| `--c-900` | almost black with a tint | hero card, active tab, main buttons |
| `--c-700` | deep (≥4.5:1 on white) | text and icons on light backgrounds, pressed states |
| `--c-500` | the seller's color | progress, rings, highlights |
| `--c-300` | soft (mid tone if the color is pastel) | secondary details, chart bars |
| `--c-100` | barely-there tint | backgrounds behind tiles and chips |

The near-black and the faint tint are what make one color look like a
designed palette. Darker shades are slightly desaturated so they read
rich, not neon. The script prints contrast checks and CSS that maps the
shades onto the template's accent tokens (`--sage*`, `--nav-active`).
Keep the light background, white cards and the done/urgent colors; if
the seller's color is itself green or red, shift done/urgent so they
stay distinct. With a pastel base, never put text or icons in `--c-500`;
use `--c-700`. A full palette from the seller (like slate) is used as
given instead.

## Lessons (the checker enforces the first two)

- **Active nav icon vanishing:** active tabs swap to the filled shape,
  but some icons (`insights`, `add`, `check`, `close`…) have no filled
  version. Only hide the outline when a fill exists:
  `.active .icon svg:has(.f) .o{display:none}` (the template's
  `.icon.has-fill` guard does the same). Checker: `nav-icon-vanishes`.
- **Subtitle running under a checkbox:** `white-space:nowrap` +
  `text-overflow:ellipsis` only clip a *block* box, so an inline `<span>`
  subtitle spills under the button beside it. Give the text column
  `flex:1; min-width:0` and every line `display:block; overflow:hidden;
  text-overflow:ellipsis; white-space:nowrap`, and keep subtitles short
  ("Product Designer · 10 days"). Checker: `text-under-control`.
- **Ring labels:** the number inside a ring stays small next to it,
  about 17–18px in a 96px ring (under ~20% of the diameter), label
  10–11px. A 24px "8/10" in a 112px ring looked oversized on a real
  phone.
- **Hero chip rows** must fit one line at 320–360px: shrink padding and
  type or drop a chip rather than wrapping a lone chip to a second line.
- **Emoji are text, never images:** they render as each buyer's own
  phone emoji (Apple on iPhone, Samsung/Google on Android), so avoid ones
  whose look varies in meaning (📅 shows a specific date, e.g. "JUL 17").
  Never embed emoji artwork images.
- Toasts sit above the floating add button, never on top of it.


## Dark mode (every personality)

Every planner ships light and dark (template: head theme script,
Settings > Appearance with Light / Dark / Auto, `:root[data-theme="dark"]`
tokens). Each example file has its dark block in `<style id="dark-mode">`;
open it with `?theme=dark` to see it. The recipe for a palette:

- **Background:** near-black tinted with the planner's hue, never #000
  (navy planner #0A101C, warm planner #16120A, plum #15121C). Surfaces
  step lighter as they rise: `--bg` < `--surface` (+6-8% lightness) <
  `--field` (+4%). Lines are a little lighter than the surface.
- **Text:** off-white tinted with the hue (#E8EDF6, #F7EEDA), secondary
  text ~56-60% of it.
- **Accents:** keep the hue, lighten ~15% and desaturate ~10% (#2B57A6
  becomes #6F95DC) so they don't glow. Soft tints become the accent at
  ~15% opacity instead of a pale solid.
- **Hero cards:** a dark hero (Bold, Focused) turns a step *lighter* than
  the page so it still reads as the anchor; a bright hero (Playful's
  gradient, Sunny's yellow, Dreamy's header) keeps its color, toned down
  a little, and fades into the dark page instead of white.
- **Buttons and nav:** primary buttons and the active nav pill become
  light or the accent with dark text (`--action`, `--on-action`,
  `--nav-active`, `--on-nav`).
- **Fixed-color details:** text that sits on a color that doesn't change
  (white pill buttons on a hero, a dark "Lv 4" chip, names on Sunny's
  yellow) keeps a fixed dark or light color instead of a token that
  flips. These are what the checker's low-contrast warning catches.
- Category colors keep their hue; pastel tiles turn into tinted ones.
