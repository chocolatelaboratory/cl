# Etsy title, tags and description

Write these after the planner is built, from what it actually does.
Never promise a feature the file doesn't have: a buyer who can't find
the "habit tracker" from the description leaves a bad review.

## Limits (Etsy, as of 2026)

- Title: 140 characters max. Buyers on phones see roughly the first 40,
  so lead with the main search phrase.
- Tags: 13, each 20 characters max (count spaces). Use all 13.
- Description: long is allowed, but only the first ~160 characters show
  in previews, so the opening line has to sell on its own.

## Title

Formula: `[Main search phrase] | [Key benefit or format] | [2–3 secondary phrases]`

- Main phrase = what the buyer types: "ADHD Planner Digital", "Homeschool
  Planner", "ADHD Study Planner for Students".
- Read it out loud. It should sound like a product name, not a keyword
  pile. Don't repeat the same word three times.
- Good length is ~80–130 characters.
- Example: `ADHD Study Planner Digital | Mobile & Desktop App | Assignment Tracker, Focus Timer, Student Planner`

Offer 2–3 title options with their character counts.

## Tags (13 × ≤20 chars)

Mix of: the exact product phrase, synonyms (planner/organizer/tracker),
the audience (college student, homeschool mom, adult ADHD), the format
(digital planner, printable alternative, planner app), key modules
(budget tracker, chore chart), and gift angles (gift for student).
Don't repeat the title word-for-word in every tag; cover different
searches. Show each tag with its character count and recheck that none
exceed 20.

## Description structure

1. **Opening (≤160 chars)**: what it is + who it's for + the main
   benefit. "A calm, all-in-one ADHD study planner that works on your
   phone and computer. Track assignments, break work into tiny steps, and
   actually start."
   Right after the opening, add one plain line that sets expectations
   about the format, e.g. "Please note: this is an interactive app that
   opens in your web browser. It is not a printable PDF or a
   GoodNotes/Notability file." Buyers who expected a PDF leave 2–3 star
   reviews ("this is just a website download") when this is missing. If
   the planner can print or save pages as PDF, say so in the same line.
2. **Why it helps** (2–4 short lines, speaking to the buyer's real
   struggle in their words, warm, no medical claims).
3. **What's inside**: every module/view grouped by section, one line
   each, describing what it does for them. Use simple bullet characters
   (•, ✓, ★) because Etsy descriptions are plain text with no markdown.
4. **Features**: works on phone, tablet and computer; no app or
   subscription; data saved privately on the device; backup/restore;
   sample data to explore; undo; calm, distraction-free design. Only list
   what this file actually does.
5. **How it works / what you receive**: instant digital download, the
   file type, how to open it. Use the seller's existing delivery
   instructions if known; if not, ask rather than invent steps.
6. **Good to know**: digital product, nothing shipped; data lives in the
   browser on each device (use backup to move it); personal use.
7. **Short FAQ** (3–4 questions buyers actually ask: Does it work on
   iPhone? Do I need internet? Can I use it on two devices? Is there a
   subscription?).
8. Friendly sign-off inviting messages.

## Rules

- Plain text only (no **bold**, no # headers, no links outside Etsy).
- No medical claims ("treats ADHD", "cures procrastination"). Say "made
  for ADHD brains", "designed to reduce overwhelm".
- When the planner is modeled on a competitor's listing: use their
  module list only as inspiration. Never copy their wording, title,
  photos, or brand name, and never mention them.
- Match the tone of the app itself: warm, encouraging, short sentences.
- Put the finished title options, tags and description in a single
  plain-text file (`<planner-name>-etsy-listing.txt`) so the seller can
  copy and paste each part.
