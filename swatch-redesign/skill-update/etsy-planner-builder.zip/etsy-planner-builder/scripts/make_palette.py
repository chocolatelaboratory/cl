#!/usr/bin/env python3
"""Build a 5-shade palette from ONE color the seller names, so "make it
purple" looks as designed as a hand-picked palette.

Usage:  python3 make_palette.py "#7A5AF8"        (any hex)
Prints the five shades, what each is for, contrast checks, and CSS tokens
to paste into the planner's :root.

The steps are deliberately NOT even: an almost-black tint and a barely-there
tint do most of the work in an app. Darker shades are slightly desaturated
so they look rich, not neon. Background, white cards and the done/urgent
colors are left alone; this only replaces the accent.
"""
import colorsys, sys

def hex2rgb(h):
    h = h.strip().lstrip('#')
    if len(h) == 3: h = ''.join(c * 2 for c in h)
    return tuple(int(h[i:i + 2], 16) / 255 for i in (0, 2, 4))

def rgb2hex(r, g, b): return '#%02X%02X%02X' % tuple(round(max(0, min(1, v)) * 255) for v in (r, g, b))

def lum(rgb):
    f = lambda c: c / 12.92 if c <= 0.03928 else ((c + 0.055) / 1.055) ** 2.4
    r, g, b = map(f, rgb); return 0.2126 * r + 0.7152 * g + 0.0722 * b

def contrast(a, b):
    la, lb = sorted((lum(a), lum(b)), reverse=True); return (la + 0.05) / (lb + 0.05)

def shade(base, l, s_mul):
    h, _, s = colorsys.rgb_to_hls(*base)
    return colorsys.hls_to_rgb(h, l, min(1, s * s_mul))

def main():
    if len(sys.argv) < 2: sys.exit(__doc__)
    base = hex2rgb(sys.argv[1])
    white = (1, 1, 1)
    shades = [
        ("--c-900", shade(base, 0.13, 0.45), "almost black tint: hero card, active tab, main buttons"),
        ("--c-700", shade(base, 0.34, 0.70), "deep: text on light backgrounds, pressed buttons"),
        ("--c-500", base,                    "the seller's color: progress, rings, highlights"),
        ("--c-300", shade(base, 0.82, 0.90), "soft: secondary details, chart bars"),
        ("--c-100", shade(base, 0.96, 0.90), "faint tint: backgrounds behind tiles and chips"),
    ]
    # a light base (pastel) would make the soft shade a near-copy; use a mid tone instead
    if colorsys.rgb_to_hls(*base)[1] > 0.7:
        shades[3] = ("--c-300", shade(base, 0.55, 0.85), "mid: secondary details, chart bars (base is light)")
    # deep shade must be readable as text on white; darken until it is
    name, rgb, use = shades[1]
    l = 0.34
    while contrast(rgb, white) < 4.5 and l > 0.1:
        l -= 0.02; rgb = shade(base, l, 0.70)
    shades[1] = (name, rgb, use)
    print("Palette from", sys.argv[1].upper())
    for n, rgb, use in shades:
        print(f"  {n}  {rgb2hex(*rgb)}  white-text contrast {contrast(rgb, white):4.1f}  {use}")
    c500 = contrast(base, white)
    if c500 < 3:
        print("  NOTE: the base color is light; use --c-700 (not --c-500) for any text or icon on white.")
    print("\n:root{")
    for n, rgb, _ in shades: print(f"  {n}: {rgb2hex(*rgb)};")
    print("  /* map onto the template's accent tokens */")
    print("  --sage: var(--c-500); --sage-strong: var(--c-700); --sage-soft: var(--c-100);")
    print("  --nav-active: var(--c-900);")
    print("}")

if __name__ == "__main__":
    main()
