#!/usr/bin/env python3
"""Build the buyer download: the planner HTML + its "Start Here" PDF, zipped.

Usage:
  python3 make_buyer_package.py <planner>.html <start-here>.html --name "ADHD Meal Planner" [--out DIR]

- Renders the filled-in start-here HTML (from assets/start-here-template.html)
  to "Start Here - <name>.pdf" (US Letter).
- Fails if any page's content runs into its footer, or if placeholders
  like __PLANNER_NAME__ are left unfilled.
- Zips "<name>.html" and the PDF into "<Name-With-Dashes>.zip", ready to
  upload to Etsy as the digital download.
"""
import argparse
import pathlib
import re
import shutil
import sys
import zipfile

from playwright.sync_api import sync_playwright


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("planner")
    ap.add_argument("guide")
    ap.add_argument("--name", required=True, help='product name, e.g. "ADHD Meal Planner"')
    ap.add_argument("--out", default="buyer-package")
    args = ap.parse_args()

    guide = pathlib.Path(args.guide).resolve()
    left = sorted(set(re.findall(r"__[A-Z_]+__", guide.read_text(encoding="utf-8"))))
    if left:
        sys.exit("Fill these placeholders in the guide first: " + ", ".join(left))

    out = pathlib.Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    html_name = f"{args.name}.html"
    pdf_name = f"Start Here - {args.name}.pdf"
    shutil.copyfile(args.planner, out / html_name)

    with sync_playwright() as p:
        browser = p.chromium.launch()
        page = browser.new_page()
        page.goto(guide.as_uri())
        page.wait_for_timeout(300)
        problems = page.evaluate("""() => [...document.querySelectorAll('.page')].map((pg, i) => {
            const c = pg.querySelector('.content'), f = pg.querySelector('.foot');
            if (!c || !f) return null;
            const over = Math.round(c.getBoundingClientRect().bottom - f.getBoundingClientRect().top);
            return over > -8 ? `page ${i + 1} runs ${over + 8}px into its footer` : null;
        }).filter(Boolean)""")
        if problems:
            browser.close()
            sys.exit("Guide doesn't fit: " + "; ".join(problems) + ". Shorten or tighten it and re-run.")
        page.pdf(path=str(out / pdf_name), format="Letter", print_background=True, prefer_css_page_size=True)
        browser.close()

    zip_path = out / (re.sub(r"[^A-Za-z0-9]+", "-", args.name).strip("-") + ".zip")
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as z:
        z.write(out / html_name, html_name)
        z.write(out / pdf_name, pdf_name)
    print(f"PDF:  {out / pdf_name}\nZIP:  {zip_path}  ({html_name} + {pdf_name})")


if __name__ == "__main__":
    main()
