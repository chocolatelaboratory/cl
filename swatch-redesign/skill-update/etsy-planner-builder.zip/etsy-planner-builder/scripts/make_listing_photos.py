#!/usr/bin/env python3
"""Make Etsy listing photos for a planner.

Opens the planner in a headless browser using its ?view=<name>&sample=1
hook, captures each requested screen at real phone (or desktop) size,
then lays each one out as a finished 3000x2250 (4:3) listing image:
3D devices, headline, short supporting text and checklist, on a soft
blurred-gradient background in the planner's colors.

Devices are real 3D models rendered with three.js (assets/device3d, bundled,
no download): a jet black phone with machined cut edges, pill side buttons
and antenna lines, tilted in perspective with a soft floor shadow, and a
matching laptop on the "desktop" slide. Rendering uses software WebGL, so a
10-slide set takes a few minutes.

Usage:
  python3 make_listing_photos.py planner.html photos.json --out listing-photos
  python3 make_listing_photos.py ... --flat      # old flat CSS frames, no 3D

photos.json:
{
  "name": "ADHD Study Planner",          # shown small on every image
  "accent": "terracotta",                 # or "sage": headline highlight color
  "palette": "shop",                      # or "blue", or {"bg":..,"main":..,"strong":..,"soft":..,"b1":..,"b2":..,"accent":..}
  "finish": "jet",                        # device finish: jet (default), graphite, titanium, silver, black
  "glow": ["#EE9AA2", "#F6C3C6", "#F8C9A0", "#F4DCD3"],  # optional: the 4 background glows (default: from the palette)
  "slides": [
    {"type": "hero", "views": [{"view": "assignments", "scroll_to": ".assign-card"}, "today", "focus"],
     "headline": "ADHD Study Planner", "highlight": "Study",
     "sub": "A calm digital planner for your phone and computer",
     "badges": ["Instant download", "No app or subscription"]},

    {"type": "phone", "view": "today",
     "headline": "Know what to do next", "highlight": "next",
     "sub": "One clear task at a time, with the next tiny step.",
     "bullets": ["Right now card", "Quick capture for stray thoughts"],
     "click": [".assign-body"],          # optional: CSS selectors to tap first
     "scroll_to": "#some-panel",          # optional: scroll this into view
     "js": "document.querySelector('.board').scrollLeft = 300",  # optional: run a line of JS after the clicks
     "fill": [["#calc-weight", "25"]],     # optional: type into fields after the clicks (a number picks a dropdown option by index)
     "hide": [".fab"],                    # optional: hide elements for the shot
     "side": "right",                     # phone on the right (default) or left
     "fast_forward_ms": 540000},          # optional: let 9 minutes pass after the clicks

    {"type": "two-phones", "views": ["classes", "insights"], ...same text keys},

    {"type": "comparison", "view": "today",            # always slide 2 (rank 2)
     "headline": "More than a printable chart", "highlight": "printable chart",
     "sub": "It does the work a chart can't.",
     "versus": "PRINTABLE",                            # left column header (what buyers would use instead)
     "rows": [["All 320 Honolulu colors", true],       # true = the alternative has it too (grey tick)
              ["Old <-> new code converter", false]]}, # false = only this app (grey x); 5-6 rows

    {"type": "desktop", "view": "today", ...same text keys},

    {"type": "features", "headline": "What's inside",
     "items": [{"icon": "wb_sunny", "title": "Today", "text": "Your next step"}, ...],
     "footer": ["Works offline", "Private on your device"]}
  ]
}
Icons in "features" can be any Material Symbols name.
"""
import re
import argparse
import base64
import gzip
import html
import json
import pathlib

from playwright.sync_api import sync_playwright

HERE = pathlib.Path(__file__).resolve().parent
DEVICES = HERE.parent / "assets" / "device3d"   # three.js device models (devices.html)
ICON_BUNDLE = HERE.parent / "assets" / "material-symbols-outlined.json.gz"

W, H = 1500, 1125          # CSS px; rendered at 2x -> 3000x2250
PHONE_W, PHONE_H = 390, 844
DESK_W, DESK_H = 1440, 900

COLORS = {"terracotta": "#A65C48", "sage": "#5F7259"}

# Background and accent colors of the photos. "shop" is the default
# sage/terracotta look; a planner with its own palette passes
# "palette": "blue" (or an object with any of these keys) in photos.json.
PALETTES = {
    "shop": {"bg": "#F4F1EC", "b1": "#E6ECE3", "b2": "#F7E4DD", "soft": "#EEF2EC", "main": "#7B9075", "strong": "#5F7259"},
    "slate": {"bg": "#F1F3F3", "b1": "#E2E6E7", "b2": "#E9ECEC", "soft": "#E6E9EA", "main": "#4A5C6A", "strong": "#253745", "accent": "#4A5C6A"},
    "blue": {"bg": "#F3F7FA", "b1": "#E1F1FD", "b2": "#FDEDE8", "soft": "#E1F1FD", "main": "#0085ca", "strong": "#006aa1", "accent": "#0085ca"},
    "gold": {"bg": "#F7F3EC", "b1": "#EFE5D2", "b2": "#F2EBDD", "soft": "#FAF6F0", "main": "#B4883A", "strong": "#765F38", "accent": "#9A7430"},
}

BASE_CSS = """
*{box-sizing:border-box;margin:0;padding:0}
body{width:%(W)spx;height:%(H)spx;overflow:hidden;font-family:Inter,-apple-system,'Segoe UI',Roboto,sans-serif;
  background:var(--p-bg);color:#171717;-webkit-font-smoothing:antialiased;position:relative}
.blob{position:absolute;border-radius:50%%;filter:blur(2px)}


.b3{width:180px;height:180px;background:var(--p-soft);left:46%%;top:70px}
.brand{position:absolute;left:96px;bottom:64px;font-size:22px;font-weight:700;color:rgba(23,23,23,.55);letter-spacing:.02em;display:flex;align-items:center;gap:12px}
.brand .dot{width:12px;height:12px;border-radius:50%%;background:var(--p-main)}
h1{font-size:78px;line-height:1.05;letter-spacing:-.03em;font-weight:800}
h1 em{font-style:normal;color:var(--accent)}
.sub{font-size:31px;line-height:1.4;color:rgba(23,23,23,.66);margin-top:28px;font-weight:500}
ul.ticks{list-style:none;margin-top:40px;display:flex;flex-direction:column;gap:20px}
ul.ticks li{display:flex;align-items:center;gap:18px;font-size:27px;font-weight:600;color:rgba(23,23,23,.82)}
ul.ticks li::before{content:'';flex:0 0 40px;height:40px;border-radius:12px;background:var(--p-main) url("data:image/svg+xml,%%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24'%%3E%%3Cpath d='M9 16.2 4.8 12l-1.4 1.4L9 19 21 7l-1.4-1.4z' fill='white'/%%3E%%3C/svg%%3E") center/24px no-repeat}
.badges{display:flex;gap:16px;flex-wrap:wrap;margin-top:40px}
.badge{background:#fff;border:2px solid #E7E5E2;border-radius:40px;padding:14px 26px;font-size:24px;font-weight:700;color:var(--p-strong)}
.phone{position:absolute;width:%(PW)spx;border-radius:62px;background:#1C1C1E;padding:14px;box-shadow:0 40px 80px rgba(60,50,40,.22),0 8px 20px rgba(60,50,40,.12)}
.phone .screen{border-radius:48px;overflow:hidden;background:#fff;position:relative}
.phone .status{height:54px;background:#fff;display:flex;align-items:center;justify-content:space-between;padding:6px 34px 0;font-size:17px;font-weight:700;color:#171717}
.phone .island{position:absolute;top:12px;left:50%%;transform:translateX(-50%%);width:118px;height:34px;border-radius:20px;background:#1C1C1E}
.phone .bars{display:flex;gap:6px;align-items:center}
.phone .bars i{display:block;width:24px;height:12px;border:2px solid #171717;border-radius:4px;position:relative}
.phone .bars i::after{content:'';position:absolute;inset:1px;right:5px;background:#171717;border-radius:1px}
.phone .bars b{display:block;width:18px;height:12px;background:linear-gradient(90deg,#171717 0 3px,transparent 3px 5px,#171717 5px 8px,transparent 8px 10px,#171717 10px 13px,transparent 13px 15px,#171717 15px 18px);clip-path:polygon(0 100%%,100%% 0,100%% 100%%)}
.phone img{display:block;width:100%%}
.laptop{position:absolute}
.laptop .lid{background:#1C1C1E;border-radius:28px 28px 0 0;padding:18px 18px 22px;box-shadow:0 40px 80px rgba(60,50,40,.22)}
.laptop .lid img{display:block;width:100%%;border-radius:6px}
.laptop .base{height:26px;background:linear-gradient(#D8D6D2,#BDBAB5);border-radius:0 0 26px 26px;margin:0 -56px;position:relative}
.laptop .base::after{content:'';position:absolute;left:50%%;top:0;transform:translateX(-50%%);width:180px;height:10px;background:#A9A6A0;border-radius:0 0 10px 10px}
.grid{display:flex;flex-wrap:wrap;justify-content:center;gap:26px;margin-top:56px}
.grid .card{width:calc((100%% - 52px) / 3)}
.card{background:#fff;border:2px solid #E7E5E2;border-radius:28px;padding:30px 30px 32px;box-shadow:0 2px 6px rgba(23,23,23,.04)}
.card .ic{width:62px;height:62px;border-radius:18px;background:var(--p-soft);display:flex;align-items:center;justify-content:center;margin-bottom:20px}
.card .ic svg{width:36px;height:36px;fill:var(--p-strong)}
.card h3{font-size:28px;font-weight:800;letter-spacing:-.01em}
.card p{font-size:21px;line-height:1.4;color:rgba(23,23,23,.64);margin-top:8px;font-weight:500}
.footer{display:flex;gap:16px;justify-content:center;flex-wrap:wrap;margin-top:56px}
.grid.compact{gap:22px;margin-top:40px}
.grid.compact .card{padding:24px 28px 26px}
.grid.compact .card .ic{width:54px;height:54px;margin-bottom:14px}
.grid.compact .card p{font-size:20px}

body{background:#FBF8F6}
.glow{position:absolute;border-radius:50%%;filter:blur(110px);opacity:.9}
.g1{width:900px;height:760px;left:-320px;bottom:-380px;background:var(--glow1)}
.g2{width:820px;height:640px;left:330px;bottom:-430px;background:var(--glow2);opacity:.75}
.g3{width:900px;height:760px;right:-360px;bottom:-300px;background:var(--glow3)}
.g4{width:700px;height:520px;right:-120px;top:-380px;background:var(--glow4);opacity:.55}
.dots{position:absolute;left:44%%;top:30%%;width:620px;height:520px;opacity:.5;
  background-image:radial-gradient(rgba(23,23,23,.14) 1.4px,transparent 1.6px);background-size:16px 16px;
  -webkit-mask-image:radial-gradient(closest-side,#000,transparent);mask-image:radial-gradient(closest-side,#000,transparent)}
.badge{background:rgba(255,255,255,.78)}
.laptop.p3d{max-width:none}
.phone.p3d{background:none !important;padding:0 !important;border-radius:0 !important;box-shadow:none !important;width:auto !important;max-width:none}
.stage{position:absolute}
.stage .group{position:absolute;left:0;top:0}

"""


def esc(s):
    return html.escape(str(s or ""))


def headline(slide):
    h = esc(slide.get("headline", ""))
    hl = slide.get("highlight")
    if hl and esc(hl) in h:
        h = h.replace(esc(hl), f"<em>{esc(hl)}</em>", 1)
    return f"<h1>{h}</h1>"


def text_block(slide):
    out = headline(slide)
    if slide.get("sub"):
        out += f'<p class="sub">{esc(slide["sub"])}</p>'
    if slide.get("bullets"):
        out += '<ul class="ticks">' + "".join(f"<li>{esc(b)}</li>" for b in slide["bullets"]) + "</ul>"
    if slide.get("badges"):
        out += '<div class="badges">' + "".join(f'<span class="badge">{esc(b)}</span>' for b in slide["badges"]) + "</div>"
    return out


RENDER3D = {}


def render3d(img_uri, tilt, finish):
    """Renders the phone model in three.js and returns a cropped PNG data URI."""
    from PIL import Image
    import io
    pg = RENDER3D['page']
    url = pg.evaluate('([s, a, b, c, f]) => renderPhone(s, a, b, c, f)', [img_uri, tilt[0], tilt[1], tilt[2], finish])
    im = Image.open(io.BytesIO(base64.b64decode(url.split(',')[1]))).convert('RGBA')
    im = im.crop(im.getchannel('A').getbbox())
    buf = io.BytesIO(); im.save(buf, 'PNG')
    return 'data:image/png;base64,' + base64.b64encode(buf.getvalue()).decode(), im.size


def phone(img_uri, x, y, scale=1.0, rotate=0, z=1, tilt=None):
    """A device in the photo. With the 3D renderer running (the default), a tilted
    three.js phone rendered to a transparent PNG; with --flat, the old flat frame."""
    if tilt is not None and RENDER3D.get('page'):
        uri, (iw, ih) = render3d(img_uri, tilt, RENDER3D.get('finish', 'jet'))
        h = int(860 * scale)
        return (f'<img class="phone p3d" src="{uri}" style="position:absolute;left:{x}px;top:{y}px;height:{h}px;z-index:{z};'
                f'filter:drop-shadow(18px 34px 30px rgba(70,30,30,.30)) drop-shadow(4px 8px 8px rgba(70,30,30,.18))">')
    return phone_flat(img_uri, x, y, scale, rotate, z)


def phone_flat(img_uri, x, y, scale=1.0, rotate=0, z=1):
    w = int(390 * scale) + 28
    return (f'<div class="phone" style="left:{x}px;top:{y}px;width:{w}px;z-index:{z};'
            f'transform:rotate({rotate}deg)"><div class="screen"><div class="island"></div>'
            f'<div class="status"><span>9:41</span><span class="bars"><b></b><i></i></span></div>'
            f'<img src="{img_uri}"></div></div>')


def capture(browser, base, view, slide, desktop=False):
    vw, vh = (DESK_W, DESK_H) if desktop else (PHONE_W, PHONE_H - 54)
    ctx = browser.new_context(reduced_motion="reduce", viewport={"width": vw, "height": vh}, device_scale_factor=3 if not desktop else 1.5,
                              is_mobile=not desktop, has_touch=not desktop)
    ctx.route("**/fonts.g*/**", lambda r: r.abort())  # same as an offline buyer; Inter falls back locally
    pg = ctx.new_page()
    if slide.get("fast_forward_ms"):
        pg.clock.install()
    pg.goto(f"{base}?sample=1&view={view}")
    pg.wait_for_timeout(600)
    for sel in slide.get("click", []):
        loc = pg.locator(sel).first
        if loc.count():
            loc.click()
            pg.wait_for_timeout(250)
    for sel, val in slide.get("fill", []):
        loc = pg.locator(sel).first
        if loc.count():
            if loc.evaluate("e => e.tagName") == "SELECT":
                loc.select_option(index=int(val)) if str(val).isdigit() else loc.select_option(val)
            else:
                loc.fill(str(val))
            pg.wait_for_timeout(150)
    if slide.get("js"):
        pg.evaluate("() => { " + slide["js"] + " }")   # e.g. scroll a board sideways
        pg.wait_for_timeout(200)
    if slide.get("fast_forward_ms"):
        pg.clock.run_for(int(slide["fast_forward_ms"]))  # e.g. show a timer mid-session
        pg.wait_for_timeout(200)
    hide = slide.get("hide", [".fab"])
    if hide:
        pg.add_style_tag(content=",".join(hide) + "{display:none !important}")
    pg.add_style_tag(content="#toast-container{display:none !important}")
    if slide.get("scroll_to"):
        pg.evaluate("""(sel) => { const el = document.querySelector(sel); if (!el) return;
            const top = el.getBoundingClientRect().top + window.scrollY - 72; window.scrollTo(0, top); }""", slide["scroll_to"])
        pg.wait_for_timeout(200)
    png = pg.screenshot()
    ctx.close()
    return "data:image/png;base64," + base64.b64encode(png).decode()



def highlight_color(spec, pal):
    """Headline highlight color. Seller's rule: it always matches the planner's main
    theme color, on listing photos AND pins alike, so the set looks consistent.
    Order: an explicit "highlight_color" in the spec, else the palette's "main"
    (any custom or named palette), else the old named accent for the shop palette."""
    if spec.get("highlight_color"):
        return spec["highlight_color"]
    p = spec.get("palette", "shop")
    if p != "shop" and pal.get("main"):
        return pal["main"]
    return COLORS.get(spec.get("accent", ""), spec.get("accent") or pal.get("accent") or "#A65C48")

def slide_html(slide, shots, icons, name, accent):
    t = slide["type"]
    body = '<div class="glow g1"></div><div class="glow g2"></div><div class="glow g3"></div><div class="glow g4"></div><div class="dots"></div>'
    # Devices go inside a .stage (the area they should sit in). After render,
    # center_devices() measures the real device outlines (rotation included)
    # and centers the group inside its stage, so compositions never drift.
    def stage(l, t_, r, b, inner):
        return f'<div class="stage" style="left:{l}px;top:{t_}px;right:{r}px;bottom:{b}px"><div class="group">{inner}</div></div>'
    if t == "hero":
        while len(shots) < 3:  # fewer than 3 views: repeat so the layout still works
            shots.append(shots[len(shots) % max(1, len(shots))] if shots else "")
        a, b, c = shots[:3]
        body += f'<div class="txt" style="position:absolute;left:96px;top:0;bottom:0;width:540px;display:flex;flex-direction:column;justify-content:center">{text_block(slide)}</div>'
        body += stage(640, 30, 30, 30, phone(a, 0, 130, 0.86, z=2, tilt=(8, -26, 6)) + phone(b, 170, 0, 1.08, z=3, tilt=(10, -18, -7)) + phone(c, 400, 130, 0.86, z=1, tilt=(8, 26, -6)))
    elif t == "phone":
        left = slide.get("side", "right") == "left"
        tx = 760 if left else 96
        body += f'<div class="txt" style="position:absolute;left:{tx}px;top:0;bottom:0;width:650px;display:flex;flex-direction:column;justify-content:center">{text_block(slide)}</div>'
        body += stage(40, 40, 760, 40, phone(shots[0], 0, 0, 1.12, tilt=(10, 24, 8))) if left else stage(760, 40, 40, 40, phone(shots[0], 0, 0, 1.12, tilt=(10, -24, -8)))
    elif t == "comparison":
        left = slide.get("side", "right") == "left"
        tick = lambda c: (f'<span class="cbox" style="background:{c}"><svg viewBox="0 0 24 24"><path d="M6 12.5l4 4 8-9" fill="none" '
                          'stroke="#fff" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"/></svg></span>')
        cross = '<svg class="cx" viewBox="0 0 24 24"><path d="M6 6l12 12M18 6L6 18" stroke="#b9b4b4" stroke-width="2.4" stroke-linecap="round"/></svg>'
        arrow = '<svg style="width:1.05em;height:.7em;vertical-align:-.02em;margin:0 .12em" viewBox="0 0 30 16"><path d="M2 8h26M8 2L2 8l6 6M22 2l6 6-6 6" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"/></svg>'
        rows = "".join(f'<tr><td class="lab">{esc(r[0]).replace(chr(0x2194), arrow)}</td><td class="c">{tick("#c9c5c5") if (len(r) > 1 and r[1]) else cross}</td>'
                       f'<td class="c app">{tick("var(--accent)")}</td></tr>' for r in slide.get("rows", []))
        vs = esc(slide.get("versus", "PRINTABLE")).upper()
        table = (f'<style>.cmp{{width:100%;margin-top:40px;border-collapse:separate;border-spacing:0;background:rgba(255,255,255,.88);'
                 f'border-radius:22px;overflow:hidden;box-shadow:0 15px 40px rgba(60,20,40,.08)}}'
                 f'.cmp th{{height:62px;font-size:{19 if len(vs) > 9 else 22}px;font-weight:700;letter-spacing:.06em;text-align:center;color:#85828a;border-bottom:1.5px solid #eee8ea}}'
                 f'.cmp th.app{{color:var(--accent)}}.cmp td{{height:68px;border-bottom:1.5px solid #efeaec}}.cmp tr:last-child td{{border-bottom:0}}'
                 f'.cmp .lab{{padding-left:28px;font-size:26px;font-weight:600;color:#1b1b1f;white-space:nowrap}}'
                 f'.cmp .c{{text-align:center;width:24%}}.cmp .app{{background:color-mix(in srgb,var(--accent) 7%,white)}}'
                 f'.cbox{{display:inline-flex;width:39px;height:39px;border-radius:8px;vertical-align:middle;align-items:center;justify-content:center}}'
                 f'.cbox svg{{width:25px;height:25px}}.cx{{width:28px;height:28px;vertical-align:middle}}</style>'
                 f'<table class="cmp"><tr><th></th><th>{vs}</th><th class="app">THIS APP</th></tr>{rows}</table>')
        tx = 790 if left else 66
        body += (f'<div class="txt" style="position:absolute;left:{tx}px;top:0;bottom:0;width:680px;display:flex;flex-direction:column;justify-content:center">'
                 f'{headline(slide).replace(" <em>", "<br><em>", 1)}{"<p class=sub>" + esc(slide["sub"]) + "</p>" if slide.get("sub") else ""}{table}</div>')
        body += stage(40, 40, 790, 40, phone(shots[0], 0, 0, 1.12, tilt=(10, 24, 8))) if left else stage(790, 40, 40, 40, phone(shots[0], 0, 0, 1.12, tilt=(10, -24, -8)))
    elif t == "two-phones":
        body += f'<div class="txt" style="position:absolute;left:96px;top:0;bottom:0;width:580px;display:flex;flex-direction:column;justify-content:center">{text_block(slide)}</div>'
        body += stage(660, 30, 30, 30, phone(shots[0], 0, 80, 0.9, z=1, tilt=(10, -22, -10)) + phone(shots[1], 360, 0, 0.9, z=2, tilt=(10, -20, -4)))
    elif t == "desktop":
        body += f'<div class="txt" style="position:absolute;left:96px;right:96px;top:84px;text-align:center">{text_block(slide)}</div>'
        if RENDER3D.get('page'):
            lap = RENDER3D['page'].evaluate('([s, f]) => renderLaptop(s, -24, 15, f, 108)', [shots[0], RENDER3D.get('finish', 'jet')])
            from PIL import Image
            import io
            im = Image.open(io.BytesIO(base64.b64decode(lap.split(',')[1]))).convert('RGBA'); im = im.crop(im.getchannel('A').getbbox())
            buf = io.BytesIO(); im.save(buf, 'PNG'); lap = 'data:image/png;base64,' + base64.b64encode(buf.getvalue()).decode()
            inner = (f'<img class="laptop p3d" src="{lap}" style="position:absolute;left:0;top:0;width:900px;'
                     f'filter:drop-shadow(10px 40px 40px rgba(70,30,30,.28)) drop-shadow(2px 8px 8px rgba(70,30,30,.18))">')
            if len(shots) > 1:
                inner += phone(shots[1], 760, 120, 0.68, z=3, tilt=(6, -22, -4))
        else:
            inner = (f'<div class="laptop" style="left:0;top:0;width:860px"><div class="lid">'
                     f'<img src="{shots[0]}"></div><div class="base"></div></div>')
            if len(shots) > 1:
                inner += phone(shots[1], 740, 30, 0.66, 0, 3)
        body += stage(40, 400, 40, 50, inner)
    elif t == "features":
        cards = ""
        for it in slide.get("items", []):
            d = icons.get(it.get("icon", ""), {})
            svg = (f'<svg viewBox="{d.get("v", "0 -960 960 960")}"><path d="{d.get("o", "")}"/></svg>' if d else "")
            cards += f'<div class="card"><div class="ic">{svg}</div><h3>{esc(it.get("title"))}</h3><p>{esc(it.get("text"))}</p></div>'
        foot = ""
        if slide.get("footer"):
            foot = '<div class="footer">' + "".join(f'<span class="badge">{esc(f)}</span>' for f in slide["footer"]) + "</div>"
        body += (f'<div style="position:absolute;left:96px;right:96px;top:84px;text-align:center">{headline(slide)}'
                 f'{"<p class=sub>" + esc(slide["sub"]) + "</p>" if slide.get("sub") else ""}'
                 f'<div class="grid{" compact" if len(slide.get("items", [])) > 6 else ""}" style="text-align:left">{cards}</div>{foot}</div>')
    css = BASE_CSS % {"W": W, "H": H, "PW": PHONE_W}
    return (f'<!doctype html><html><head><meta charset="utf-8"><style>{css}</style></head>'
            f'<body style="--accent:{accent}">{body}</body></html>')


CENTER_JS = r"""
() => {
  const notes = [];
  document.querySelectorAll('.stage').forEach((st) => {
    const g = st.querySelector('.group'), sr = st.getBoundingClientRect();
    const rects = [...g.querySelectorAll('.phone, .laptop')].map((d) => {
      const r = d.getBoundingClientRect(); const base = d.querySelector('.base');
      if (base) { const b = base.getBoundingClientRect(); return { l: Math.min(r.left, b.left), t: r.top, r: Math.max(r.right, b.right), b: Math.max(r.bottom, b.bottom) }; }
      return { l: r.left, t: r.top, r: r.right, b: r.bottom };
    });
    if (!rects.length) return;
    const u = rects.reduce((a, r) => ({ l: Math.min(a.l, r.l), t: Math.min(a.t, r.t), r: Math.max(a.r, r.r), b: Math.max(a.b, r.b) }));
    const dx = (sr.left + sr.width / 2) - (u.l + u.r) / 2, dy = (sr.top + sr.height / 2) - (u.t + u.b) / 2;
    g.style.transform = `translate(${dx}px, ${dy}px)`;
    // After centering, the group must fit inside the canvas
    const W = document.body.clientWidth, H = document.body.clientHeight;
    if (u.l + dx < 16 || u.r + dx > W - 16) notes.push(`devices are ${Math.round(u.r - u.l)}px wide and run off the sides; use a smaller scale`);
    if (u.t + dy < 16 || u.b + dy > H - 16) notes.push(`devices are ${Math.round(u.b - u.t)}px tall and run off the top/bottom; use a smaller scale`);
  });
  // Text block must not overlap the devices
  const txt = document.querySelector('.txt'), devs = [...document.querySelectorAll('.phone, .laptop')];
  if (txt) { const t = txt.firstElementChild ? [...txt.children].reduce((a, c) => { const r = c.getBoundingClientRect(); return { l: Math.min(a.l, r.left), t: Math.min(a.t, r.top), r: Math.max(a.r, r.right), b: Math.max(a.b, r.bottom) }; }, { l: 1e9, t: 1e9, r: -1e9, b: -1e9 }) : null;
    if (t) devs.forEach((d) => { const r = d.getBoundingClientRect(); if (r.left < t.r - 4 && r.right > t.l + 4 && r.top < t.b - 4 && r.bottom > t.t + 4) notes.push('a device overlaps the headline text'); }); }
  return [...new Set(notes)];
}
"""


def mix(a, b, t):
    """Blend two #rrggbb colors: t=0 gives a, t=1 gives b."""
    a = [int(a[i:i + 2], 16) for i in (1, 3, 5)]; b = [int(b[i:i + 2], 16) for i in (1, 3, 5)]
    return "#" + "".join("%02x" % round(a[k] + (b[k] - a[k]) * t) for k in range(3))


def default_glow(pal):
    """Four soft background glows from the palette: the main color (bottom left),
    a paler tint (bottom middle), a warm peach blended toward the main color
    (bottom right) and a faint tint (top right). Override with "glow" in the spec."""
    m = pal.get("main", "#7B9075")
    return [mix(m, "#ffffff", 0.45), mix(m, "#ffffff", 0.72), mix("#F6BE92", m, 0.18), mix(m, "#ffffff", 0.86)]


def start_devices(browser, finish):
    """Opens the three.js device page. Files are served from the skill's assets
    through a Playwright route (ES modules can't load from file://), so no local
    server is needed."""
    pg = browser.new_page(viewport={"width": 1500, "height": 2100})
    def serve(route):
        rel = route.request.url.split("://devices.local/", 1)[1].split("?")[0] or "devices.html"
        f = (DEVICES / rel).resolve()
        if DEVICES.resolve() in f.parents and f.is_file():
            route.fulfill(path=str(f))
        else:
            route.fulfill(status=404, body="")
    pg.route("http://devices.local/**", serve)
    pg.goto("http://devices.local/devices.html")
    pg.wait_for_function("window.ready === true", timeout=90000)
    RENDER3D["page"] = pg
    RENDER3D["finish"] = finish
    return pg


GL_ARGS = ["--use-gl=angle", "--use-angle=swiftshader", "--enable-unsafe-swiftshader", "--ignore-gpu-blocklist"]


def boost_saturation(fn, factor, keep_dir=None):
    """The seller's rule: every listing photo and pin gets +50 saturation (factor 1.5),
    so colors pop in Etsy search thumbnails. Applied to the finished image."""
    if not factor or abs(factor - 1) < 0.001: return
    from PIL import Image, ImageEnhance
    im = Image.open(fn).convert("RGB")
    if keep_dir:
        keep_dir.mkdir(parents=True, exist_ok=True); im.save(keep_dir / pathlib.Path(fn).name)
    ImageEnhance.Color(im).enhance(factor).save(fn)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("html")
    ap.add_argument("spec")
    ap.add_argument("--out", default="listing-photos")
    ap.add_argument("--flat", action="store_true", help="old flat CSS phone frames instead of 3D devices")
    ap.add_argument("--saturation", type=float, default=None, help="color boost, 1.5 = +50 (the default rule); 1 = off")
    ap.add_argument("--keep-original", action="store_true", help="also save the un-boosted images in <out>/original/")
    args = ap.parse_args()

    spec = json.loads(pathlib.Path(args.spec).read_text())
    out = pathlib.Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    base = pathlib.Path(args.html).resolve().as_uri()
    icons = json.loads(gzip.decompress(ICON_BUNDLE.read_bytes()))
    pal = spec.get("palette", "shop")
    pal = dict(PALETTES["shop"], **(PALETTES.get(pal, {}) if isinstance(pal, str) else pal))
    accent = highlight_color(spec, pal)
    glows = spec.get("glow") or default_glow(pal)
    accent = accent + ";" + ";".join(f"--p-{k}:{v}" for k, v in pal.items() if k != "accent") + ";" + ";".join(f"--glow{i+1}:{c}" for i, c in enumerate(glows))
    name = spec.get("name", "")
    sat = args.saturation if args.saturation is not None else spec.get("saturation", 1.5)

    with sync_playwright() as p:
        browser = p.chromium.launch(args=GL_ARGS)
        if not args.flat:
            start_devices(browser, spec.get("finish", "jet"))
        for i, slide in enumerate(spec["slides"], 1):
            t = slide["type"]
            def many(n):
                # each entry is a view name, or {"view": ..., "click": ..., "scroll_to": ...}
                res = []
                for v in slide["views"][:n]:
                    if isinstance(v, dict):
                        res.append(capture(browser, base, v["view"], {**slide, **v}))
                    else:
                        res.append(capture(browser, base, v, {k: x for k, x in slide.items() if k not in ("click", "scroll_to", "fill", "js")}))
                return res
            if t == "hero":
                shots = many(3)
            elif t == "two-phones":
                shots = many(2)
            elif t in ("phone", "comparison"):
                shots = [capture(browser, base, slide["view"], slide)]
            elif t == "desktop":
                shots = [capture(browser, base, slide["view"], slide, desktop=True)]
                if slide.get("phone_view"):
                    shots.append(capture(browser, base, slide["phone_view"], slide))
            else:
                shots = []
            page = browser.new_page(viewport={"width": W, "height": H}, device_scale_factor=2)
            page.set_content(slide_html(slide, shots, icons, name, accent))
            page.wait_for_timeout(150)
            off = page.evaluate(CENTER_JS)
            for o in off:
                print(f"  WARNING slide {i}: {o}")
            page.wait_for_timeout(300)
            fn = out / ("%02d-%s.png" % (i, re.sub(r"[^a-z0-9]+", "-", str(slide.get("view") or t).lower()).strip("-")))
            page.screenshot(path=str(fn))
            boost_saturation(fn, sat, out / "original" if args.keep_original else None)
            page.close()
            print("saved", fn)
        browser.close()


if __name__ == "__main__":
    main()
