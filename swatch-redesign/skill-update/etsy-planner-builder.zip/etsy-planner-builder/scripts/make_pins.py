#!/usr/bin/env python3
"""Make Pinterest pins (1000x1500, Pinterest's recommended 2:3 ratio,
rendered at 2x = 2000x3000) for a planner, plus a text file with each
pin's title, description, alt text and board suggestion. Uses the same
3D devices and blurred-gradient background as make_listing_photos.py
("finish", "glow" and --flat work the same way).

Usage:
  python3 make_pins.py planner.html pins.json --out pinterest

pins.json:
{
  "name": "Job Search Tracker",
  "palette": "slate",                      # same palettes as make_listing_photos.py
  "brand": "LUCIAN VOX DESIGNS",           # small wordmark at the bottom of every pin
  "cta": "Instant download on Etsy",       # small line under the badges
  "board": "Job Search Tips & Tools",      # default board suggestion
  "pins": [
    {"layout": "hero", "views": ["home", {"view": "jobs", "click": [...]}, "insights"],
     "headline": "Organize your job search", "highlight": "job search",
     "sub": "...", "badges": ["Phone & computer", "No subscription"],
     "title": "Pin title (max 100 chars)", "description": "Pin description (max 500)",
     "alt": "Alt text describing the image", "board": "optional board"},
    {"layout": "phone", "view": "home", ...},          # one big phone
    {"layout": "two-phones", "views": [...], ...},      # two phones side by side
    {"layout": "list", "view": "home", "bullets": [...], ...}  # checklist + phone peeking up
  ]
}
Views take the same options as make_listing_photos.py (click, fill, js,
scroll_to, fast_forward_ms, hide).
"""
import argparse, json, gzip, pathlib, sys
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
import make_listing_photos as M
from playwright.sync_api import sync_playwright

W, H = 1000, 1500

PIN_CSS = """
*{box-sizing:border-box;margin:0;padding:0}
body{width:%(W)spx;height:%(H)spx;overflow:hidden;font-family:Inter,-apple-system,'Segoe UI',Roboto,sans-serif;
  background:var(--p-bg);color:#171717;-webkit-font-smoothing:antialiased;position:relative}
.blob{position:absolute;border-radius:50%%}

body{background:#FBF8F6}
.glow{position:absolute;border-radius:50%%;filter:blur(120px)}
.g1{width:900px;height:900px;left:-380px;bottom:-360px;background:var(--glow1);opacity:.9}
.g2{width:800px;height:700px;left:200px;bottom:-460px;background:var(--glow2);opacity:.75}
.g3{width:900px;height:900px;right:-460px;bottom:-200px;background:var(--glow3);opacity:.85}
.g4{width:800px;height:600px;right:-200px;top:-420px;background:var(--glow4);opacity:.55}
.phone.p3d{background:none !important;padding:0 !important;border-radius:0 !important;box-shadow:none !important;width:auto !important;max-width:none}
.peek .phone.p3d{position:relative !important;display:block;margin:0 auto}
.top{position:absolute;left:72px;right:72px;top:96px;text-align:center}
h1{font-size:92px;line-height:1.02;letter-spacing:-.035em;font-weight:800;text-wrap:balance}
h1 em{font-style:normal;color:var(--accent)}
.sub{font-size:36px;line-height:1.35;color:rgba(23,23,23,.68);margin-top:26px;font-weight:500;text-wrap:balance}
ul.ticks{list-style:none;display:flex;flex-direction:column;gap:22px;text-align:left}
ul.ticks li{display:flex;align-items:center;gap:20px;font-size:34px;font-weight:600;color:rgba(23,23,23,.84);background:#fff;border:2px solid rgba(23,23,23,.06);border-radius:24px;padding:22px 26px;box-shadow:0 2px 8px rgba(23,23,23,.04)}
ul.ticks li::before{content:'';flex:0 0 48px;height:48px;border-radius:14px;background:var(--p-main) url("data:image/svg+xml,%%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24'%%3E%%3Cpath d='M9 16.2 4.8 12l-1.4 1.4L9 19 21 7l-1.4-1.4z' fill='white'/%%3E%%3C/svg%%3E") center/28px no-repeat}
.foot{position:absolute;left:0;right:0;bottom:56px;display:flex;flex-direction:column;align-items:center;gap:18px;z-index:5}
.badges{display:flex;gap:14px;flex-wrap:wrap;justify-content:center}
.badge{background:#fff;border:2px solid rgba(23,23,23,.08);border-radius:40px;padding:14px 26px;font-size:26px;font-weight:700;color:var(--p-strong);box-shadow:0 4px 14px rgba(23,23,23,.06)}
.cta{font-size:24px;font-weight:700;color:rgba(23,23,23,.55);letter-spacing:.01em}
.brand{font-size:20px;font-weight:800;letter-spacing:.32em;color:rgba(23,23,23,.42)}
.phone{position:absolute;width:%(PW)spx;border-radius:62px;background:#1C1C1E;padding:14px;box-shadow:0 40px 90px rgba(40,40,40,.25),0 8px 22px rgba(40,40,40,.12)}
.phone .screen{border-radius:48px;overflow:hidden;background:#fff;position:relative}
.phone .status{height:54px;background:#fff;display:flex;align-items:center;justify-content:space-between;padding:6px 34px 0;font-size:17px;font-weight:700;color:#171717}
.phone .island{position:absolute;top:12px;left:50%%;transform:translateX(-50%%);width:118px;height:34px;border-radius:20px;background:#1C1C1E}
.phone .bars{display:flex;gap:6px;align-items:center}
.phone .bars i{display:block;width:24px;height:12px;border:2px solid #171717;border-radius:4px;position:relative}
.phone .bars i::after{content:'';position:absolute;inset:1px;right:5px;background:#171717;border-radius:1px}
.phone .bars b{display:block;width:18px;height:12px;background:linear-gradient(90deg,#171717 0 3px,transparent 3px 5px,#171717 5px 8px,transparent 8px 10px,#171717 10px 13px,transparent 13px 15px,#171717 15px 18px);clip-path:polygon(0 100%%,100%% 0,100%% 100%%)}
.phone img{display:block;width:100%%}
.stage{position:absolute}
.stage .group{position:absolute;left:0;top:0}
.peek{position:absolute;left:50%%;transform:translateX(-50%%);bottom:-260px}
.peek .phone{position:relative;left:0 !important;top:0 !important}
"""

# Centers the device group inside its stage and reports anything that runs
# off the pin or covers the text. "peek" layouts let the phone run off the
# bottom on purpose, so the bottom edge is not checked there.
FIT_JS = r"""
(peek) => {
  // The phones fill whatever space the headline and badges leave: the stage
  // runs from 36px under the text to 30px above the badges, and the phone
  // group is scaled down to fit it and centered. Long headlines therefore
  // never collide with the phones.
  const notes = [];
  const box = (sel) => { const e = document.querySelector(sel); if (!e) return null; const kids = [...e.children]; if (!kids.length) return null;
    return kids.reduce((a, c) => { const r = c.getBoundingClientRect(); return { l: Math.min(a.l, r.left), t: Math.min(a.t, r.top), r: Math.max(a.r, r.right), b: Math.max(a.b, r.bottom) }; }, { l: 1e9, t: 1e9, r: -1e9, b: -1e9 }); };
  const top = box('.top'), foot = box('.foot');
  document.querySelectorAll('.stage').forEach((st) => {
    if (top) st.style.top = (top.b + 36) + 'px';
    if (foot) st.style.bottom = (innerHeight - foot.t + 30) + 'px';
    const g = st.querySelector('.group'), sr = st.getBoundingClientRect(), gr = g.getBoundingClientRect();
    const rs = [...g.querySelectorAll('.phone')].map((d) => d.getBoundingClientRect());
    if (!rs.length) return;
    const u = rs.reduce((a, r) => ({ l: Math.min(a.l, r.left), t: Math.min(a.t, r.top), r: Math.max(a.r, r.right), b: Math.max(a.b, r.bottom) }), { l: 1e9, t: 1e9, r: -1e9, b: -1e9 });
    const s = Math.min(1, sr.height / (u.b - u.t), sr.width / (u.r - u.l));
    if (s < 0.55) notes.push('little room is left for the phones (scaled to ' + Math.round(s * 100) + '%); shorten the headline or sub');
    const cx = (u.l + u.r) / 2, cy = (u.t + u.b) / 2;
    g.style.transformOrigin = (cx - gr.left) + 'px ' + (cy - gr.top) + 'px';
    g.style.transform = `translate(${sr.left + sr.width / 2 - cx}px, ${sr.top + sr.height / 2 - cy}px) scale(${s})`;
  });
  document.querySelectorAll('.phone').forEach((d) => {
    const r = d.getBoundingClientRect();
    if (r.left < 8 || r.right > innerWidth - 8) notes.push('a phone runs off the side');
    if (top && r.top < top.b - 4 && r.left < top.r && r.right > top.l) notes.push('a phone overlaps the headline');
    if (foot && !peek && r.bottom > foot.t + 4 && r.left < foot.r && r.right > foot.l) notes.push('a phone overlaps the badges at the bottom');
  });
  if (top && top.b > innerHeight * 0.42) notes.push('the headline block is taller than 42% of the pin; shorten the headline or sub');
  return [...new Set(notes)];
}
"""


def headline(p):
    return M.headline(p) + (f'<p class="sub">{M.esc(p["sub"])}</p>' if p.get("sub") else "")


def foot(p, spec):
    badges = p.get("badges", spec.get("badges", []))
    out = '<div class="foot">'
    if badges:
        out += '<div class="badges">' + "".join(f'<span class="badge">{M.esc(b)}</span>' for b in badges) + "</div>"
    if spec.get("cta"):
        out += f'<div class="cta">{M.esc(spec["cta"])}</div>'
    if spec.get("brand"):
        out += f'<div class="brand">{M.esc(spec["brand"])}</div>'
    return out + "</div>"


def pin_html(p, shots, spec, style):
    lay = p.get("layout", "phone")
    body = '<div class="glow g1"></div><div class="glow g2"></div><div class="glow g3"></div><div class="glow g4"></div>'
    stage = lambda t, b, inner: f'<div class="stage" style="left:24px;right:24px;top:{t}px;bottom:{b}px"><div class="group">{inner}</div></div>'
    ph = M.phone
    if lay == "hero":
        body += f'<div class="top">{headline(p)}</div>'
        a, b, c = (shots * 3)[:3]
        body += stage(520, 250, ph(a, 0, 90, 0.86, z=2, tilt=(8, -26, 6)) + ph(b, 230, 0, 1.0, z=3, tilt=(10, -18, -6)) + ph(c, 480, 90, 0.86, z=1, tilt=(8, 26, -6)))
        body += foot(p, spec)
    elif lay == "two-phones":
        body += f'<div class="top">{headline(p)}</div>'
        body += stage(520, 250, ph(shots[0], 0, 60, 0.98, z=1, tilt=(10, -22, -8)) + ph(shots[1], 420, 0, 0.98, z=2, tilt=(10, -20, -4)))
        body += foot(p, spec)
    elif lay == "list":
        body += f'<div class="top">{M.headline(p)}</div>'
        bl = p.get("bullets", [])
        body += f'<div style="position:absolute;left:96px;right:96px;top:{p.get("list_top", 400)}px"><ul class="ticks">' + "".join(f"<li>{M.esc(x)}</li>" for x in bl) + "</ul></div>"
        body += f'<div class="peek" style="width:{int(390 * 1.12) + 28}px;bottom:{p.get("peek_bottom", -430)}px">' + ph(shots[0], 0, 0, 1.12, tilt=(14, -10, -4)) + "</div>"
    else:  # phone
        body += f'<div class="top">{headline(p)}</div>'
        body += stage(470, 240, ph(shots[0], 0, 0, 1.12, tilt=(10, -24, -8)))
        body += foot(p, spec)
    css = PIN_CSS % {"W": W, "H": H, "PW": M.PHONE_W}
    return f'<!doctype html><html><head><meta charset="utf-8"><style>{css}</style></head><body style="--accent:{style}">{body}</body></html>'


def boost_saturation(fn, factor, keep_dir=None):
    """The seller's rule: every listing photo and pin gets +50 saturation (factor 1.5),
    so colors pop in Etsy search thumbnails. Applied to the finished image."""
    if not factor or abs(factor - 1) < 0.001: return
    from PIL import Image, ImageEnhance
    im = Image.open(fn).convert("RGB")
    if keep_dir:
        keep_dir.mkdir(parents=True, exist_ok=True); im.save(keep_dir / pathlib.Path(fn).name)
    ImageEnhance.Color(im).enhance(factor).save(fn)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("html"); ap.add_argument("spec"); ap.add_argument("--out", default="pinterest"); ap.add_argument("--flat", action="store_true", help="old flat CSS phone frames instead of 3D"); ap.add_argument("--saturation", type=float, default=None, help="color boost, 1.5 = +50 (default rule)")
    a = ap.parse_args()
    spec = json.loads(pathlib.Path(a.spec).read_text())
    out = pathlib.Path(a.out); out.mkdir(parents=True, exist_ok=True)
    base = pathlib.Path(a.html).resolve().as_uri()
    pal = spec.get("palette", "shop")
    pal = dict(M.PALETTES["shop"], **(M.PALETTES.get(pal, {}) if isinstance(pal, str) else pal))
    accent = M.highlight_color(spec, pal)
    glows = spec.get("glow") or M.default_glow(pal)
    style = accent + ";" + ";".join(f"--p-{k}:{v}" for k, v in pal.items() if k != "accent") + ";" + ";".join(f"--glow{i+1}:{c}" for i, c in enumerate(glows))
    lines, problems = [], 0
    with sync_playwright() as pw:
        br = pw.chromium.launch(args=M.GL_ARGS)
        if not a.flat:
            M.start_devices(br, spec.get("finish", "jet"))
        for i, p in enumerate(spec["pins"], 1):
            views = p.get("views") or [p.get("view", "home")]
            shots = [M.capture(br, base, v["view"], {**p, **v}) if isinstance(v, dict) else M.capture(br, base, v, {k: x for k, x in p.items() if k not in ("click", "scroll_to", "fill", "js")} if p.get("views") else p) for v in views]
            page = br.new_page(viewport={"width": W, "height": H}, device_scale_factor=2)
            page.set_content(pin_html(p, shots, spec, style)); page.wait_for_timeout(150)
            for n in page.evaluate(FIT_JS, p.get("layout") == "list"):
                print(f"  WARNING pin {i}: {n}"); problems += 1
            page.wait_for_timeout(250)
            fn = out / f"pin-{i:02d}.png"; page.screenshot(path=str(fn)); page.close(); boost_saturation(fn, a.saturation if a.saturation is not None else spec.get("saturation", 1.5)); print("saved", fn)
            t, d = p.get("title", ""), p.get("description", "")
            if len(t) > 100: print(f"  WARNING pin {i}: title is {len(t)} characters (Pinterest max 100)"); problems += 1
            if len(d) > 500: print(f"  WARNING pin {i}: description is {len(d)} characters (Pinterest max 500)"); problems += 1
            lines.append(f"PIN {i}  ({fn.name})\nBoard: {p.get('board', spec.get('board', ''))}\n\nTitle ({len(t)}/100):\n{t}\n\nDescription ({len(d)}/500):\n{d}\n\nAlt text:\n{p.get('alt', '')}\n\nLink: paste your Etsy listing URL\n" + "-" * 60)
        br.close()
    head = (f"PINTEREST PINS: {spec.get('name', '')}\n"
            "Pin size: 1000x1500 (2:3), saved at 2x. Upload each image, paste its title,\n"
            "description and alt text, set the link to your Etsy listing and pick the board.\n"
            "Space them out: one new pin every few days works better than all at once.\n" + "=" * 60 + "\n")
    (out / "pinterest-pins.txt").write_text(head + "\n".join(lines) + "\n")
    print("saved", out / "pinterest-pins.txt", f"({problems} warning(s))")


if __name__ == "__main__":
    main()
