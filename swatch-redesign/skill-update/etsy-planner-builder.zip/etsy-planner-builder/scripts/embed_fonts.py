#!/usr/bin/env python3
"""Embed a planner's display + body fonts into the HTML file, so the design
looks the same online, offline and on first open (no Google Fonts needed).

Usage:
  python3 embed_fonts.py planner.html --display "Fraunces:600,700" --body "Geist:400,600,700"

Fonts come from assets/fonts (pre-subset Latin WOFF files, SIL Open Font
License, fine to embed in products you sell; the license notice is added as
a CSS comment). Writes @font-face rules between /*FONTS:START*/ and
/*FONTS:END*/ at the top of the first <style> and sets the tokens
--font-display and --font-body. Re-run safely; it replaces its own block.
It also removes the Google Fonts <link> tags, which are no longer needed.

Available: Inter 400/500/600/700 · Inter Display 600/700 · Fraunces 600/700 · Geist 400/500/600/700 · Bricolage Grotesque
600/800 · Space Grotesk 500/700 · Newsreader 500/600 · Instrument Serif 400 ·
Nunito 400/600/700/800/900 · Fredoka 500/600/700.
"""
import argparse, base64, pathlib, re, sys

FONTS = pathlib.Path(__file__).resolve().parent.parent / "assets" / "fonts"
FALLBACK = {
    "serif": "ui-serif, Georgia, 'Times New Roman', serif",
    "sans": "-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif",
}
SERIFS = {"Fraunces", "Newsreader", "Instrument Serif"}


def parse(spec):
    fam, _, ws = spec.partition(":")
    return fam.strip(), [int(w) for w in (ws or "400").split(",") if w.strip()]


def face(fam, w):
    fn = FONTS / f"{fam.replace(' ', '')}-{w}.woff"
    if not fn.exists():
        sys.exit(f"Missing font file {fn.name}. Available: " + ", ".join(sorted(p.stem for p in FONTS.glob('*.woff'))))
    b64 = base64.b64encode(fn.read_bytes()).decode()
    return (f"@font-face{{font-family:'{fam}';font-style:normal;font-weight:{w};font-display:swap;"
            f"src:url(data:font/woff;base64,{b64}) format('woff');}}")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("html"); ap.add_argument("--display", required=True); ap.add_argument("--body", required=True)
    a = ap.parse_args()
    p = pathlib.Path(a.html); s = p.read_text()
    (df, dws), (bf, bws) = parse(a.display), parse(a.body)
    stack = lambda f: f"'{f}', " + FALLBACK["serif" if f in SERIFS else "sans"]
    fams = sorted({df, bf})
    block = ("/*FONTS:START*/\n/* Embedded fonts: " + ", ".join(fams) + ". Licensed under the SIL Open Font License 1.1"
             " (https://openfontlicense.org). Copyright their respective authors. */\n"
             + "\n".join(face(df, w) for w in dws) + "\n" + "\n".join(face(bf, w) for w in bws if not (bf == df and w in dws))
             + f"\n:root{{ --font-display: {stack(df)}; --font-body: {stack(bf)}; --font: var(--font-body); }}\n/*FONTS:END*/\n")
    s = re.sub(r"/\*FONTS:START\*/.*?/\*FONTS:END\*/\n?", "", s, flags=re.S)
    s = s.replace("<style>", "<style>\n" + block, 1)
    s = re.sub(r'\s*<link rel="preconnect" href="https://fonts\.(googleapis|gstatic)\.com"[^>]*>', "", s)
    s = re.sub(r'\s*<link href="https://fonts\.googleapis\.com/[^"]*" rel="stylesheet">', "", s)
    p.write_text(s)
    kb = sum((FONTS / f"{f.replace(' ', '')}-{w}.woff").stat().st_size for f, ws in ((df, dws), (bf, bws)) for w in ws) // 1024
    print(f"Embedded {df} {dws} + {bf} {bws} (~{kb} KB before base64)")


if __name__ == "__main__":
    main()
