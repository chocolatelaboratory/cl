#!/usr/bin/env python3
"""Embed the Material Symbols icons a planner uses directly into its HTML.

Icons drawn as inline SVG need no font download, so they show instantly
for every buyer: offline, on school/work wifi that blocks Google, in a
private tab, or on a first open with no cache.

What it does (safe to re-run after every change):
  1. Finds every icon name the file uses:
       <span class="icon">settings</span>      (static markup)
       icon('settings')  icon("settings", 18)  (JS helper calls)
       icon:'settings'   icon: "settings"      (config lists like NAV)
       /* icons: name1, name2 */              (names built dynamically)
  2. Writes a compact ICONS map with just those shapes between the
     /*ICONS:START*/ and /*ICONS:END*/ markers in the file's script.
  3. Removes the Material Symbols Google Fonts <link> if present.

Usage:  python3 embed_icons.py planner.html [--extra name1,name2]
Exit code 1 if a name isn't a real Material Symbol (typo check).

Icon artwork: Material Symbols by Google, Apache License 2.0
(see assets/MATERIAL-SYMBOLS-LICENSE.txt). Fine to use in products you sell.
"""
import argparse
import gzip
import json
import pathlib
import re
import sys

HERE = pathlib.Path(__file__).resolve().parent
BUNDLE = HERE.parent / "assets" / "material-symbols-outlined.json.gz"
START, END = "/*ICONS:START*/", "/*ICONS:END*/"

PATTERNS = [
    r'<span class="icon"[^>]*>\s*([a-z0-9_]+)\s*</span>',
    r'\bicon\(\s*[\'"]([a-z0-9_]+)[\'"]',
    r'\bicon\s*:\s*[\'"]([a-z0-9_]+)[\'"]',
]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("html")
    ap.add_argument("--extra", default="", help="comma-separated icon names to include")
    args = ap.parse_args()

    path = pathlib.Path(args.html)
    src = path.read_text(encoding="utf-8")
    icons = json.loads(gzip.decompress(BUNDLE.read_bytes()))

    names = set()
    for p in PATTERNS:
        names.update(re.findall(p, src))
    for block in re.findall(r"/\*\s*icons:\s*([^*]+)\*/", src):
        names.update(n.strip() for n in block.split(",") if n.strip())
    names.update(n.strip() for n in args.extra.split(",") if n.strip())
    names.discard("name")  # the helper's own parameter

    missing = sorted(n for n in names if n not in icons)
    used = {n: icons[n] for n in sorted(names) if n in icons}

    block = START + "\n  var ICONS = " + json.dumps(used, separators=(",", ":")) + ";\n  " + END
    if START in src and END in src:
        src = re.sub(re.escape(START) + r".*?" + re.escape(END), lambda m: block, src, flags=re.S)
    else:
        print(f"No {START} ... {END} markers found. Add them inside the <script> (the starter template has them).")
        sys.exit(1)

    src, n_links = re.subn(r'[ \t]*<link[^>]+Material\+Symbols[^>]*>\n?', "", src)
    path.write_text(src, encoding="utf-8")

    kb = len(json.dumps(used)) / 1024
    print(f"Embedded {len(used)} icons ({kb:.1f} KB): {', '.join(used)}")
    if n_links:
        print("Removed the Material Symbols font link (no longer needed).")
    if "document.fonts.check" in src:
        print("Note: file still calls document.fonts.check() for icons; remove that old guard.")
    if missing:
        print("NOT FOUND (typo, or not a Material Symbol): " + ", ".join(missing))
        sys.exit(1)


if __name__ == "__main__":
    main()
