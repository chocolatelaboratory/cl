#!/usr/bin/env python3
"""Mobile layout checker for single-file planner apps.

Opens the planner in a headless phone-sized browser, visits every view
(any element with id="view-<name>") and every in-view tab (data-action="...-tab") using the ?view=<name>&sample=1 demo
hook, and reports the problems that most often break a planner on a phone:

  * the page scrolls sideways (something is wider than the screen)
  * an element pokes past the right/left edge of the screen
  * tap targets smaller than 44x44px
  * form fields with uneven padding or native dropdown styling
  * text spilling out of its box or out of a progress ring
  * text inputs under 16px (iOS Safari zooms the page when you tap them)
  * content hidden behind the fixed bottom nav
  * raw icon names showing as text, or icons that were never embedded
  * JavaScript errors

It also saves a full-page screenshot of every view at each width so you
can eyeball them.

Usage:
  python3 check_mobile.py planner.html [--out DIR] [--widths 320,375,430]

Needs: pip install playwright && playwright install chromium
Exit code is 1 when any problem is found, 0 when clean.
"""
import argparse
import re
import json
import pathlib
import sys

from playwright.sync_api import sync_playwright

PROBE_JS = r"""
() => {
  const vw = window.innerWidth;
  const issues = [];
  const isVisible = (el) => {
    const cs = getComputedStyle(el);
    if (cs.display === 'none' || cs.visibility === 'hidden' || parseFloat(cs.opacity) === 0) return false;
    const r = el.getBoundingClientRect();
    return r.width > 0 && r.height > 0;
  };
  const label = (el) => {
    let s = el.tagName.toLowerCase();
    if (el.id) s += '#' + el.id;
    if (el.classList.length) s += '.' + [...el.classList].slice(0, 3).join('.');
    const t = (el.getAttribute('aria-label') || el.textContent || '').trim().replace(/\s+/g, ' ').slice(0, 40);
    return t ? `${s} "${t}"` : s;
  };
  // Inside a deliberate horizontal scroller (pill rows, tables)? Then
  // sticking out of the screen is fine: the user swipes it.
  const inScroller = (el) => {
    for (let p = el.parentElement; p && p !== document.body; p = p.parentElement) {
      const ox = getComputedStyle(p).overflowX;
      if (ox === 'auto' || ox === 'scroll' || ox === 'hidden' || ox === 'clip') return true;
    }
    return false;
  };
  const inFixedChrome = (el) => !!el.closest('.sidebar');

  // 1. Sideways page scroll
  const sw = document.documentElement.scrollWidth;
  if (sw > vw + 1) issues.push({ check: 'page-scrolls-sideways', detail: `page is ${sw}px wide on a ${vw}px screen` });

  // 2. Elements past the screen edge (report outermost offenders only)
  const offenders = [];
  for (const el of document.querySelectorAll('body *')) {
    if (!isVisible(el) || inScroller(el) || inFixedChrome(el)) continue;
    const r = el.getBoundingClientRect();
    if (r.right > vw + 1 || r.left < -1) {
      if (!offenders.some((o) => o.contains(el))) offenders.push(el);
    }
  }
  for (const el of offenders.slice(0, 8)) {
    const r = el.getBoundingClientRect();
    issues.push({ check: 'off-screen-element', detail: `${label(el)} spans ${Math.round(r.left)}..${Math.round(r.right)}px (screen ${vw}px)` });
  }

  // 3. Tap targets
  const tappables = document.querySelectorAll('button, a[href], input:not([type=hidden]):not([type=file]), select, textarea, [data-action], [role=button], [onclick]');
  const small = [];
  for (const el of tappables) {
    if (!isVisible(el) || inFixedChrome(el)) continue;
    // A small control wrapped in a bigger tappable parent is fine.
    const parent = el.parentElement && el.parentElement.closest('button, a[href], label, [data-action]');
    if (parent && parent !== el) {
      const pr = parent.getBoundingClientRect();
      if (pr.width >= 44 && pr.height >= 44) continue;
    }
    const r = el.getBoundingClientRect();
    if (r.width < 44 || r.height < 44) small.push(`${label(el)} is ${Math.round(r.width)}x${Math.round(r.height)}`);
  }
  if (small.length) issues.push({ check: 'small-tap-targets', detail: small.slice(0, 12).join('; ') + (small.length > 12 ? `; ...and ${small.length - 12} more` : '') });

  // 4. iOS zoom-on-focus
  const zoomers = [];
  for (const el of document.querySelectorAll('input:not([type=checkbox]):not([type=radio]):not([type=hidden]):not([type=file]):not([type=range]), select, textarea')) {
    if (!isVisible(el) || inFixedChrome(el)) continue;
    const fs = parseFloat(getComputedStyle(el).fontSize);
    if (fs < 16) zoomers.push(`${label(el)} (${fs}px)`);
  }
  if (zoomers.length) issues.push({ check: 'ios-zoom-inputs', detail: 'inputs under 16px make iPhones zoom in: ' + zoomers.slice(0, 8).join('; ') });

  // 4b. Text cut off inside fields (dropdown choices, placeholders)
  const cv = document.createElement('canvas').getContext('2d');
  const clipped = [];
  for (const el of document.querySelectorAll('select, input[placeholder]')) {
    if (!isVisible(el) || inFixedChrome(el)) continue;
    const cs = getComputedStyle(el);
    cv.font = `${cs.fontWeight} ${cs.fontSize} ${cs.fontFamily}`;
    const room = el.clientWidth - parseFloat(cs.paddingLeft) - parseFloat(cs.paddingRight) - (el.tagName === 'SELECT' ? 20 : 0);
    // For dropdowns only the chosen option is visible; for inputs, the placeholder while empty.
    const texts = el.tagName === 'SELECT' ? (el.selectedIndex >= 0 ? [el.options[el.selectedIndex].text] : []) : (el.value ? [] : [el.placeholder]);
    for (const t of texts) {
      if (cv.measureText(t).width > room + 1) { clipped.push(`${label(el)}: "${t}"`); break; }
    }
  }
  if (clipped.length) issues.push({ check: 'clipped-field-text', detail: 'text cut off inside fields (shorten it or give the field more width): ' + clipped.slice(0, 8).join('; ') });

  // 4c. Form fields whose text isn't vertically centered (uneven padding),
  //     or that are shorter than the 48px field height.
  const uneven = [];
  for (const el of document.querySelectorAll('input:not([type=checkbox]):not([type=radio]):not([type=hidden]):not([type=file]):not([type=range]), select')) {
    if (!isVisible(el) || inFixedChrome(el)) continue;
    const cs = getComputedStyle(el), pt = parseFloat(cs.paddingTop), pb = parseFloat(cs.paddingBottom), h = el.getBoundingClientRect().height;
    if (Math.abs(pt - pb) > 1 || h < 44) uneven.push(`${label(el)} (padding ${pt}/${pb}px, height ${Math.round(h)}px)`);
    else if (el.tagName === 'SELECT' && cs.appearance !== 'none' && cs.webkitAppearance !== 'none') uneven.push(`${label(el)} uses the native dropdown style (renders differently on Android/iOS)`);
  }
  if (uneven.length) issues.push({ check: 'uneven-form-fields', detail: uneven.slice(0, 8).join('; ') });

  // 4d. Text spilling out of its own box, or out of a ring / circle.
  const spill = [];
  const textLeaves = [...document.querySelectorAll('body *')].filter((el) => !el.children.length && el.textContent.trim() && isVisible(el) && !inFixedChrome(el) && !['INPUT','SELECT','TEXTAREA','OPTION','SCRIPT','STYLE'].includes(el.tagName));
  for (const el of textLeaves) {
    const cs = getComputedStyle(el);
    if (cs.overflow === 'visible' && cs.textOverflow !== 'ellipsis' && el.scrollWidth > el.clientWidth + 2 && cs.display !== 'inline') {
      spill.push(`${label(el)} is ${el.scrollWidth}px of text in a ${el.clientWidth}px box`);
    }
  }
  const rings = [...document.querySelectorAll('.donut, .ring, [class*="donut"]:not(.donut-wrap):not(.donut-center):not(.donut-detail)')].filter(isVisible);
  for (const ring of rings) {
    const r = ring.getBoundingClientRect(), side = Math.min(r.width, r.height) * 0.72;
    const box = { l: r.left + (r.width - side) / 2, t: r.top + (r.height - side) / 2 }; box.r = box.l + side; box.b = box.t + side;
    for (const el of ring.querySelectorAll('*')) {
      if (el.children.length || !el.textContent.trim() || !isVisible(el)) continue;
      const range = document.createRange(); range.selectNodeContents(el); const tr = range.getBoundingClientRect();
      if (tr.left < box.l - 2 || tr.right > box.r + 2 || tr.top < box.t - 2 || tr.bottom > box.b + 2) {
        spill.push(`"${el.textContent.trim().slice(0, 30)}" doesn't fit inside the ring (keep only a short value there; put details below it)`);
      }
    }
  }
  if (spill.length) issues.push({ check: 'text-outside-its-box', detail: [...new Set(spill)].slice(0, 8).join('; ') });

  // 5. Content hidden behind the fixed bottom nav
  const nav = [...document.querySelectorAll('nav, .bottom-nav')].find((n) => isVisible(n) && getComputedStyle(n).position === 'fixed');
  if (nav) {
    window.scrollTo(0, document.documentElement.scrollHeight);
    const navTop = nav.getBoundingClientRect().top;
    const view = document.querySelector('.view.active') || document.querySelector('main');
    if (view) {
      let lowest = null, lowestBottom = -Infinity;
      for (const el of view.querySelectorAll('*')) {
        if (!isVisible(el) || el.children.length) continue;
        const b = el.getBoundingClientRect().bottom;
        if (b > lowestBottom) { lowestBottom = b; lowest = el; }
      }
      if (lowest && lowestBottom > navTop - 8) issues.push({ check: 'hidden-behind-bottom-nav', detail: `${label(lowest)} ends at ${Math.round(lowestBottom)}px, nav starts at ${Math.round(navTop)}px` });
    }
    window.scrollTo(0, 0);
  }

  // 6. Raw icon ligature names visible as words (icon font missing).
  // Measured, not trusted from a class: a working ligature is roughly
  // square; a word like "settings" is several times wider than tall.
  const raw = [];
  for (const el of document.querySelectorAll('.icon, .material-symbols-outlined, .material-icons, .material-symbols-rounded')) {
    if (!isVisible(el)) continue;
    const t = el.textContent.trim();
    const r = el.getBoundingClientRect();
    if (t.length > 2 && r.width > r.height * 1.6) raw.push(`"${t}"`);
  }
  const blank = [];
  for (const el of document.querySelectorAll('span.icon')) {
    if (el.closest('.sidebar') || getComputedStyle(el).display === 'none') continue;
    if (!el.querySelector('svg') && !(el.textContent.trim().length > 2 && raw.length)) blank.push(el.textContent.trim() || '(empty)');
  }
  if (blank.length) issues.push({ check: 'icons-not-embedded', detail: `${blank.length} icons have no drawing (run scripts/embed_icons.py): ${[...new Set(blank)].slice(0, 8).join(', ')}` });
  // Icon beside text on one line must be cap-aligned (see template CSS:
  // align-items: baseline + translate by half the cap height). Plain
  // center alignment looks 1-2px off in screenshots and on some phones.
  const offIcons = [];
  for (const ic of document.querySelectorAll('.view.active .icon, .mobile-header .icon')) {
    const p = ic.parentElement; if (!p || !isVisible(ic)) continue;
    const cs = getComputedStyle(p);
    if (!/flex/.test(cs.display) || cs.flexDirection.startsWith('column')) continue;
    const hasText = [...p.childNodes].some(n => (n.nodeType === 3 && n.textContent.trim()) || (n.nodeType === 1 && n !== ic && !n.classList.contains('icon') && n.textContent.trim() && getComputedStyle(n).display.startsWith('inline')));
    if (!hasText) continue;
    if (cs.alignItems !== 'baseline' || getComputedStyle(ic).translate === 'none') offIcons.push(label(p));
  }
  if (offIcons.length) issues.push({ check: 'icon-not-cap-aligned', detail: 'icon + text rows not aligned to the capital letters (add class ic-text, or stacked for icon-above-text buttons): ' + [...new Set(offIcons)].slice(0, 6).join('; ') });
  // Nav icons must still draw when their tab is active. The active state swaps
  // to the filled shape, and an icon with no filled version vanishes if the
  // outline is hidden without checking a fill exists (svg:has(.f) .o).
  const goneNav = [];
  for (const b of document.querySelectorAll('.bottom-nav button, .nav-btn, nav button')) {
    const svg = b.querySelector('.icon svg'); if (!svg || !isVisible(b)) continue;
    if (![...svg.querySelectorAll('path')].some(pa => getComputedStyle(pa).display !== 'none')) goneNav.push(label(b));
  }
  if (goneNav.length) issues.push({ check: 'nav-icon-vanishes', detail: 'active tab shows no icon (hide the outline only when a filled shape exists: .active .icon svg:has(.f) .o): ' + goneNav.slice(0, 4).join('; ') });
  // Text running under a button in the same row (long subtitle under a checkbox).
  // Usually an inline <span> with nowrap/ellipsis: ellipsis only clips a block box.
  const isFixed = (el) => { for (let p = el; p && p !== document.body; p = p.parentElement) if (getComputedStyle(p).position === 'fixed') return true; return false; };
  const ctrls = [...document.querySelectorAll('.view.active button, .view.active input, .view.active select, .view.active .check')].filter(c => isVisible(c) && !isFixed(c));
  const under = [];
  if (ctrls.length < 400) for (const el of document.querySelectorAll('.view.active *')) {
    if (!el.childNodes.length || ![...el.childNodes].some(n => n.nodeType === 3 && n.textContent.trim()) || !isVisible(el) || isFixed(el) || inScroller(el)) continue;
    const r = el.getBoundingClientRect();
    for (const c of ctrls) {
      if (c.contains(el) || el.contains(c)) continue;
      const q = c.getBoundingClientRect();
      const ox = Math.min(r.right, q.right) - Math.max(r.left, q.left), oy = Math.min(r.bottom, q.bottom) - Math.max(r.top, q.top);
      if (ox > 2 && oy > 4) { under.push(label(el) + ' under ' + label(c)); break; }
    }
    if (under.length > 5) break;
  }
  if (under.length) issues.push({ check: 'text-under-control', detail: 'text overlaps a button or checkbox (give the text block min-width:0 and make each line display:block with overflow:hidden + text-overflow:ellipsis, or shorten it): ' + under.slice(0, 4).join('; ') });
  // Optical centering: the VISIBLE icon + capital letters must sit centered in
  // buttons, and a column button's icon must sit over its label. Box-centered
  // content looks lopsided (Material icons carry uneven empty space; line boxes
  // put capitals ~1px low). The template's opticalCenter() handles this.
  const capOf = (cs) => { const c = (capOf.cv = capOf.cv || document.createElement('canvas')).getContext('2d'); c.font = cs.fontStyle + ' ' + cs.fontWeight + ' ' + cs.fontSize + ' ' + cs.fontFamily; const m = c.measureText('H'); return m.fontBoundingBoxAscent ? { cap: m.actualBoundingBoxAscent, asc: m.fontBoundingBoxAscent, desc: m.fontBoundingBoxDescent } : null; };
  const textInk = (el) => { const w = document.createTreeWalker(el, NodeFilter.SHOW_TEXT); let n, box = null; const rg = document.createRange();
    while ((n = w.nextNode())) { if (!n.textContent.trim() || n.parentElement.closest('.icon')) continue; const m = capOf(getComputedStyle(n.parentElement)); if (!m) return null; rg.selectNodeContents(n);
      for (const rc of rg.getClientRects()) { if (!rc.width) continue; const base = rc.top + (rc.height - (m.asc + m.desc)) / 2 + m.asc, t = base - m.cap; box = box ? { l: Math.min(box.l, rc.left), r: Math.max(box.r, rc.right), t: Math.min(box.t, t), b: Math.max(box.b, base) } : { l: rc.left, r: rc.right, t, b: base }; } }
    return box; };
  const iconInk = (ic) => { const svg = ic.querySelector('svg'); if (!svg || !svg.viewBox.baseVal || !svg.viewBox.baseVal.width) return null; const vb = svg.viewBox.baseVal, r = svg.getBoundingClientRect(); let bb = null;
    for (const pa of svg.querySelectorAll('path')) { if (getComputedStyle(pa).display === 'none') continue; const b = pa.getBBox(); if (!b.width) continue; bb = bb ? { x: Math.min(bb.x, b.x), y: Math.min(bb.y, b.y), x2: Math.max(bb.x2, b.x + b.width), y2: Math.max(bb.y2, b.y + b.height) } : { x: b.x, y: b.y, x2: b.x + b.width, y2: b.y + b.height }; }
    if (!bb) return null; const k = r.width / vb.width; return { l: r.left + (bb.x - vb.x) * k, r: r.left + (bb.x2 - vb.x) * k, t: r.top + (bb.y - vb.y) * k, b: r.top + (bb.y2 - vb.y) * k }; };
  const offCenter = [];
  for (const el of document.querySelectorAll('.view.active .btn, .view.active .pill, .view.active .icon-btn, .view.active .tag, .bottom-nav button')) {
    if (!isVisible(el) || isFixed(el) && !el.closest('.bottom-nav')) continue;
    const cs = getComputedStyle(el); if (!/flex/.test(cs.display)) continue;
    const col = /^column/.test(cs.flexDirection), t = textInk(el), inks = [...el.children].filter(c => c.classList.contains('icon')).map(iconInk).filter(Boolean);
    if (!t || !inks.length && !col) { if (!t) continue; }
    if (col) { for (const k of inks) { if (Math.abs((k.l + k.r) / 2 - (t.l + t.r) / 2) > 1.25) { offCenter.push(label(el) + ' (icon not over label)'); break; } } continue; }
    if (!/center/.test(cs.justifyContent)) continue;
    const all = inks.concat([t]).reduce((a, b) => ({ l: Math.min(a.l, b.l), r: Math.max(a.r, b.r), t: Math.min(a.t, b.t), b: Math.max(a.b, b.b) }));
    const R = el.getBoundingClientRect(), gx = (R.left + R.right) / 2 - (all.l + all.r) / 2, gy = (R.top + R.bottom) / 2 - (all.t + all.b) / 2;
    if (Math.abs(gx) > 1.25 || Math.abs(gy) > 1.25) offCenter.push(label(el) + ` (${gx.toFixed(1)}px, ${gy.toFixed(1)}px)`);
    if (offCenter.length > 5) break;
  }
  if (offCenter.length) issues.push({ check: 'content-not-optically-centered', detail: 'icon + text not visually centered in the button (keep the template’s opticalCenter() block; give icon-above-text buttons .stacked): ' + offCenter.slice(0, 4).join('; ') });
  // Any other button (custom classes the optical pass doesn't cover): its
  // label must sit on the button's vertical center. A flex button with a
  // min-height but no align-items:center pins its text to the top edge.
  const notMid = [], OPT = '.btn, .pill, .icon-btn, .tag, .fab, .toggle, .ic-text, .back-btn, .link-btn, .rightnow-label, .nav-btn';
  for (const el of document.querySelectorAll('.view.active button, .view.active [role=button], .overlay:not(.hidden) button')) {
    // every button is measured, including the ones opticalCenter() is meant to fix: a button it
    // skipped (display:flex, no justify-content) once shipped 1.3px low on the Workout Tracker
    if (el.closest('.bottom-nav') || !isVisible(el) || isFixed(el)) continue;
    const R = el.getBoundingClientRect(); if (R.height < 30 || R.height > 80) continue;
    const cs = getComputedStyle(el); if (/^column/.test(cs.flexDirection)) continue;
    // a text link with no background, border or shadow has no visible box to be centered in
    const bare = (cs.backgroundColor === 'rgba(0, 0, 0, 0)' || cs.backgroundColor === 'transparent') && cs.backgroundImage === 'none' && !(parseFloat(cs.borderTopWidth) > 0) && cs.boxShadow === 'none';
    if (bare) continue;
    if ([...el.querySelectorAll('*')].some(d => !d.closest('.icon') && !/^(inline|inline-block|contents|none)$/.test(getComputedStyle(d).display))) continue;
    const rg = document.createRange(), tops = new Set(); const w = document.createTreeWalker(el, NodeFilter.SHOW_TEXT); let n;
    while ((n = w.nextNode())) { if (!n.textContent.trim() || n.parentElement.closest('.icon')) continue; rg.selectNodeContents(n); for (const rc of rg.getClientRects()) if (rc.width) tops.add(Math.round(rc.top / 4)); }
    if (tops.size !== 1) continue;
    const t = textInk(el); if (!t) continue;
    const inks = [...el.querySelectorAll('.icon')].map(iconInk).filter(Boolean);
    const all = inks.concat([t]).reduce((a, b) => ({ t: Math.min(a.t, b.t), b: Math.max(a.b, b.b) }));
    const gy = (R.top + R.bottom) / 2 - (all.t + all.b) / 2;
    if (Math.abs(gy) > 1) notMid.push(label(el) + ` (${gy > 0 ? 'text ' + gy.toFixed(0) + 'px too high' : 'text ' + (-gy).toFixed(0) + 'px too low'})`);
    if (notMid.length > 5) break;
  }
  if (notMid.length) issues.push({ check: 'button-text-not-centered', detail: 'button label not vertically centered (give the button class align-items:center; justify-content:center, or ic-text if it has an icon beside the text): ' + notMid.slice(0, 4).join('; ') });
  // Emoji or icons inside a shape (hexagon, icon tile, ring, avatar circle) must sit dead
  // center. A broad rule like `.card span{display:block}` silently overrides the shape's
  // `display:grid; place-items:center` and pins the emoji to the top-left corner.
  const offShape = [], EMO = /\p{Extended_Pictographic}/u;
  const shaped = (el, cs) => (cs.backgroundColor !== 'rgba(0, 0, 0, 0)' && cs.backgroundColor !== 'transparent') || cs.backgroundImage !== 'none' ||
    parseFloat(cs.borderTopWidth) > 0 || (cs.clipPath && cs.clipPath !== 'none');
  for (const el of document.querySelectorAll('.view.active *, .bottom-nav *')) {
    if (!isVisible(el) || el.closest('.icon') || el.matches(OPT)) continue;
    const R = el.getBoundingClientRect(); if (R.width < 24 || R.height < 24 || R.width > 130 || R.height > 130) continue;
    const ar = R.width / R.height; if (ar < 0.6 || ar > 1.7) continue;
    const cs = getComputedStyle(el); if (!shaped(el, cs)) continue;
    const kids = [...el.childNodes].filter(n => n.nodeType === 1 || (n.nodeType === 3 && n.textContent.trim()));
    if (kids.length !== 1) continue;
    const k = kids[0]; let box = null;
    if (k.nodeType === 3 || (k.nodeType === 1 && !k.classList.contains('icon') && !k.children.length)) {
      const txt = k.textContent.trim(); if (!txt || txt.length > 8 || !EMO.test(txt) || /[A-Za-z0-9]/.test(txt)) continue;
      const rg = document.createRange(); rg.selectNodeContents(k); const rs = [...rg.getClientRects()].filter(r => r.width);
      if (rs.length !== 1) continue; box = { l: rs[0].left, r: rs[0].right, t: rs[0].top, b: rs[0].bottom };
    } else if (k.nodeType === 1 && k.classList.contains('icon')) { box = iconInk(k); }
    if (!box) continue;
    const dx = (R.left + R.right) / 2 - (box.l + box.r) / 2, dy = (R.top + R.bottom) / 2 - (box.t + box.b) / 2, tol = Math.max(2.5, R.width * 0.07);
    if (Math.abs(dx) > tol || Math.abs(dy) > tol) offShape.push(label(el) + ` (${dx.toFixed(0)}px, ${dy.toFixed(0)}px off)`);
    if (offShape.length > 5) break;
  }
  if (offShape.length) issues.push({ check: 'content-not-centered-in-shape', detail: 'emoji or icon not centered in its shape (give the shape display:grid; place-items:center, and make sure no broader rule like `.card span{display:block}` overrides it): ' + offShape.slice(0, 4).join('; ') });
  if (raw.length) issues.push({ check: 'raw-icon-names-visible', detail: `${raw.length} icons are showing as words, e.g. ${[...new Set(raw)].slice(0, 5).join(', ')}` });
  return issues;
}
"""


# Dark mode probe: the phone is set to dark and the theme is on Auto, so the
# planner must switch itself (html[data-theme="dark"]). Flags a planner that
# stays light, light surfaces left behind (hardcoded #fff cards, inputs,
# sheets) and text that is hard to read on its background.
DARK_JS = r"""
() => {
  const issues = [];
  const rgb = s => { const m = String(s).match(/rgba?\(([^)]+)\)/); if(!m) return null; const p = m[1].split(',').map(x => parseFloat(x)); return { r:p[0], g:p[1], b:p[2], a: p.length > 3 ? p[3] : 1 }; };
  const lum = c => { const f = v => { v /= 255; return v <= .03928 ? v / 12.92 : Math.pow((v + .055) / 1.055, 2.4); }; return .2126 * f(c.r) + .7152 * f(c.g) + .0722 * f(c.b); };
  const contrast = (a, b) => { const x = lum(a), y = lum(b); return (Math.max(x, y) + .05) / (Math.min(x, y) + .05); };
  const visible = el => { const r = el.getBoundingClientRect(), cs = getComputedStyle(el); return r.width > 0 && r.height > 0 && cs.visibility !== 'hidden' && cs.display !== 'none' && parseFloat(cs.opacity) > 0.05; };
  if (document.documentElement.dataset.theme !== 'dark') {
    issues.push({ check: 'dark-mode-missing', detail: 'with the phone set to dark and the theme on Auto, html[data-theme] is not "dark"; keep the template\'s theme script and Appearance setting' });
    return issues;
  }
  const bodyBg = rgb(getComputedStyle(document.body).backgroundColor);
  if (bodyBg && lum(bodyBg) > .2) issues.push({ check: 'dark-light-background', detail: 'the page background is still light in dark mode; define --bg (and --surface) under :root[data-theme="dark"]' });
  // Effective background: nearest ancestor with an opaque color; skip text over gradients or images.
  const bgOf = el => {
    const act = el.closest('.bottom-nav button.active'), pill = act && act.parentElement.querySelector('.nav-pill');
    if (pill && getComputedStyle(pill).opacity !== '0') { const c = rgb(getComputedStyle(pill).backgroundColor); if (c && c.a > .85) return c; }
    for (let n = el; n && n.nodeType === 1; n = n.parentElement) { const cs = getComputedStyle(n); if (cs.backgroundImage !== 'none') return null; const c = rgb(cs.backgroundColor); if (c && c.a > .85) return c; } return bodyBg; };
  const white = [], low = [];
  const label = el => (el.className && typeof el.className === 'string' ? el.tagName.toLowerCase() + '.' + el.className.trim().split(/\s+/).slice(0, 2).join('.') : el.tagName.toLowerCase()) + ' "' + (el.innerText || el.value || el.placeholder || '').trim().slice(0, 30) + '"';
  for (const el of document.querySelectorAll('.view.active *, .bottom-nav, .bottom-nav *, .overlay:not(.hidden) *')) {
    if (!visible(el)) continue;
    const cs = getComputedStyle(el), r = el.getBoundingClientRect();
    const c = rgb(cs.backgroundColor);
    if (c && c.a > .85 && lum(c) > .8 && r.width >= 40 && r.height >= 30 && !el.closest('button, .btn, .pill, .fab, .tag, .badge, .swatch, .sw, [style*="background"]')) white.push(label(el));
    const own = [...el.childNodes].some(n => n.nodeType === 3 && n.textContent.trim());
    if (own) {
      const fg = rgb(cs.color), bg = bgOf(el);
      if (fg && bg && fg.a > .3) {
        const k = contrast(fg, bg), big = parseFloat(cs.fontSize) >= 18 || (parseFloat(cs.fontSize) >= 14 && parseInt(cs.fontWeight) >= 700);
        if (k < (big ? 2.6 : 3.2)) low.push(label(el) + ' ' + k.toFixed(1) + ':1');
      }
    }
  }
  if (white.length) issues.push({ check: 'dark-white-surface', detail: 'light surfaces left in dark mode (use var(--surface) instead of #fff): ' + [...new Set(white)].slice(0, 4).join('; ') });
  if (low.length) issues.push({ check: 'dark-low-contrast', detail: 'text hard to read in dark mode (give it a light token or a darker background): ' + [...new Set(low)].slice(0, 4).join('; ') });
  return issues;
}
"""


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("html")
    ap.add_argument("--out", default="mobile-check")
    ap.add_argument("--widths", default="320,375,430")
    ap.add_argument("--block-fonts", action="store_true", help="also test with Google Fonts blocked (offline buyer)")
    ap.add_argument("--no-dark", action="store_true", help="skip the dark-mode pass (375px, phone set to dark, theme on Auto)")
    args = ap.parse_args()

    path = pathlib.Path(args.html).resolve()
    out = pathlib.Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    widths = [int(w) for w in args.widths.split(",")]
    base = path.as_uri()
    report = {}
    total = 0

    with sync_playwright() as p:
        browser = p.chromium.launch()
        modes = [("online", False)] + ([("fonts-blocked", True)] if args.block_fonts else []) + ([] if args.no_dark else [("dark", False)])

        # Discover the views once.
        ctx = browser.new_context(viewport={"width": 375, "height": 812})
        pg = ctx.new_page()
        pg.goto(base + "?sample=1")
        pg.wait_for_timeout(600)
        views = pg.eval_on_selector_all('[id^="view-"]', "els => els.map(e => e.id.slice(5))")
        ctx.close()
        if not views:
            print("No elements with id=\"view-...\" found; checking the page as a single view.")
            views = [None]

        for mode, block in modes:
            for w in (widths if mode != "dark" else [375]):
                for v in views:
                    ctx = browser.new_context(reduced_motion="reduce", viewport={"width": w, "height": 812}, device_scale_factor=2,
                                              is_mobile=True, has_touch=True, color_scheme="dark" if mode == "dark" else "light")
                    if block:
                        ctx.route("**/fonts.googleapis.com/**", lambda r: r.abort())
                        ctx.route("**/fonts.gstatic.com/**", lambda r: r.abort())
                    pg = ctx.new_page()
                    errors = []
                    pg.on("pageerror", lambda e: errors.append(str(e)))
                    pg.on("console", lambda m: errors.append(m.text) if m.type == "error" and "fonts.g" not in m.text and "net::ERR" not in m.text else None)
                    url = base + "?sample=1" + (f"&view={v}" if v else "")
                    pg.goto(url)
                    pg.wait_for_timeout(900)
                    suffix = {"online": "", "fonts-blocked": "-nofonts", "dark": "-dark"}[mode]
                    # The view itself, then every in-view tab (buttons whose
                    # data-action ends in "-tab"), so tabbed screens get checked too.
                    tab_sel = '.view.active [data-action$="-tab"]'
                    n_tabs = pg.locator(tab_sel).count()
                    states = [None] + list(range(n_tabs))
                    for st in states:
                        tab_name = ""
                        if st is not None:
                            btn = pg.locator(tab_sel).nth(st)
                            tab_name = btn.get_attribute("data-id") or str(st)
                            if not btn.is_visible():
                                continue
                            btn.click()
                            pg.wait_for_timeout(250)
                        issues = pg.evaluate(PROBE_JS)
                        if mode == "dark":
                            issues += pg.evaluate(DARK_JS)
                        if errors and st is None:
                            issues.append({"check": "javascript-errors", "detail": "; ".join(errors[:5])})
                        key = f"{mode} {w}px {v or 'page'}" + (f" > {tab_name}" if tab_name else "")
                        report[key] = issues
                        total += len(issues)
                        if mode == "online" or w == 375:
                            pg.screenshot(path=str(out / f"{v or 'page'}{'-' + tab_name if tab_name else ''}-{w}{suffix}.png"), full_page=True)
                    ctx.close()
        browser.close()

    # Source check: timers must count from the clock, not by ticks.
    # Browsers slow or pause setInterval in background tabs and on a locked
    # phone, so "remaining -= 1" drifts or freezes (a buyer's 1-star review
    # was exactly this). The right pattern stores endAt = Date.now() + ms
    # and recomputes endAt - Date.now() on every tick and on visibilitychange.
    src = path.read_text(encoding="utf-8", errors="ignore")
    src = re.sub(r"/\*.*?\*/", "", src, flags=re.S)          # drop block comments
    src = re.sub(r"(?m)^\s*//.*$", "", src)                  # and whole-line // comments
    timer_issues = []
    tick_math = [] if "setInterval" not in src else re.findall(r"\b\w*(?:remain|left|second|secs|elapsed|countdown|ticks?)\w*\s*(?:-=|\+=|--|\+\+)", src, re.I)
    if tick_math:
        timer_issues.append({"check": "timer-counts-ticks", "detail": "a timer changes its count on each tick (" + ", ".join(sorted(set(t.strip() for t in tick_math))[:4]) + "). Store an end time (Date.now() + duration) and compute remaining = endAt - Date.now() instead; see design-system.md > Timers"})
    if "setInterval" in src and re.search(r"(?i)timer|countdown|stopwatch|pomodoro", src):
        if "Date.now()" not in src and "getTime()" not in src and "performance.now" not in src:
            timer_issues.append({"check": "timer-not-clock-based", "detail": "setInterval is used for a timer but the clock is never read (Date.now()); background tabs will freeze it"})
        if "visibilitychange" not in src:
            timer_issues.append({"check": "timer-no-visibility-refresh", "detail": "add document.addEventListener('visibilitychange', ...) that re-runs the timer tick when the page is shown again"})
    if timer_issues:
        report["source timers"] = timer_issues
        total += len(timer_issues)

    (out / "report.json").write_text(json.dumps(report, indent=2))
    for key, issues in report.items():
        status = "OK " if not issues else "FIX"
        print(f"[{status}] {key}")
        for i in issues:
            print(f"      - {i['check']}: {i['detail']}")
    print(f"\n{total} problem(s). Screenshots and report.json in {out}/")
    sys.exit(1 if total else 0)


if __name__ == "__main__":
    main()
