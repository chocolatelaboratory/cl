#!/usr/bin/env python3
"""3D showcase video for TikTok / Instagram (1080x1920, 30fps, H.264, no audio).

The planner runs on the same jet black 3D phone as the listing photos. Each feature is a
section: the real app is recorded frame by frame, then put on the phone with whip-pan
transitions, motion blur, a pop-out card and a big two-line headline, ending on an end card.

  python3 make_3d_video.py planner.html spec.json --out video/            # full render (~1.2s per frame)
  python3 make_3d_video.py planner.html spec.json --out video/ --stills   # storyboard sheet only (~1 min)
  python3 make_3d_video.py planner.html spec.json --out video/ --rerecord # re-record the app clips

Spec format: see references/3d-video.md. Styles: "bold" (a color per section that wipes in with
the whip) and "studio" (one soft backdrop, headlines slide with the phone).
"""
import argparse, base64, colorsys, datetime, json, math, pathlib, re, shutil, subprocess, sys, time
from playwright.sync_api import sync_playwright

SKILL = pathlib.Path(__file__).resolve().parent.parent
DEVICES = SKILL / 'assets' / 'device3d'
FPS, W, H = 30, 1080, 1920
APP_W, APP_H = 390, 796           # the phone screen below the status bar, in CSS px
RATE = 0.08                       # CSS animations slowed while recording, then played back at speed

TAP = r"""
(() => {
  const css = `#__tap{position:fixed;width:48px;height:48px;margin:-24px 0 0 -24px;border-radius:50%;pointer-events:none;z-index:99999;
    background:rgba(255,255,255,.55);box-shadow:0 0 0 2px rgba(15,31,24,.28), 0 4px 14px rgba(0,0,0,.18);opacity:0;transform:scale(1.25);
    transition:opacity .25s ease, transform .25s ease, background .14s ease}`;
  window.__tapApi = {
    el(){ let d = document.getElementById('__tap'); if(!d){ const s = document.createElement('style'); s.textContent = css; document.head.appendChild(s);
      d = document.createElement('div'); d.id = '__tap'; document.body.appendChild(d); } return d; },
    show(x, y){ const d = this.el(); d.style.transition = 'opacity .25s ease, transform .25s ease'; d.style.left = x + 'px'; d.style.top = y + 'px'; d.style.opacity = '1'; d.style.transform = 'scale(1)'; },
    press(){ const d = this.el(); d.style.transition = 'transform .14s ease, background .14s ease'; d.style.transform = 'scale(.82)'; d.style.background = 'rgba(200,210,205,.75)'; },
    release(){ const d = this.el(); d.style.transition = 'opacity .65s ease, transform .65s ease'; d.style.transform = 'scale(1.5)'; d.style.opacity = '0'; d.style.background = 'rgba(255,255,255,.55)'; }
  };
})();
"""

# =====================================================================================
# 1. RECORD each section of the app, frame by frame (frozen clock, slowed animations)
# =====================================================================================
class Rec:
    def __init__(self, browser, url, folder):
        self.dir = folder; self.dir.mkdir(parents=True, exist_ok=True); self.n = 0; self.saving = False
        self.taps, self.rects, self.marks = [], {}, {}
        self.ctx = browser.new_context(viewport={'width': APP_W, 'height': APP_H}, device_scale_factor=3, is_mobile=True, has_touch=False)
        self.ctx.add_init_script(TAP)
        pg = self.pg = self.ctx.new_page()
        t0 = datetime.datetime.now().replace(microsecond=0)
        pg.clock.install(time=t0); pg.clock.pause_at(t0 + datetime.timedelta(seconds=1))
        cdp = self.ctx.new_cdp_session(pg); cdp.send('Animation.enable'); cdp.send('Animation.setPlaybackRate', {'playbackRate': RATE})
        pg.goto(url)
        self.acc = 0.0; self.nxt = time.perf_counter()
    def frame(self):
        fms = 1000 / FPS; self.acc += fms; step = int(self.acc); self.acc -= step; self.pg.clock.run_for(step)
        now = time.perf_counter(); real = fms / RATE / 1000
        if now < self.nxt: time.sleep(self.nxt - now)
        self.nxt = max(self.nxt + real, time.perf_counter())
        self.pg.wait_for_timeout(20)
        if self.saving:
            self.pg.screenshot(path=str(self.dir / f'{self.n:05d}.jpg'), type='jpeg', quality=94); self.n += 1
    def hold(self, sec):
        for _ in range(int(round(sec * FPS))): self.frame()
    def center(self, sel):
        return self.pg.evaluate("s => { const e = document.querySelector(s); if (!e) return null; const r = e.getBoundingClientRect(); return [r.left + r.width / 2, r.top + r.height / 2]; }", sel)
    def step(self, st):
        kind = st[0]
        if kind == 'hold': self.hold(st[1])
        elif kind == 'tap':
            sel, pre = st[1], (st[2] if len(st) > 2 else 0.35)
            self.hold(pre); c = self.center(sel)
            if not c: sys.exit(f'tap: nothing matches {sel!r}')
            x, y = c
            if self.saving: self.taps.append(self.n + int(0.46 * FPS))
            self.pg.evaluate(f'__tapApi.show({x},{y})'); self.hold(0.32)
            self.pg.evaluate('__tapApi.press()'); self.hold(0.14)
            self.pg.mouse.click(x, y); self.pg.evaluate('__tapApi.release()'); self.frame()
        elif kind == 'pop':
            # A pop-out is a crop of the screen, so it must be a whole visual card: rounded corners that
            # match the card's own, and nothing else painted across its edges (an overlapping row of
            # tiles gets sliced in half). Pass a list of selectors to pop several boxes as one card
            # (e.g. a hero plus the stat tiles that overlap its bottom); the corner radius falls back to
            # the first rounded descendant when a wrapper has none.
            sels = st[1] if isinstance(st[1], list) else [st[1]]
            r = self.pg.evaluate("""sels => {
              const els = sels.map(s => document.querySelector(s)); if (els.some(e => !e)) return null;
              const rad = e => parseFloat(getComputedStyle(e).borderTopLeftRadius) || 0;
              let L = 1e9, T = 1e9, R = -1e9, B = -1e9, radius = 0;
              els.forEach(e => { const b = e.getBoundingClientRect(); L = Math.min(L, b.left); T = Math.min(T, b.top); R = Math.max(R, b.right); B = Math.max(B, b.bottom); });
              for (const e of els) { radius = rad(e); if (radius) break; const kids = [...e.querySelectorAll('*')].filter(k => { const b = k.getBoundingClientRect(); return Math.abs(b.left - L) < 2 && Math.abs(b.top - T) < 2 && rad(k); }); if (kids.length) { radius = rad(kids[0]); break; } }
              const inside = n => els.some(e => e === n || e.contains(n) || n.contains(e));
              const clip = [...document.querySelectorAll('body *')].filter(n => {
                if (inside(n)) return false; const cs = getComputedStyle(n); if (cs.visibility === 'hidden' || cs.display === 'none' || +cs.opacity === 0) return false;
                const b = n.getBoundingClientRect(); if (b.width < 4 || b.height < 4) return false;
                const ix = Math.min(b.right, R) - Math.max(b.left, L), iy = Math.min(b.bottom, B) - Math.max(b.top, T);
                const within = b.left >= L - 1 && b.right <= R + 1 && b.top >= T - 1 && b.bottom <= B + 1;
                const covers = b.left <= L + 1 && b.right >= R - 1 && b.top <= T + 1 && b.bottom >= B - 1;
                return ix > 6 && iy > 6 && !within && !covers && !n.contains(els[0]) && n.closest('.bottom-nav, nav, .fab') === null;
              }).slice(0, 3).map(n => n.className || n.tagName);
              return [L, T, R - L, B - T, radius, clip];
            }""", sels)
            if not r: sys.exit(f'pop: nothing matches {st[1]!r}')
            if r[5]: print(f'  WARNING pop {st[1]!r}: cuts through {r[5]} (overlapping content gets sliced). Pop a list that includes it, e.g. ["{sels[0]}", ".{str(r[5][0]).split()[0]}"].', flush=True)
            r = r[:5]
            self.rects['pop'] = r; self.marks['pop'] = self.n
        elif kind == 'scroll':   # bring an element to `offset` px below the top, instantly (use in setup)
            off = st[2] if len(st) > 2 else 64
            self.pg.evaluate("([s, o]) => { const e = document.querySelector(s); window.scrollTo(0, e.getBoundingClientRect().top + scrollY - o); }", [st[1], off])
            self.frame()
        elif kind == 'type':
            self.pg.focus(st[1])
            for ch in st[2]: self.pg.keyboard.type(ch); self.hold(0.2)
            self.pg.evaluate('document.activeElement.blur()')
        elif kind == 'js': self.pg.evaluate(st[1]); self.frame()
        else: sys.exit(f'unknown step {kind!r}')
    def done(self):
        self.ctx.close()
        return {'frames': self.n, 'taps': self.taps, 'rects': self.rects, 'marks': self.marks}

def record(planner, spec, out):
    sec_dir = out / 'sections'
    if sec_dir.exists(): shutil.rmtree(sec_dir)
    meta = {}
    with sync_playwright() as p:
        b = p.chromium.launch()
        for i, s in enumerate(spec['sections']):
            q = s.get('query', '')
            url = planner.resolve().as_uri() + '?sample=1' + ('&' + q.lstrip('?&') if q else '')
            r = Rec(b, url, sec_dir / str(i))
            if i == 0 and s.get('wake', True):
                r.saving = True                         # first section: show the app waking up
            else:
                r.hold(s.get('settle', 0.8))            # let entrance animations finish off camera
            for st in s.get('setup', []): r.step(st)
            r.saving = True
            for st in s['steps']: r.step(st)
            meta[str(i)] = r.done()
            print(f"  recorded section {i + 1}: {meta[str(i)]['frames']} frames", flush=True)
        b.close()
    json.dump(meta, open(out / 'sections.json', 'w'), indent=1)
    return meta

# =====================================================================================
# 2. TIMELINE + MOTION
# =====================================================================================
INTRO_BLACK, ENTER, EXIT, WIPE = 9, 16, 8, 12      # frames

def clamp(v, a=0.0, b=1.0): return max(a, min(b, v))
def settle(t):   # fast start, long settle, ~3% overshoot: the "expensive" ease of app promo videos
    t = clamp(t); return 1.0 if t >= 1 else 1 - math.exp(-6.2 * t) * math.cos(4.6 * t)
def expo_in(t): return clamp(t) ** 3.2
def smooth(t): t = clamp(t); return t * t * (3 - 2 * t)
def ppm(z): return H / (189.0 * z)                  # screen px per mm at zoom z

def hex_rgb(h): h = h.lstrip('#'); return tuple(int(h[i:i + 2], 16) / 255 for i in (0, 2, 4))
def lum(h):
    def ch(c): return c / 12.92 if c <= 0.03928 else ((c + 0.055) / 1.055) ** 2.4
    r, g, b = (ch(c) for c in hex_rgb(h)); return 0.2126 * r + 0.7152 * g + 0.0722 * b
def mix(h1, h2, t):
    a, b = hex_rgb(h1), hex_rgb(h2); return '#' + ''.join(f'{round((x + (y - x) * t) * 255):02X}' for x, y in zip(a, b))

class Timeline:
    def __init__(self, spec, meta):
        self.spec, self.meta = spec, meta
        self.style = spec.get('style', 'bold')
        pal = spec.get('palette', {})
        self.ink = pal.get('ink', '#0F2733'); self.main = pal.get('main', '#2A8FB0'); self.strong = pal.get('strong', '#155E7A')
        cyc = pal.get('section_colors') or [self.main, pal.get('accent', '#FFB547'), pal.get('sage', '#1FAE8E'), self.strong]
        dirs_bold = [(-1, 0), (0, 1), (1, 0), (0, -1)]
        dirs_studio = [(-1, 0), (1, 0)]
        self.secs = []
        t = 0
        for i, s in enumerate(spec['sections']):
            m = meta[str(i)]
            L = m['frames'] + (INTRO_BLACK if i == 0 and s.get('wake', True) else 0)
            bg = s.get('bg') or cyc[i % len(cyc)]
            if self.style == 'studio':
                c1, c2 = s.get('c1', self.ink), s.get('c2', self.main)
            else:
                dark = lum(bg) < 0.33
                c1 = s.get('c1', '#FFFFFF' if dark else self.ink)
                c2 = s.get('c2', mix(pal.get('accent', '#FFD9A0'), '#FFFFFF', 0.45) if dark else mix(bg, '#000000', 0.55))
            d = (dirs_studio if self.style == 'studio' else dirs_bold)[i % (2 if self.style == 'studio' else 4)]
            yaw = (-12 if i % 2 == 0 else 12)
            self.secs.append(dict(start=t, len=L, bg=bg, c1=c1, c2=c2, l1=s['headline'][0], l2=s['headline'][1] if len(s['headline']) > 1 else '',
                                  out=d, ry=yaw, black=INTRO_BLACK if i == 0 and s.get('wake', True) else 0, m=m))
            t += L
        self.end = spec.get('end')
        self.end_start = t
        self.N = t + (int(self.end.get('seconds', 2.4) * FPS) if self.end else 0)
        if not self.end: self.secs[-1]['out'] = None      # nothing to whip into: hold on the last section

    def where(self, f):
        if f < 0: return 0, f
        if self.end and f >= self.end_start: return 'end', f - self.end_start
        for i in range(len(self.secs) - 1, -1, -1):
            if f >= self.secs[i]['start']: return i, f - self.secs[i]['start']
        return 0, f

    def pose(self, f):
        sec, lf = self.where(f)
        if sec == 'end': return None
        S = self.secs[sec]; L = S['len']; ts = f / FPS
        studio = self.style == 'studio'
        z = 1.20 - 0.08 * smooth(lf / L)                                # slow push in
        rx, ry, rz = 6.0, S['ry'], 0.0
        rx += 1.0 * math.sin(2 * math.pi * ts / 3.3 + 1)                # idle float
        ry += 1.6 * math.sin(2 * math.pi * ts / 4.4)
        rz += 0.5 * math.sin(2 * math.pi * ts / 5.1)
        ox = oy = 0.0
        dxm = (W * 0.62) / ppm(z) + 45; dym = (H * 0.62) / ppm(z) + 90   # far enough to leave the frame
        if sec == 0:
            if S['black'] or True:
                e = settle((lf - 2) / 30)
                if e < 1: z *= 0.52 + 0.48 * e
                rx += 30 * (1 - e); ry += -34 * (1 - e); rz += -18 * (1 - e)
        else:
            dx, dy = self.secs[sec - 1]['out']; e = settle(lf / ENTER); k = 0.6 if studio else 1.0
            ox = -dx * dxm * (1 - e); oy = -dy * dym * (1 - e)
            ry += dx * 34 * k * (1 - e); rx += -dy * 26 * k * (1 - e); rz += dx * 10 * k * (1 - e)
        k_ = lf - (L - EXIT)
        if k_ > 0 and S['out']:
            dx, dy = S['out']; e = expo_in(k_ / EXIT)
            ox += dx * dxm * e; oy += dy * dym * e
            ry += dx * 38 * e; rx += -dy * 30 * e; rz += -dx * 12 * e
        for tp in S['m']['taps']:                                       # a small push in on each tap
            d = lf - S['black'] - tp
            if -4 <= d < 0: z *= 1 - 0.03 * smooth((d + 4) / 4)
            elif 0 <= d < 14: z *= 1 - 0.03 * (1 - smooth(d / 14))
        lift, scale, ctx_, cty = 0.0, 1.0, 0.0, 0.0
        mk = S['m']['marks'].get('pop')
        if mk is not None:
            p = (lf - S['black'] - mk) / 18
            if p > 0:
                e = settle(p); lift, scale = 15 * e, 1 + 0.10 * e
                ctx_, cty = -5 * e, -S['ry'] * 0.35 * e
                ry -= S['ry'] * 0.30 * e
        return dict(rx=rx, ry=ry, rz=rz, cx=-ox, cy=-oy + 150 / ppm(z), z=z, lift=lift, scale=scale, ctx=ctx_, cty=cty)

    def screen(self, f, base):
        sec, lf = self.where(f)
        if sec == 'end': return None
        S = self.secs[sec]
        if lf < S['black']: return 'black'
        lf = int(min(max(0, lf - S['black']), S['m']['frames'] - 1))
        return f'{base}/sections/{sec}/{lf:05d}.jpg'

    def samples(self, f):
        p0 = self.pose(f)
        if p0 is None: return []
        pa, pb = self.pose(f - 0.5), self.pose(f + 0.5)
        if not pa or not pb: return [p0]
        px = ppm(p0['z'])
        sp = (abs(pb['cx'] - pa['cx']) + abs(pb['cy'] - pa['cy'])) * px + (abs(pb['ry'] - pa['ry']) + abs(pb['rx'] - pa['rx'])) * 9
        if sp < 14: return [p0]
        n = min(18, 2 + int(sp / 6))
        out = [self.pose(f + (i / (n - 1) - 0.5) * 0.5) for i in range(n)]     # 180-degree shutter
        return [q for q in out if q] or [p0]

    def layers(self, f):
        """[key, x px, y px, local frame, alpha]: around each cut the next layer wipes in from the side
        the phone travels toward (bold), or the headline slides in while the old one slides out (studio)."""
        keys = [str(i) for i in range(len(self.secs))] + ['end']
        st = [s['start'] for s in self.secs] + [self.end_start]
        for j, S in enumerate(self.secs):
            if not S['out'] or j + 1 >= len(st): continue
            cut = st[j + 1]; w0 = cut - WIPE          # the wipe finishes exactly on the cut
            if w0 <= f < w0 + WIPE + 2:
                p = smooth((f - w0) / WIPE); dx, dy = S['out']
                old = [keys[j], 0, 0, f - st[j], 1.0]
                if self.style == 'studio' and keys[j + 1] != 'end':
                    old = [keys[j], round(dx * W * 0.5 * p), round(-dy * H * 0.3 * p), f - st[j], 1 - p]
                    return [old, [keys[j + 1], round(-dx * W * 0.5 * (1 - p)), round(dy * H * 0.3 * (1 - p)), f - cut, p]]
                return [old, [keys[j + 1], round(-dx * W * (1 - p)), round(dy * H * (1 - p)), f - cut, 1.0]]
        sec, lf = self.where(f)
        return [[keys[sec] if sec != 'end' else 'end', 0, 0, lf, 1.0]]

    def layer_cfg(self):
        pal = self.spec.get('palette', {})
        d = {str(i): dict(bg=s['bg'], l1=s['l1'], l2=s['l2'], c1=s['c1'], c2=s['c2']) for i, s in enumerate(self.secs)}
        if self.end:
            d['end'] = dict(end=True, bg=self.end.get('bg', pal.get('bg', '#F3F9FB')), title=self.end.get('title', [self.spec.get('name', '')]),
                            emoji=self.end.get('emoji', ''), cta=self.end.get('cta', ''), c1=self.ink, c2=self.main, pill=self.strong,
                            glow=pal.get('glow', [mix(self.main, '#FFFFFF', 0.55)])[0])
        return d

# =====================================================================================
# 3. COMPOSITE in the page: background layers + soft phone shadow + 3D phone, averaged for blur
# =====================================================================================
STAGE_JS = r"""
async (cfg) => {
  const FONT = cfg.font, WEIGHT = cfg.weight;
  try { await document.fonts.load(`${WEIGHT} 96px ${FONT}`); } catch (e) {}
  const W = cfg.W, H = cfg.H;
  videoSize(W, H);
  const mk = (w, h) => { const c = document.createElement('canvas'); c.width = w; c.height = h; return [c, c.getContext('2d')]; };
  const [sub, s] = mk(W, H), [out, c] = mk(W, H), [sm, m] = mk(W / 5, H / 5), [sb, b] = mk(W / 5, H / 5), [base, bctx] = mk(W, H);
  const ease = (t) => { t = Math.max(0, Math.min(1, t)); return 1 - Math.pow(1 - t, 4); };
  const pop = (t) => { t = Math.max(0, t); return t >= 1 ? 1 : 1 - Math.exp(-6.2 * t) * Math.cos(4.6 * t); };
  // studio backdrop: soft color glows like the listing photos
  const studio = document.createElement('canvas'); studio.width = W; studio.height = H; const sg = studio.getContext('2d');
  sg.fillStyle = cfg.studio.bg; sg.fillRect(0, 0, W, H);
  const glow = (x, y, rx, ry, col) => { sg.save(); sg.translate(x, y); sg.scale(rx / ry, 1);
    const g = sg.createRadialGradient(0, 0, 0, 0, 0, ry); g.addColorStop(0, col + 'FF'); g.addColorStop(1, col + '00'); sg.fillStyle = g; sg.fillRect(-ry, -ry, 2 * ry, 2 * ry); sg.restore(); };
  const gl = cfg.studio.glow;
  glow(W / 2, H * 0.55, W * 0.7, H * 0.45, '#FFFFFF'); glow(0, H, W * 0.65, H * 0.4, gl[0]); glow(W / 2, H * 1.05, W * 0.5, H * 0.25, gl[1]);
  glow(W, H * 0.95, W * 0.6, H * 0.36, gl[2]); glow(W, 0, W * 0.65, H * 0.36, gl[3]);
  function text(ctx, str, x, y, col, t, size) {
    const e = ease(t / 14); if (e <= 0 || !str) return;
    ctx.save(); ctx.globalAlpha *= Math.min(1, t / 6); ctx.fillStyle = col; ctx.font = `${WEIGHT} ${size}px ${FONT}`;
    let sz = size; while (ctx.measureText(str).width > W - 120 && sz > 50) { sz -= 4; ctx.font = `${WEIGHT} ${sz}px ${FONT}`; }
    ctx.textAlign = 'center'; ctx.fillText(str, x, y + (1 - e) * 46); ctx.restore();
  }
  function layer(ctx, key, ox, oy, t, a) {
    const L = cfg.layers[key];
    ctx.save(); ctx.translate(ox, oy); ctx.globalAlpha = a;
    if (L.end) {
      if (cfg.style === 'studio') ctx.drawImage(studio, 0, 0); else { ctx.fillStyle = L.bg; ctx.fillRect(0, 0, W, H);
        const g = ctx.createRadialGradient(W / 2, H * 0.45, 0, W / 2, H * 0.45, 900); g.addColorStop(0, L.glow + '99'); g.addColorStop(1, L.glow + '00'); ctx.fillStyle = g; ctx.fillRect(0, 0, W, H); }
      let y = 960;
      if (L.emoji) { const pe = pop((t - 2) / 16); if (pe > 0) { ctx.save(); ctx.translate(W / 2, 700); ctx.scale(pe, pe); ctx.font = '170px sans-serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillText(L.emoji, 0, 0); ctx.restore(); } }
      L.title.forEach((ln, i) => text(ctx, ln, W / 2, y + i * 110, i === L.title.length - 1 && L.title.length > 1 ? L.c2 : L.c1, t - 8 - 4 * i, 104));
      if (L.cta) { const pp = pop((t - 20) / 16); const yy = y + L.title.length * 110 + 50;
        if (pp > 0) { ctx.save(); ctx.translate(W / 2, yy); ctx.scale(pp, pp); ctx.font = `${WEIGHT} 46px ${FONT}`; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
          const w = ctx.measureText(L.cta).width + 100; ctx.fillStyle = L.pill; ctx.beginPath(); ctx.roundRect(-w / 2, -50, w, 100, 50); ctx.fill();
          ctx.fillStyle = '#fff'; ctx.fillText(L.cta, 0, 3); ctx.restore(); } }
    } else {
      if (cfg.style !== 'studio') {
        ctx.fillStyle = L.bg; ctx.fillRect(0, 0, W, H);
        const g = ctx.createRadialGradient(W / 2, H * 0.58, 0, W / 2, H * 0.58, 1050); g.addColorStop(0, 'rgba(255,255,255,0.22)'); g.addColorStop(1, 'rgba(255,255,255,0)');
        ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);
        const v = ctx.createRadialGradient(W / 2, H / 2, 700, W / 2, H / 2, 1250); v.addColorStop(0, 'rgba(0,0,0,0)'); v.addColorStop(1, 'rgba(0,0,0,0.16)');
        ctx.fillStyle = v; ctx.fillRect(0, 0, W, H);
      }
      text(ctx, L.l1, W / 2, 238, L.c1, t - 3, 96);
      text(ctx, L.l2, W / 2, 344, L.c2, t - 7, 96);
    }
    ctx.restore();
  }
  window.compose = async (src, poses, rect, lays) => {
    const has = poses.length > 0;
    if (has) { if (src === 'black') setScreenBlack(); else await setScreen(src); setCard(rect || null); }
    c.globalAlpha = 1;
    if (cfg.style === 'studio') c.drawImage(studio, 0, 0);
    lays.forEach(([k, ox, oy, t, a]) => layer(c, k, ox, oy, t, a));
    if (!has) return out.toDataURL('image/jpeg', 0.93);
    bctx.drawImage(out, 0, 0);
    poses.forEach((p, i) => {
      cardState(p.lift, p.scale, p.ctx, p.cty); renderPose(p.rx, p.ry, p.rz, p.cx, p.cy, p.z);
      s.globalAlpha = 1; s.drawImage(base, 0, 0);
      m.clearRect(0, 0, W / 5, H / 5); m.globalCompositeOperation = 'source-over'; m.drawImage(__r.domElement, 0, 0, W / 5, H / 5);
      m.globalCompositeOperation = 'source-in'; m.fillStyle = cfg.shadow; m.fillRect(0, 0, W / 5, H / 5);
      b.clearRect(0, 0, W / 5, H / 5); b.filter = 'blur(7px)'; b.drawImage(sm, 0, 0); b.filter = 'none';
      s.globalAlpha = cfg.style === 'studio' ? 0.22 : 0.34; s.drawImage(sb, 26, 58, W, H); s.globalAlpha = 1;
      s.drawImage(__r.domElement, 0, 0);
      c.globalAlpha = 1 / (i + 1); c.drawImage(sub, 0, 0);
    });
    c.globalAlpha = 1;
    return out.toDataURL('image/jpeg', 0.93);
  };
}
"""

def planner_font(planner, want=None):
    """The planner's boldest embedded display face (or the family named in the spec's "font"),
    so the video speaks in the app's type."""
    html = planner.read_text()
    faces = re.findall(r"@font-face\{[^}]*\}", html)
    best = None
    for f in faces:
        fam = re.search(r"font-family:\s*'?([^;']+)'?", f); wt = re.search(r"font-weight:\s*(\d+)", f)
        if want and fam and fam.group(1).strip().lower() != want.lower(): continue
        if fam and wt and (best is None or int(wt.group(1)) > best[1]): best = (fam.group(1).strip(), int(wt.group(1)), f)
    return best or ('Inter', 800, '')

def render(planner, spec, out, meta, stills=False, test=1):
    tl = Timeline(spec, meta)
    fam, weight, css = planner_font(planner, spec.get('font'))
    frames_dir = out / ('stills' if stills else 'frames')
    if frames_dir.exists(): shutil.rmtree(frames_dir)
    frames_dir.mkdir(parents=True)
    pal = spec.get('palette', {})
    glow = pal.get('glow') or [mix(tl.main, '#FFFFFF', 0.55), mix(tl.main, '#FFFFFF', 0.75), mix(pal.get('accent', '#FFD9A0'), '#FFFFFF', 0.5), mix(tl.main, '#FFFFFF', 0.82)]
    cfg = dict(W=W, H=H, style=tl.style, font=f"'{fam}', sans-serif", weight=weight, layers=tl.layer_cfg(),
               studio=dict(bg=pal.get('bg', '#F3F9FB'), glow=glow), shadow='rgba(10,30,45,1)')
    if stills:
        picks = []
        for i, S in enumerate(tl.secs):
            mk = S['m']['marks'].get('pop')
            picks += [S['start'] + (16 if i == 0 else 8), S['start'] + S['black'] + (mk + 24 if mk is not None else S['len'] // 2)]
            if S['out']: picks.append(S['start'] + S['len'] - 3)
        if tl.end: picks.append(tl.end_start + 45)
        frames = sorted(set(min(tl.N - 1, max(0, p)) for p in picks))
    else:
        frames = list(range(0, tl.N, test))
    t0 = time.time()
    with sync_playwright() as p:
        b = p.chromium.launch(args=['--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'])
        pg = b.new_page(viewport={'width': W, 'height': H})
        errs = []; pg.on('pageerror', lambda e: errs.append(str(e)))
        def serve(route):   # ES modules can't load from file://, so the device page is served through a route
            rel = route.request.url.split('://devices.local/', 1)[1].split('?')[0] or 'devices.html'
            f = (out / rel[4:]) if rel.startswith('out/') else (DEVICES / rel)
            route.fulfill(path=str(f)) if f.exists() else route.fulfill(status=404, body='')
        pg.route('http://devices.local/**', serve)
        pg.add_init_script('window.FAST_FRONT = true; window.TEX_W = 960;')
        pg.goto('http://devices.local/devices.html'); pg.wait_for_function('window.ready === true')
        if css: pg.add_style_tag(content=css)
        pg.evaluate(STAGE_JS, cfg)
        pg.evaluate("() => setScreen('http://devices.local/out/sections/0/00000.jpg')")
        for k, f in enumerate(frames):
            sec, _ = tl.where(f)
            rect = tl.secs[sec]['m']['rects'].get('pop') if isinstance(sec, int) else None
            url = pg.evaluate("([s, p, r, l]) => compose(s, p, r, l)", [tl.screen(f, 'http://devices.local/out'), tl.samples(f), rect, tl.layers(f)])
            (frames_dir / f'{k:05d}.jpg').write_bytes(base64.b64decode(url.split(',', 1)[1]))
            if not stills and k % 60 == 0: print(f'  frame {f}/{tl.N}  {time.time() - t0:.0f}s', flush=True)
        b.close()
    if errs: sys.exit('page errors: ' + '; '.join(errs[:3]))
    return tl, frames_dir, frames

def contact(frames_dir, dest, labels=None, cols=8, tw=216):
    from PIL import Image, ImageDraw
    fs = sorted(frames_dir.glob('*.jpg'))
    if labels is None: fs = fs[::max(1, round(FPS * 0.75))]
    th = round(tw * H / W); rows = (len(fs) + cols - 1) // cols
    sheet = Image.new('RGB', (tw * cols, (th + 22) * rows), 'white'); d = ImageDraw.Draw(sheet)
    for i, f in enumerate(fs):
        x, y = (i % cols) * tw, (i // cols) * (th + 22)
        sheet.paste(Image.open(f).resize((tw, th)), (x, y))
        d.text((x + 4, y + th + 5), labels[i] if labels else f'{i * 0.75:.2f}s', fill='black')
    sheet.save(dest)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('planner'); ap.add_argument('spec'); ap.add_argument('--out', default='video')
    ap.add_argument('--stills', action='store_true', help='render a storyboard sheet only')
    ap.add_argument('--rerecord', action='store_true'); ap.add_argument('--test', type=int, default=1)
    a = ap.parse_args()
    planner, out = pathlib.Path(a.planner), pathlib.Path(a.out); out.mkdir(parents=True, exist_ok=True)
    spec = json.load(open(a.spec))
    meta_f = out / 'sections.json'
    # only what changes the recording counts: restyling or new headlines reuse the recorded clips
    spec_sig = json.dumps([{k: x.get(k) for k in ('query', 'setup', 'steps', 'wake', 'settle')} for x in spec['sections']], sort_keys=True)
    sig_f = out / 'sections.sig'
    if a.rerecord or not meta_f.exists() or not sig_f.exists() or sig_f.read_text() != spec_sig:
        print('Recording the app...', flush=True)
        meta = record(planner, spec, out); sig_f.write_text(spec_sig)
    else:
        meta = json.load(open(meta_f))
    tl, fdir, frames = render(planner, spec, out, meta, stills=a.stills, test=a.test)
    slug = re.sub(r'[^a-z0-9]+', '-', spec.get('name', 'planner').lower()).strip('-')
    if a.stills:
        labels = [f'{f / FPS:.1f}s' for f in frames]
        contact(fdir, out / f'{slug}-storyboard.png', labels=labels, cols=min(8, len(frames)))
        print(f'Storyboard: {out / (slug + "-storyboard.png")}  ({tl.N / FPS:.1f}s video)')
        return
    mp4 = out / f'{slug}-3d-{tl.style}.mp4'
    subprocess.run(['ffmpeg', '-y', '-loglevel', 'error', '-framerate', str(FPS // a.test if a.test > 1 else FPS), '-i', str(fdir / '%05d.jpg'),
                    '-c:v', 'libx264', '-pix_fmt', 'yuv420p', '-crf', '17', '-preset', 'slow', '-movflags', '+faststart', str(mp4)], check=True)
    contact(fdir, out / f'{slug}-3d-{tl.style}-contact.png')
    print(f'Video: {mp4}  ({tl.N / FPS:.1f}s)  contact sheet: {slug}-3d-{tl.style}-contact.png')

if __name__ == '__main__':
    main()
